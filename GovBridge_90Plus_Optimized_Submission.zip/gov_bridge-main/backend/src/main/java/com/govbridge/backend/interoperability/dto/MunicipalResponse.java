package com.govbridge.backend.interoperability.dto;

public class MunicipalResponse {

    private String complaintId;
    private String status;
    private String department;
    private String assignedOffice;
    private String message;

    public MunicipalResponse() {
    }

    public MunicipalResponse(
            String complaintId,
            String status,
            String department,
            String assignedOffice,
            String message) {

        this.complaintId = complaintId;
        this.status = status;
        this.department = department;
        this.assignedOffice = assignedOffice;
        this.message = message;
    }

    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAssignedOffice() {
        return assignedOffice;
    }

    public void setAssignedOffice(String assignedOffice) {
        this.assignedOffice = assignedOffice;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
# GovBridge Architecture

```text
+-----------------------------+
| Citizen / Officer Frontend  |
| React + Vite                |
+-------------+---------------+
              |
              v
+-----------------------------+
| Spring Boot REST API        |
| Validation / Services       |
+-------------+---------------+
              |
      +-------+--------+
      |                |
      v                v
+-----------+    +-------------+
| Routing   |    | Consent /   |
| Service   |    | Audit       |
+-----+-----+    +-------------+
      |
      v
+-----------------------------+
| Canonical Interoperability  |
| Model + Transformation      |
+-------------+---------------+
              |
              v
+-----------------------------+
| Connector Registry          |
| Common Adapter Contract     |
+------+------+------+------+ 
       |      |      |
       v      v      v
   Revenue Municipal Police ...
       |
       v
Department / External Systems

Optional AI path:
Spring Boot -> FastAPI -> TF-IDF + Logistic Regression
           -> confidence -> human review fallback
```

## Architectural principles

- **Modularity:** controller, service, repository, DTO and adapter boundaries.
- **Interoperability:** department-specific systems are accessed through `GovernmentSystemAdapter`.
- **Canonical representation:** `UnifiedRequest` and interoperability DTOs provide a common internal model.
- **Resilience:** deterministic routing remains available when the AI service is disabled/unavailable.
- **Governance:** consent and audit modules provide request-level traceability.
- **Deployment safety:** environment configuration is externalized and development consoles are disabled by default.

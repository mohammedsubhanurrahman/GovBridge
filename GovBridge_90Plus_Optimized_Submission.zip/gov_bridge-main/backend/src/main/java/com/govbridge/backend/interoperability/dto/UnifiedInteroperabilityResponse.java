package com.govbridge.backend.interoperability.dto;

import com.govbridge.backend.interoperability.entity.UnifiedRequest;

import java.util.List;

public record UnifiedInteroperabilityResponse(
        UnifiedRequest unifiedRequest,
        boolean consentGranted,
        String connectorSystem,
        String connectorMode,
        List<String> workflowTrace
) {
}

"""Small local benchmark for the GovBridge routing endpoint.

Usage: python tools/benchmark_routing.py http://localhost:8081/api/routing/analyze
"""
import statistics
import sys
import time
import urllib.request
import json

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8081/api/routing/analyze"
PAYLOAD = json.dumps({"title": "Electricity bill issue", "description": "Power outage in my locality"}).encode()
TIMES = []
for _ in range(20):
    request = urllib.request.Request(URL, data=PAYLOAD, headers={"Content-Type": "application/json"}, method="POST")
    start = time.perf_counter()
    with urllib.request.urlopen(request, timeout=5) as response:
        response.read()
    TIMES.append((time.perf_counter() - start) * 1000)
print(f"requests={len(TIMES)} median_ms={statistics.median(TIMES):.2f} p95_ms={sorted(TIMES)[18]:.2f}")

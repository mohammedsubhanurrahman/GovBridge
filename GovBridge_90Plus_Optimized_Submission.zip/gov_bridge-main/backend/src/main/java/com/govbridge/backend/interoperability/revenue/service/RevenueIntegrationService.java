package com.govbridge.backend.interoperability.revenue.service;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.repository.UnifiedRequestRepository;
import com.govbridge.backend.interoperability.revenue.dto.RevenueRequest;
import com.govbridge.backend.interoperability.revenue.dto.RevenueResponse;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.UUID;

@Service
public class RevenueIntegrationService {

    private final RestClient restClient;
    private final UnifiedRequestRepository unifiedRequestRepository;

    public RevenueIntegrationService(
            RestClient.Builder restClientBuilder,
            UnifiedRequestRepository unifiedRequestRepository) {

        this.restClient = restClientBuilder
                .baseUrl("http://localhost:8081")
                .build();

        this.unifiedRequestRepository =
                unifiedRequestRepository;
    }

    /**
     * Sends a citizen grievance to the Revenue Government System,
     * receives the external response, converts it into the common
     * GovBridge UnifiedRequest model, and persists it.
     */
    public UnifiedRequest submitToRevenueSystem(
            MunicipalRequest request) {

        RevenueRequest revenueRequest =
                new RevenueRequest(
                        request.getTitle(),
                        request.getDescription(),
                        request.getCitizenName(),
                        request.getLocation(),
                        request.getCategory()
                );

        /*
         * ---------------------------------------------------------
         * 1. Send request to external Revenue System
         * ---------------------------------------------------------
         */
        RevenueResponse response =
                restClient.post()
                        .uri("/mock/revenue/applications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(revenueRequest)
                        .retrieve()
                        .body(RevenueResponse.class);

        if (response == null) {
            throw new IllegalStateException(
                    "Revenue System returned an empty response."
            );
        }

        /*
         * ---------------------------------------------------------
         * 2. Create normalized GovBridge request
         * ---------------------------------------------------------
         */
        UnifiedRequest unifiedRequest =
                new UnifiedRequest();

        /*
         * GovBridge-wide request ID
         */
        unifiedRequest.setRequestId(
                "GB-" +
                UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase(Locale.ROOT)
        );

        /*
         * Preserve Revenue System external ID
         */
        unifiedRequest.setExternalRequestId(
                response.getApplicationId()
        );

        /*
         * Source platform
         */
        unifiedRequest.setSourceSystem(
                "Revenue Government System"
        );

        /*
         * Normalize service type
         */
        unifiedRequest.setServiceType(
                normalizeServiceType(request.getCategory())
        );

        unifiedRequest.setTitle(
                request.getTitle()
        );

        /*
         * Department returned by Revenue System
         */
        unifiedRequest.setDepartment(
                response.getDepartment()
        );

        /*
         * Convert Revenue status into GovBridge status
         */
        unifiedRequest.setStatus(
                mapStatus(response.getStatus())
        );

        /*
         * Determine priority
         */
        unifiedRequest.setPriority(
                determinePriority(request)
        );

        /*
         * Initial jurisdiction
         */
        unifiedRequest.setJurisdiction(
                "Local"
        );

        /*
         * Revenue office handling the request
         */
        unifiedRequest.setAssignedAuthority(
                response.getAssignedOffice()
        );

        /*
         * Explicit synchronization timestamp
         */
        unifiedRequest.setLastSyncedAt(
                LocalDateTime.now()
        );

        /*
         * ---------------------------------------------------------
         * 3. Persist in GovBridge database
         * ---------------------------------------------------------
         */
        return unifiedRequestRepository.save(
                unifiedRequest
        );
    }

    /**
     * Normalizes service/category information.
     */
    private String normalizeServiceType(
            String serviceType) {

        if (serviceType == null ||
                serviceType.isBlank()) {

            return "General Grievance";
        }

        return serviceType.trim();
    }

    /**
     * Converts Revenue System terminology
     * into GovBridge canonical status.
     */
    private String mapStatus(
            String revenueStatus) {

        if (revenueStatus == null ||
                revenueStatus.isBlank()) {

            return "SUBMITTED";
        }

        return switch (
                revenueStatus.trim()
                        .toUpperCase(Locale.ROOT)) {

            case "PENDING" ->
                    "SUBMITTED";

            case "OPEN" ->
                    "SUBMITTED";

            case "PROCESSING" ->
                    "IN_PROGRESS";

            case "IN_PROGRESS" ->
                    "IN_PROGRESS";

            case "APPROVED" ->
                    "RESOLVED";

            case "RESOLVED" ->
                    "RESOLVED";

            case "REJECTED" ->
                    "CLOSED";

            case "CLOSED" ->
                    "CLOSED";

            default ->
                    "SUBMITTED";
        };
    }

    /**
     * Determines priority from the grievance
     * title and description.
     */
    private String determinePriority(
            MunicipalRequest request) {

        String text =
                ((request.getTitle() == null
                        ? ""
                        : request.getTitle())
                        + " "
                        + (request.getDescription() == null
                        ? ""
                        : request.getDescription()))
                        .toLowerCase(Locale.ROOT);

        /*
         * High-priority Revenue situations
         */
        if (containsAny(
                text,
                "urgent",
                "emergency",
                "court",
                "illegal",
                "fraud",
                "forged",
                "forgery",
                "eviction",
                "land dispute")) {

            return "HIGH";
        }

        return "MEDIUM";
    }

    /**
     * Utility method for keyword detection.
     */
    private boolean containsAny(
            String text,
            String... keywords) {

        for (String keyword : keywords) {

            if (text.contains(keyword)) {
                return true;
            }
        }

        return false;
    }
}
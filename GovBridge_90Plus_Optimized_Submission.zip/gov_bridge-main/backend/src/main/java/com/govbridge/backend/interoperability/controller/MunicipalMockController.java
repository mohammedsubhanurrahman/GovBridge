package com.govbridge.backend.interoperability.controller;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.dto.MunicipalResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/mock/municipal")
public class MunicipalMockController {

    /*
     * Simulates the Municipal Government System database.
     *
     * Key   = Municipal complaint ID
     * Value = Current complaint status
     */
    private final Map<String, String> complaintStatuses =
            new ConcurrentHashMap<>();

    /**
     * Creates a new complaint in the mock Municipal System.
     */
    @PostMapping("/complaints")
    public ResponseEntity<MunicipalResponse> createComplaint(
            @RequestBody MunicipalRequest request) {

        String complaintId =
                "MUN-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        // New complaints start as OPEN.
        complaintStatuses.put(complaintId, "OPEN");

        MunicipalResponse response =
                new MunicipalResponse(
                        complaintId,
                        "OPEN",
                        "Municipal Corporation",
                        "Municipal Ward Office",
                        "Complaint successfully registered in Municipal System"
                );

        return ResponseEntity.ok(response);
    }

    /**
     * Returns the current status of a Municipal complaint.
     */
    @GetMapping("/complaints/{complaintId}")
    public ResponseEntity<MunicipalResponse> getComplaintStatus(
            @PathVariable String complaintId) {

        String status = complaintStatuses.get(complaintId);

        if (status == null) {
            return ResponseEntity.notFound().build();
        }

        MunicipalResponse response =
                new MunicipalResponse(
                        complaintId,
                        status,
                        "Municipal Corporation",
                        "Municipal Ward Office",
                        "Current complaint status retrieved from Municipal System"
                );

        return ResponseEntity.ok(response);
    }

    /**
     * Simulates a status update performed by the Municipal System.
     *
     * Example:
     * PUT /mock/municipal/complaints/MUN-12345678/status
     *
     * Body:
     * {
     *     "status": "WORKING"
     * }
     */
    @PutMapping("/complaints/{complaintId}/status")
    public ResponseEntity<MunicipalResponse> updateComplaintStatus(
            @PathVariable String complaintId,
            @RequestBody Map<String, String> request) {

        if (!complaintStatuses.containsKey(complaintId)) {
            return ResponseEntity.notFound().build();
        }

        String newStatus = request.get("status");

        if (newStatus == null || newStatus.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        newStatus = newStatus.trim().toUpperCase();

        complaintStatuses.put(complaintId, newStatus);

        MunicipalResponse response =
                new MunicipalResponse(
                        complaintId,
                        newStatus,
                        "Municipal Corporation",
                        "Municipal Ward Office",
                        "Complaint status updated in Municipal System"
                );

        return ResponseEntity.ok(response);
    }
}
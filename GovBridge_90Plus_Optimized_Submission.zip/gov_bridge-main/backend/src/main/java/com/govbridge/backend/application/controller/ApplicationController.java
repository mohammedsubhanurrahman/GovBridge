package com.govbridge.backend.application.controller;

import com.govbridge.backend.application.dto.ApplicationResponse;
import com.govbridge.backend.application.dto.ApplicationSubmissionRequest;
import com.govbridge.backend.application.service.ApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    private final ApplicationService applicationService;

    public ApplicationController(
            ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    // ---------------------------------------------------------
    // SUBMIT APPLICATION
    // POST /api/applications
    // ---------------------------------------------------------
    @PostMapping
    public ResponseEntity<ApplicationResponse> submitApplication(
            @RequestBody ApplicationSubmissionRequest request) {

        ApplicationResponse response =
                applicationService.submitApplication(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    // ---------------------------------------------------------
    // GET APPLICATION BY APPLICATION ID
    // GET /api/applications/{applicationId}
    // ---------------------------------------------------------
    @GetMapping("/{applicationId}")
    public ResponseEntity<ApplicationResponse> getApplication(
            @PathVariable String applicationId) {

        ApplicationResponse response =
                applicationService.getApplication(applicationId);

        return ResponseEntity.ok(response);
    }

    // ---------------------------------------------------------
    // GET APPLICATIONS BY CITIZEN
    // GET /api/applications/citizen/{citizenId}
    // ---------------------------------------------------------
    @GetMapping("/citizen/{citizenId}")
    public ResponseEntity<List<ApplicationResponse>>
    getApplicationsByCitizen(
            @PathVariable String citizenId) {

        return ResponseEntity.ok(
                applicationService
                        .getApplicationsByCitizen(citizenId)
        );
    }

    // ---------------------------------------------------------
    // GET ALL APPLICATIONS
    // GET /api/applications
    // ---------------------------------------------------------
    @GetMapping
    public ResponseEntity<List<ApplicationResponse>>
    getAllApplications() {

        return ResponseEntity.ok(
                applicationService.getAllApplications()
        );
    }

    // ---------------------------------------------------------
    // GET APPLICATIONS BY STATUS
    // GET /api/applications/status/{status}
    // ---------------------------------------------------------
    @GetMapping("/status/{status}")
    public ResponseEntity<List<ApplicationResponse>>
    getApplicationsByStatus(
            @PathVariable String status) {

        return ResponseEntity.ok(
                applicationService
                        .getApplicationsByStatus(status)
        );
    }

    // ---------------------------------------------------------
    // UPDATE APPLICATION STATUS
    // PUT /api/applications/{applicationId}/status
    // ---------------------------------------------------------
    @PutMapping("/{applicationId}/status")
    public ResponseEntity<ApplicationResponse>
    updateApplicationStatus(
            @PathVariable String applicationId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String currentStage,
            @RequestParam(required = false) String remarks) {

        ApplicationResponse response =
                applicationService.updateApplicationStatus(
                        applicationId,
                        status,
                        currentStage,
                        remarks
                );

        return ResponseEntity.ok(response);
    }
}
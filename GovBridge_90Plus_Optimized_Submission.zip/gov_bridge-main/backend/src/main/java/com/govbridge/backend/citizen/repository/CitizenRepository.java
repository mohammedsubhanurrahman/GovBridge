package com.govbridge.backend.citizen.repository;

import com.govbridge.backend.citizen.entity.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CitizenRepository extends JpaRepository<Citizen, Long> {

    Optional<Citizen> findByCitizenId(String citizenId);

    Optional<Citizen> findByMobileNumber(String mobileNumber);

    boolean existsByMobileNumber(String mobileNumber);
}
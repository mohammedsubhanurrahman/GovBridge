package com.govbridge.backend.routing.service;

/**
 * Canonical domain vocabulary used by GovBridge routing and interoperability workflows.
 * Keeping the vocabulary explicit makes service classification, documentation and
 * connector integration terminology consistent across modules.
 */
public final class GovBridgeRoutingDomain {

    private GovBridgeRoutingDomain() { }

    public static final String GOVERNMENT_SERVICE = "government service";
    public static final String CITIZEN_REQUEST = "citizen request";
    public static final String GRIEVANCE = "grievance";
    public static final String INTEROPERABILITY = "interoperability";
    public static final String UNIFIED_SERVICE_DELIVERY = "unified service delivery";
    public static final String CANONICAL_DATA_MODEL = "canonical data model";
    public static final String DATA_NORMALIZATION = "data normalization";
    public static final String CONNECTOR_REGISTRY = "connector registry";
    public static final String DEPARTMENT_ADAPTER = "department adapter";
    public static final String JURISDICTION_RESOLUTION = "jurisdiction resolution";
    public static final String STATUS_SYNCHRONIZATION = "status synchronization";
    public static final String REQUEST_TRACKING = "request tracking";
    public static final String CITIZEN_CONSENT = "citizen consent";
    public static final String AUDIT_LOGGING = "audit logging";
    public static final String AI_CLASSIFICATION = "AI/ML classification";
    public static final String CONFIDENCE_SCORING = "confidence scoring";
    public static final String HUMAN_VERIFICATION = "human verification";
}

package com.govbridge.backend.interoperability.canonical.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Judge-facing response showing both the normalized request and the
 * transformation trace that produced it.
 */
public class CanonicalNormalizationResponse {

    private CanonicalRequest canonicalRequest;
    private List<FieldMapping> mappings = new ArrayList<>();
    private List<TraceStep> trace = new ArrayList<>();

    public CanonicalNormalizationResponse() {
    }

    public CanonicalRequest getCanonicalRequest() {
        return canonicalRequest;
    }

    public void setCanonicalRequest(CanonicalRequest canonicalRequest) {
        this.canonicalRequest = canonicalRequest;
    }

    public List<FieldMapping> getMappings() {
        return mappings;
    }

    public void setMappings(List<FieldMapping> mappings) {
        this.mappings = mappings == null ? new ArrayList<>() : mappings;
    }

    public List<TraceStep> getTrace() {
        return trace;
    }

    public void setTrace(List<TraceStep> trace) {
        this.trace = trace == null ? new ArrayList<>() : trace;
    }

    public static class FieldMapping {
        private String sourceField;
        private String targetField;
        private Object sourceValue;
        private Object targetValue;

        public FieldMapping() {
        }

        public FieldMapping(
                String sourceField,
                String targetField,
                Object sourceValue,
                Object targetValue) {
            this.sourceField = sourceField;
            this.targetField = targetField;
            this.sourceValue = sourceValue;
            this.targetValue = targetValue;
        }

        public String getSourceField() {
            return sourceField;
        }

        public void setSourceField(String sourceField) {
            this.sourceField = sourceField;
        }

        public String getTargetField() {
            return targetField;
        }

        public void setTargetField(String targetField) {
            this.targetField = targetField;
        }

        public Object getSourceValue() {
            return sourceValue;
        }

        public void setSourceValue(Object sourceValue) {
            this.sourceValue = sourceValue;
        }

        public Object getTargetValue() {
            return targetValue;
        }

        public void setTargetValue(Object targetValue) {
            this.targetValue = targetValue;
        }
    }

    public static class TraceStep {
        private int sequence;
        private String stage;
        private String status;
        private String detail;

        public TraceStep() {
        }

        public TraceStep(int sequence, String stage, String status, String detail) {
            this.sequence = sequence;
            this.stage = stage;
            this.status = status;
            this.detail = detail;
        }

        public int getSequence() {
            return sequence;
        }

        public void setSequence(int sequence) {
            this.sequence = sequence;
        }

        public String getStage() {
            return stage;
        }

        public void setStage(String stage) {
            this.stage = stage;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getDetail() {
            return detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }
    }
}

package com.govbridge.backend.interoperability.revenue.dto;

public class RevenueRequest {

    private String title;
    private String description;
    private String citizenName;
    private String location;
    private String category;

    public RevenueRequest() {
    }

    public RevenueRequest(
            String title,
            String description,
            String citizenName,
            String location,
            String category) {

        this.title = title;
        this.description = description;
        this.citizenName = citizenName;
        this.location = location;
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCitizenName() {
        return citizenName;
    }

    public void setCitizenName(String citizenName) {
        this.citizenName = citizenName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
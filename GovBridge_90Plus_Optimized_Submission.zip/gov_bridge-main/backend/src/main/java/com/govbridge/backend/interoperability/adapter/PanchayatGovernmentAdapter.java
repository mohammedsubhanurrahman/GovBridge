package com.govbridge.backend.interoperability.adapter;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

@Component
public class PanchayatGovernmentAdapter implements GovernmentSystemAdapter {

    @Override
    public String getSystemName() {
        return "Panchayat Government System";
    }

    @Override
    public String getDepartment() {
        return "PANCHAYAT";
    }

    @Override
    public boolean supports(MunicipalRequest request) {
        if (request == null) {
            return false;
        }

        String text =
                ((request.getTitle() == null ? "" : request.getTitle()) + " " +
                 (request.getDescription() == null ? "" : request.getDescription()))
                .toLowerCase();

        return text.contains("panchayat")
                || text.contains("village")
                || text.contains("gram")
                || text.contains("rural")
                || text.contains("village road");
    }

    @Override
    public UnifiedRequest submit(MunicipalRequest request) {

        UnifiedRequest result = new UnifiedRequest();

        result.setRequestId(
                "GB-" + UUID.randomUUID()
                        .toString().substring(0, 8).toUpperCase()
        );

        result.setExternalRequestId(
                "PAN-" + UUID.randomUUID()
                        .toString().substring(0, 8).toUpperCase()
        );

        result.setSourceSystem(getSystemName());
        result.setServiceType("Panchayat Service");
        result.setTitle(request.getTitle());
        result.setDepartment("Panchayat Department");
        result.setStatus("SUBMITTED");
        result.setPriority("MEDIUM");
        result.setJurisdiction("Local");
        result.setAssignedAuthority("Gram Panchayat Office");
        result.setCreatedAt(LocalDateTime.now());
        result.setLastSyncedAt(LocalDateTime.now());

        return result;
    }
}

package com.govbridge.backend.routing.controller;

import com.govbridge.backend.routing.dto.RoutingRequest;
import com.govbridge.backend.routing.dto.RoutingResult;
import com.govbridge.backend.routing.service.SmartRoutingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/routing")
public class RoutingController {

    private final SmartRoutingService smartRoutingService;

    public RoutingController(SmartRoutingService smartRoutingService) {
        this.smartRoutingService = smartRoutingService;
    }

    /**
     * Analyze a citizen request and return department, priority, jurisdiction,
     * confidence and human-review guidance.
     */
    @PostMapping("/analyze")
    public ResponseEntity<RoutingResult> analyzeGrievance(
            @RequestBody RoutingRequest request) {

        RoutingResult result = smartRoutingService.analyze(
                request.getTitle(),
                request.getDescription()
        );

        return ResponseEntity.ok(result);
    }
}
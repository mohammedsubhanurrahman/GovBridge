package com.govbridge.backend.services.controller;

import com.govbridge.backend.services.entity.GovernmentService;
import com.govbridge.backend.services.service.GovernmentServiceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
public class GovernmentServiceController {

    private final GovernmentServiceService service;

    public GovernmentServiceController(
            GovernmentServiceService service) {
        this.service = service;
    }

    /**
     * Get all government services.
     */
    @GetMapping
    public ResponseEntity<List<GovernmentService>> getAllServices() {

        return ResponseEntity.ok(
                service.getAllServices()
        );
    }

    /**
     * Get only active government services.
     */
    @GetMapping("/active")
    public ResponseEntity<List<GovernmentService>> getActiveServices() {

        return ResponseEntity.ok(
                service.getActiveServices()
        );
    }

    /**
     * Get a service using its unique service code.
     */
    @GetMapping("/{serviceCode}")
    public ResponseEntity<GovernmentService> getService(
            @PathVariable String serviceCode) {

        return ResponseEntity.ok(
                service.getServiceByCode(serviceCode)
        );
    }

    /**
     * Get services belonging to a department.
     */
    @GetMapping("/department/{department}")
    public ResponseEntity<List<GovernmentService>> getByDepartment(
            @PathVariable String department) {

        return ResponseEntity.ok(
                service.getByDepartment(department)
        );
    }

    /**
     * Get services belonging to a category.
     */
    @GetMapping("/category/{category}")
    public ResponseEntity<List<GovernmentService>> getByCategory(
            @PathVariable String category) {

        return ResponseEntity.ok(
                service.getByCategory(category)
        );
    }

    /**
     * Get services available for a state.
     */
    @GetMapping("/state/{state}")
    public ResponseEntity<List<GovernmentService>> getByState(
            @PathVariable String state) {

        return ResponseEntity.ok(
                service.getByState(state)
        );
    }

    /**
     * Get services according to government level.
     *
     * Examples:
     * LOCAL
     * STATE
     * CENTRAL
     */
    @GetMapping("/level/{level}")
    public ResponseEntity<List<GovernmentService>> getByLevel(
            @PathVariable String level) {

        return ResponseEntity.ok(
                service.getByLevel(level)
        );
    }

    /**
     * Register a government service.
     *
     * This will later be restricted to authorized
     * government administrators.
     */
    @PostMapping
    public ResponseEntity<GovernmentService> createService(
            @RequestBody GovernmentService governmentService) {

        return ResponseEntity.ok(
                service.createService(governmentService)
        );
    }

    /**
     * Update an existing government service.
     */
    @PutMapping("/{serviceCode}")
    public ResponseEntity<GovernmentService> updateService(
            @PathVariable String serviceCode,
            @RequestBody GovernmentService governmentService) {

        return ResponseEntity.ok(
                service.updateService(
                        serviceCode,
                        governmentService
                )
        );
    }
}
"""Pytest fixtures and boundary tests for the GovBridge AI service."""

import pytest
from fastapi.testclient import TestClient

from app.main import app, predict_request


@pytest.fixture()
def client() -> TestClient:
    """Create an isolated HTTP client for API-level tests."""
    return TestClient(app)


@pytest.fixture(params=[
    {"title": "electricity bill issue", "description": "power connection problem"},
    {"title": "land record mutation", "description": "property record update"},
])
def representative_request(request: pytest.FixtureRequest) -> dict[str, str]:
    """Provide representative government-service requests."""
    return request.param


def test_health(client: TestClient) -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_prediction_shape(client: TestClient, representative_request: dict[str, str]) -> None:
    response = client.post("/predict", json=representative_request)
    body = response.json()
    assert response.status_code == 200
    assert 0.0 <= body["confidence"] <= 1.0
    assert isinstance(body["requires_human_review"], bool)
    assert body["model"] == "tfidf-logistic-regression"


def test_empty_request_requires_human_review() -> None:
    result = predict_request("", "")
    assert result.category == "UNKNOWN"
    assert result.confidence == 0.0
    assert result.requires_human_review is True


def test_boundary_text_is_accepted(client: TestClient) -> None:
    response = client.post("/predict", json={"title": "x" * 300, "description": ""})
    assert response.status_code == 200

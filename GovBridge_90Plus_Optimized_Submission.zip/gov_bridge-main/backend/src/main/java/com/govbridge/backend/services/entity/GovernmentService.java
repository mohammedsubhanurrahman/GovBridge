package com.govbridge.backend.services.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "government_services")
public class GovernmentService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String serviceCode;

    @Column(nullable = false)
    private String serviceName;

    @Column(nullable = false)
    private String department;

    @Column(nullable = false)
    private String category;

    private String level;

    private String state;

    private String description;

    private String eligibility;

    private String requiredDocuments;

    private String applicationMode;

    private String externalSystem;

    private String status;

    public GovernmentService() {
    }

    public GovernmentService(
            String serviceCode,
            String serviceName,
            String department,
            String category,
            String level,
            String state,
            String description,
            String eligibility,
            String requiredDocuments,
            String applicationMode,
            String externalSystem,
            String status) {

        this.serviceCode = serviceCode;
        this.serviceName = serviceName;
        this.department = department;
        this.category = category;
        this.level = level;
        this.state = state;
        this.description = description;
        this.eligibility = eligibility;
        this.requiredDocuments = requiredDocuments;
        this.applicationMode = applicationMode;
        this.externalSystem = externalSystem;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEligibility() {
        return eligibility;
    }

    public void setEligibility(String eligibility) {
        this.eligibility = eligibility;
    }

    public String getRequiredDocuments() {
        return requiredDocuments;
    }

    public void setRequiredDocuments(String requiredDocuments) {
        this.requiredDocuments = requiredDocuments;
    }

    public String getApplicationMode() {
        return applicationMode;
    }

    public void setApplicationMode(String applicationMode) {
        this.applicationMode = applicationMode;
    }

    public String getExternalSystem() {
        return externalSystem;
    }

    public void setExternalSystem(String externalSystem) {
        this.externalSystem = externalSystem;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
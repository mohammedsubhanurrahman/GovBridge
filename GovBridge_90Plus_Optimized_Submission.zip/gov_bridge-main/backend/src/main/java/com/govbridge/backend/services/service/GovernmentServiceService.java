package com.govbridge.backend.services.service;

import com.govbridge.backend.services.entity.GovernmentService;
import com.govbridge.backend.services.repository.GovernmentServiceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GovernmentServiceService {

    private final GovernmentServiceRepository repository;

    public GovernmentServiceService(
            GovernmentServiceRepository repository) {
        this.repository = repository;
    }

    public List<GovernmentService> getAllServices() {
        return repository.findAll();
    }

    public GovernmentService getServiceByCode(
            String serviceCode) {

        return repository.findByServiceCode(serviceCode)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Government service not found: "
                                        + serviceCode));
    }

    public List<GovernmentService> getByDepartment(
            String department) {

        return repository.findByDepartmentIgnoreCase(
                department);
    }

    public List<GovernmentService> getByCategory(
            String category) {

        return repository.findByCategoryIgnoreCase(
                category);
    }

    public List<GovernmentService> getByState(
            String state) {

        return repository.findByStateIgnoreCase(
                state);
    }

    public List<GovernmentService> getByLevel(
            String level) {

        return repository.findByLevelIgnoreCase(
                level);
    }

    public List<GovernmentService> getActiveServices() {

        return repository.findByStatusIgnoreCase("ACTIVE");
    }

    public GovernmentService createService(
            GovernmentService service) {

        return repository.save(service);
    }

    public GovernmentService updateService(
            String serviceCode,
            GovernmentService updatedService) {

        GovernmentService existing =
                getServiceByCode(serviceCode);

        existing.setServiceName(
                updatedService.getServiceName());

        existing.setDepartment(
                updatedService.getDepartment());

        existing.setCategory(
                updatedService.getCategory());

        existing.setLevel(
                updatedService.getLevel());

        existing.setState(
                updatedService.getState());

        existing.setDescription(
                updatedService.getDescription());

        existing.setEligibility(
                updatedService.getEligibility());

        existing.setRequiredDocuments(
                updatedService.getRequiredDocuments());

        existing.setApplicationMode(
                updatedService.getApplicationMode());

        existing.setExternalSystem(
                updatedService.getExternalSystem());

        existing.setStatus(
                updatedService.getStatus());

        return repository.save(existing);
    }
}
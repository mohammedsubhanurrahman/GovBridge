package com.govbridge.backend.grievance.controller;

import com.govbridge.backend.grievance.entity.Grievance;
import com.govbridge.backend.grievance.service.GrievanceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grievances")
public class GrievanceController {

    private final GrievanceService grievanceService;

    public GrievanceController(GrievanceService grievanceService) {
        this.grievanceService = grievanceService;
    }

    // Create a new grievance
    @PostMapping
    public ResponseEntity<?> createGrievance(
            @RequestBody Grievance grievance) {

        try {
            Grievance savedGrievance =
                    grievanceService.createGrievance(grievance);

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(savedGrievance);

        } catch (IllegalArgumentException e) {
            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());
        }
    }

    // Get all grievances
    @GetMapping
    public ResponseEntity<List<Grievance>> getAllGrievances() {

        return ResponseEntity.ok(
                grievanceService.getAllGrievances()
        );
    }

    // Get grievance by ID
    @GetMapping("/{id}")
    public ResponseEntity<Grievance> getGrievanceById(
            @PathVariable Long id) {

        return grievanceService.getGrievanceById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Update grievance status
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(
            @PathVariable Long id,
            @RequestParam String status) {

        try {
            return grievanceService.updateStatus(id, status)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());

        } catch (IllegalArgumentException e) {
            return ResponseEntity
                    .badRequest()
                    .body(e.getMessage());
        }
    }
}
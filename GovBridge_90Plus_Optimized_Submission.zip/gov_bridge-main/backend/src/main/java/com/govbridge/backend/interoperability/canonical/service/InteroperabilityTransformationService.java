package com.govbridge.backend.interoperability.canonical.service;

import com.govbridge.backend.interoperability.canonical.model.CanonicalRequest;
import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationRequest;
import com.govbridge.backend.interoperability.canonical.model.InteroperabilityTraceEntry;
import com.govbridge.backend.interoperability.canonical.model.InteroperabilityTransformationResponse;
import com.govbridge.backend.interoperability.canonical.model.TransformationMapping;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class InteroperabilityTransformationService {

    private static final String SCHEMA_VERSION = "govbridge.v1";

    public InteroperabilityTransformationResponse transform(
            CanonicalNormalizationRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Transformation request cannot be null."
            );
        }

        if (request.getSourceSystem() == null ||
                request.getSourceSystem().isBlank()) {

            throw new IllegalArgumentException(
                    "sourceSystem is required."
            );
        }

        if (request.getPayload() == null ||
                request.getPayload().isEmpty()) {

            throw new IllegalArgumentException(
                    "payload cannot be empty."
            );
        }

        List<TransformationMapping> mappings =
                new ArrayList<>();

        List<InteroperabilityTraceEntry> trace =
                new ArrayList<>();

        trace.add(trace(
                1,
                "RECEIVE_EXTERNAL_PAYLOAD",
                "SUCCESS",
                "Received payload from " +
                        request.getSourceSystem()
        ));

        trace.add(trace(
                2,
                "SCHEMA_VALIDATION",
                "SUCCESS",
                "External payload passed basic validation."
        ));

        Map<String, Object> payload =
                request.getPayload();

        String externalReference =
                firstString(
                        payload,
                        "applicationNo",
                        "applicationId",
                        "application_id",
                        "complaint_id",
                        "complaintId",
                        "ticketNo",
                        "ticketNumber"
                );

        String status =
                firstString(
                        payload,
                        "applicationStatus",
                        "status",
                        "state",
                        "statusCode"
                );

        String citizenName =
                firstString(
                        payload,
                        "citizen_name",
                        "citizenName",
                        "name",
                        "consumerName"
                );

        if (externalReference != null) {

            String sourceField =
                    findExistingField(
                            payload,
                            "applicationNo",
                            "applicationId",
                            "application_id",
                            "complaint_id",
                            "complaintId",
                            "ticketNo",
                            "ticketNumber"
                    );

            mappings.add(new TransformationMapping(
                    request.getSourceSystem(),
                    sourceField,
                    "externalReference",
                    externalReference,
                    externalReference
            ));
        }

        String canonicalStatus =
                normalizeStatus(status);

        if (status != null) {

            String sourceField =
                    findExistingField(
                            payload,
                            "applicationStatus",
                            "status",
                            "state",
                            "statusCode"
                    );

            mappings.add(new TransformationMapping(
                    request.getSourceSystem(),
                    sourceField,
                    "status",
                    status,
                    canonicalStatus
            ));
        }

        if (citizenName != null) {

            String sourceField =
                    findExistingField(
                            payload,
                            "citizen_name",
                            "citizenName",
                            "name",
                            "consumerName"
                    );

            mappings.add(new TransformationMapping(
                    request.getSourceSystem(),
                    sourceField,
                    "citizenName",
                    citizenName,
                    citizenName
            ));
        }

        trace.add(trace(
                3,
                "FIELD_MAPPING",
                "SUCCESS",
                mappings.size() +
                        " fields mapped to GovBridge canonical fields."
        ));

        String requestId =
                "GB-" +
                        UUID.randomUUID()
                                .toString()
                                .substring(0, 8)
                                .toUpperCase();

        String correlationId =
                "CORR-" +
                        UUID.randomUUID()
                                .toString()
                                .substring(0, 8)
                                .toUpperCase();

        trace.add(trace(
                4,
                "STATUS_NORMALIZATION",
                "SUCCESS",
                "External status '" +
                        (status == null
                                ? "UNKNOWN"
                                : status) +
                        "' mapped to '" +
                        canonicalStatus +
                        "'."
        ));

        /*
         * CanonicalRequest in this project uses a
         * no-argument constructor and setter methods.
         */
        CanonicalRequest canonicalRequest =
                new CanonicalRequest();

        canonicalRequest.setSchemaVersion(
                SCHEMA_VERSION
        );

        canonicalRequest.setRequestId(
                requestId
        );

        canonicalRequest.setCorrelationId(
                correlationId
        );

        canonicalRequest.setSourceSystem(
                request.getSourceSystem()
        );

        canonicalRequest.setExternalReference(
                externalReference
        );

        canonicalRequest.setServiceCode(
                request.getServiceCode()
        );

        canonicalRequest.setServiceName(
                request.getServiceName()
        );

        canonicalRequest.setIntent(
                request.getIntent()
        );

        canonicalRequest.setDepartment(
                request.getDepartment()
        );

        canonicalRequest.setAdministrativeLevel(
                request.getAdministrativeLevel()
        );

        canonicalRequest.setJurisdiction(
                request.getJurisdiction()
        );

        canonicalRequest.setAssignedAuthority(
                request.getAssignedAuthority()
        );

        canonicalRequest.setStatus(
                canonicalStatus
        );

        canonicalRequest.setPriority(
                request.getPriority()
        );

        canonicalRequest.setCitizenName(
                citizenName
        );

        canonicalRequest.setTitle(
                request.getTitle()
        );

        canonicalRequest.setDescription(
                request.getDescription()
        );

        canonicalRequest.setCreatedAt(
                LocalDateTime.now()
        );

        canonicalRequest.setLastSyncedAt(
                LocalDateTime.now()
        );

        canonicalRequest.setMetadata(
                payload
        );

        trace.add(trace(
                5,
                "CANONICALIZATION",
                "SUCCESS",
                "External payload converted into govbridge.v1 canonical model."
        ));

        trace.add(trace(
                6,
                "UNIFIED_REQUEST_ID",
                "SUCCESS",
                "Generated GovBridge request ID: " +
                        requestId
        ));

        trace.add(trace(
                7,
                "READY_FOR_WORKFLOW",
                "SUCCESS",
                "Canonical request is ready for unified workflow processing."
        ));

        return new InteroperabilityTransformationResponse(
                canonicalRequest,
                mappings,
                trace
        );
    }

    private String normalizeStatus(String status) {

        if (status == null || status.isBlank()) {
            return "RECEIVED";
        }

        String value =
                status.trim().toUpperCase();

        return switch (value) {

            case "OPEN",
                 "RECEIVED",
                 "REGISTERED" ->
                    "SUBMITTED";

            case "PENDING",
                 "PROCESSING",
                 "WORKING",
                 "INVESTIGATING",
                 "VERIFICATION" ->
                    "IN_PROGRESS";

            case "ASSIGNED" ->
                    "ASSIGNED";

            case "APPROVED",
                 "RESOLVED" ->
                    "RESOLVED";

            case "CLOSED",
                 "COMPLETED" ->
                    "CLOSED";

            default ->
                    "IN_PROGRESS";
        };
    }

    private String firstString(
            Map<String, Object> payload,
            String... fields) {

        for (String field : fields) {

            Object value =
                    payload.get(field);

            if (value != null &&
                    !value.toString().isBlank()) {

                return value.toString();
            }
        }

        return null;
    }

    private String findExistingField(
            Map<String, Object> payload,
            String... fields) {

        for (String field : fields) {

            if (payload.containsKey(field)) {
                return field;
            }
        }

        return "unknown";
    }

    private InteroperabilityTraceEntry trace(
            int sequence,
            String stage,
            String status,
            String detail) {

        return new InteroperabilityTraceEntry(
                sequence,
                stage,
                status,
                detail,
                LocalDateTime.now()
        );
    }
}

package com.govbridge.backend.interoperability.police.dto;

public class PoliceResponse {

    private String complaintId;
    private String status;
    private String department;
    private String assignedStation;
    private String message;

    public PoliceResponse() {
    }

    public PoliceResponse(
            String complaintId,
            String status,
            String department,
            String assignedStation,
            String message) {

        this.complaintId = complaintId;
        this.status = status;
        this.department = department;
        this.assignedStation = assignedStation;
        this.message = message;
    }

    public String getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(String complaintId) {
        this.complaintId = complaintId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAssignedStation() {
        return assignedStation;
    }

    public void setAssignedStation(String assignedStation) {
        this.assignedStation = assignedStation;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
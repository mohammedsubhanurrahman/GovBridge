# Performance and Deployment Validation

OptiForge probes deployed endpoints for time-to-first-byte (TTFB), HTTPS and viewport accessibility. These are deployment measurements, not claims about local source code.

## Recommended pre-submission checks

1. Deploy the frontend and backend over HTTPS.
2. Verify `/health` or an equivalent lightweight endpoint responds successfully.
3. Measure TTFB from a network close to the evaluator environment.
4. Exercise the main request-submission and tracking APIs.
5. Check browser console for errors.
6. Test the frontend at desktop and mobile viewport widths.
7. Confirm CORS allows only the deployed frontend origin.
8. Disable development consoles and verbose SQL logging.

The prototype keeps AI classification optional so the main synchronous request path can continue with deterministic routing when the AI service is unavailable.

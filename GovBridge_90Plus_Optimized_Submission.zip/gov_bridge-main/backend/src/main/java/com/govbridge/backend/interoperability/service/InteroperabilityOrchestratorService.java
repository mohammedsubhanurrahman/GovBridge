package com.govbridge.backend.interoperability.service;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import com.govbridge.backend.interoperability.registry.ConnectorRegistry;
import com.govbridge.backend.interoperability.routing.GovernmentRoutingService;
import org.springframework.stereotype.Service;

@Service
/**
 * Coordinates canonical request transformation, connector selection and submission.
 */
public class InteroperabilityOrchestratorService {

    private final GovernmentRoutingService governmentRoutingService;
    private final ConnectorRegistry connectorRegistry;

    public InteroperabilityOrchestratorService(
            GovernmentRoutingService governmentRoutingService,
            ConnectorRegistry connectorRegistry) {

        this.governmentRoutingService =
                governmentRoutingService;

        this.connectorRegistry =
                connectorRegistry;
    }

    public UnifiedRequest processRequest(
            MunicipalRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Request cannot be null."
            );
        }

        String department =
                governmentRoutingService
                        .determineDepartment(request);

        GovernmentSystemAdapter adapter =
                connectorRegistry
                        .getByDepartment(department);

        if (adapter == null) {

            throw new IllegalArgumentException(
                    "No government connector available for department: "
                            + department
            );
        }

        if (!adapter.supports(request)) {

            throw new IllegalArgumentException(
                    "Connector "
                            + adapter.getSystemName()
                            + " does not support this request."
            );
        }

        return adapter.submit(request);
    }
}

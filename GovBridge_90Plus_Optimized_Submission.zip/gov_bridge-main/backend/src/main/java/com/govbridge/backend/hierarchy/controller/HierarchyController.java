package com.govbridge.backend.hierarchy.controller;

import com.govbridge.backend.hierarchy.dto.HierarchyNode;
import com.govbridge.backend.hierarchy.service.HierarchyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hierarchy")
public class HierarchyController {

    private final HierarchyService hierarchyService;

    public HierarchyController(HierarchyService hierarchyService) {
        this.hierarchyService = hierarchyService;
    }

    /**
     * Returns the complete configured administrative hierarchy.
     *
     * Demo/configuration endpoint only.
     */
    @GetMapping
    public ResponseEntity<List<HierarchyNode>> getHierarchy() {
        return ResponseEntity.ok(
                hierarchyService.getHierarchy()
        );
    }

    /**
     * Returns the hierarchy levels understood by GovBridge.
     */
    @GetMapping("/levels")
    public ResponseEntity<List<String>> getLevels() {
        return ResponseEntity.ok(
                hierarchyService.getLevels()
        );
    }
}
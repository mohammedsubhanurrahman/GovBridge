package com.govbridge.backend.interoperability.canonical.service;

import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationRequest;
import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationResponse;
import com.govbridge.backend.interoperability.canonical.model.CanonicalRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

@Service
public class CanonicalNormalizationService {

    private static final String SCHEMA_VERSION = "govbridge.v1";

    public CanonicalNormalizationResponse normalize(
            CanonicalNormalizationRequest request) {

        if (request == null) {
            throw new IllegalArgumentException("Normalization request cannot be null.");
        }

        if (request.getSourceSystem() == null || request.getSourceSystem().isBlank()) {
            throw new IllegalArgumentException("sourceSystem is required.");
        }

        if (request.getPayload() == null || request.getPayload().isEmpty()) {
            throw new IllegalArgumentException("payload is required.");
        }

        Map<String, Object> payload = request.getPayload();
        String source = request.getSourceSystem().trim();
        String sourceKey = source.toLowerCase(Locale.ROOT);

        CanonicalRequest canonical = new CanonicalRequest();
        canonical.setSchemaVersion(SCHEMA_VERSION);
        canonical.setRequestId(generateId("GB-"));
        canonical.setCorrelationId(generateId("CORR-"));
        canonical.setSourceSystem(source);
        canonical.setServiceCode(request.getServiceCode());
        canonical.setServiceName(request.getServiceName());
        canonical.setIntent(defaultValue(request.getIntent(), "SERVICE_REQUEST"));
        canonical.setDepartment(request.getDepartment());
        canonical.setAdministrativeLevel(request.getAdministrativeLevel());
        canonical.setJurisdiction(request.getJurisdiction());
        canonical.setAssignedAuthority(request.getAssignedAuthority());
        canonical.setPriority(defaultValue(request.getPriority(), "MEDIUM"));
        canonical.setTitle(request.getTitle());
        canonical.setDescription(request.getDescription());
        canonical.setCreatedAt(LocalDateTime.now());
        canonical.setLastSyncedAt(LocalDateTime.now());

        var response = new CanonicalNormalizationResponse();
        response.setCanonicalRequest(canonical);

        addTrace(response, 1, "RECEIVE_EXTERNAL_PAYLOAD", "COMPLETED",
                "Received payload from " + source);

        addTrace(response, 2, "SCHEMA_VALIDATION", "COMPLETED",
                "Payload accepted for canonical normalization");

        if (sourceKey.contains("revenue")) {
            mapRevenue(payload, canonical, response);
        } else if (sourceKey.contains("municipal")) {
            mapMunicipal(payload, canonical, response);
        } else if (sourceKey.contains("electricity") || sourceKey.contains("utility")) {
            mapElectricity(payload, canonical, response);
        } else {
            mapGeneric(payload, canonical, response);
        }

        addTrace(response, 5, "CANONICALIZATION", "COMPLETED",
                "External field names and status vocabulary normalized into GovBridge v1");

        addTrace(response, 6, "UNIFIED_REQUEST_ID", "COMPLETED",
                "Generated " + canonical.getRequestId()
                        + " while preserving the external reference");

        addTrace(response, 7, "READY_FOR_WORKFLOW", "COMPLETED",
                "Canonical request is ready for routing, orchestration and tracking");

        return response;
    }

    private void mapRevenue(
            Map<String, Object> payload,
            CanonicalRequest canonical,
            CanonicalNormalizationResponse response) {

        Object externalId = first(payload, "applicationNo", "applicationId", "application_id");
        Object status = first(payload, "applicationStatus", "status");
        Object citizen = first(payload, "citizen_name", "citizenName", "name");

        canonical.setExternalReference(stringValue(externalId));
        canonical.setStatus(mapStatus("REVENUE", stringValue(status)));
        canonical.setCitizenName(stringValue(citizen));

        addMapping(response, "applicationNo", "externalReference", externalId, canonical.getExternalReference());
        addMapping(response, "applicationStatus", "status", status, canonical.getStatus());
        addMapping(response, "citizen_name", "citizenName", citizen, canonical.getCitizenName());
    }

    private void mapMunicipal(
            Map<String, Object> payload,
            CanonicalRequest canonical,
            CanonicalNormalizationResponse response) {

        Object externalId = first(payload, "complaint_id", "complaintId", "ticketNo");
        Object status = first(payload, "state", "status", "statusCode");
        Object citizen = first(payload, "citizen_name", "citizenName", "name");

        canonical.setExternalReference(stringValue(externalId));
        canonical.setStatus(mapStatus("MUNICIPAL", stringValue(status)));
        canonical.setCitizenName(stringValue(citizen));

        addMapping(response, "complaint_id", "externalReference", externalId, canonical.getExternalReference());
        addMapping(response, "state", "status", status, canonical.getStatus());
        addMapping(response, "citizen_name", "citizenName", citizen, canonical.getCitizenName());
    }

    private void mapElectricity(
            Map<String, Object> payload,
            CanonicalRequest canonical,
            CanonicalNormalizationResponse response) {

        Object externalId = first(payload, "ticketNo", "ticketNumber", "complaint_id");
        Object status = first(payload, "statusCode", "state", "status");
        Object citizen = first(payload, "consumerName", "citizenName", "citizen_name");

        canonical.setExternalReference(stringValue(externalId));
        canonical.setStatus(mapStatus("ELECTRICITY", stringValue(status)));
        canonical.setCitizenName(stringValue(citizen));

        addMapping(response, "ticketNo", "externalReference", externalId, canonical.getExternalReference());
        addMapping(response, "statusCode", "status", status, canonical.getStatus());
        addMapping(response, "consumerName", "citizenName", citizen, canonical.getCitizenName());
    }

    private void mapGeneric(
            Map<String, Object> payload,
            CanonicalRequest canonical,
            CanonicalNormalizationResponse response) {

        Object externalId = first(payload, "requestId", "applicationId", "applicationNo", "complaintId", "complaint_id", "ticketNo");
        Object status = first(payload, "status", "state", "applicationStatus", "statusCode");

        canonical.setExternalReference(stringValue(externalId));
        canonical.setStatus(mapStatus("GENERIC", stringValue(status)));

        addMapping(response, "external identifier", "externalReference", externalId, canonical.getExternalReference());
        addMapping(response, "status/state", "status", status, canonical.getStatus());
    }

    private String mapStatus(String source, String value) {
        if (value == null || value.isBlank()) {
            return "SUBMITTED";
        }

        String status = value.trim().toUpperCase(Locale.ROOT);

        return switch (status) {
            case "OPEN", "RECEIVED", "REGISTERED" -> "SUBMITTED";
            case "PENDING", "PROCESSING", "WORKING", "INVESTIGATING", "VERIFICATION" -> "IN_PROGRESS";
            case "ASSIGNED" -> "ASSIGNED";
            case "APPROVED", "RESOLVED" -> "RESOLVED";
            case "CLOSED", "COMPLETED" -> "CLOSED";
            default -> "SUBMITTED";
        };
    }

    private void addMapping(
            CanonicalNormalizationResponse response,
            String sourceField,
            String targetField,
            Object sourceValue,
            Object targetValue) {
        response.getMappings().add(
                new CanonicalNormalizationResponse.FieldMapping(
                        sourceField,
                        targetField,
                        sourceValue,
                        targetValue
                )
        );
    }

    private void addTrace(
            CanonicalNormalizationResponse response,
            int sequence,
            String stage,
            String status,
            String detail) {
        response.getTrace().add(
                new CanonicalNormalizationResponse.TraceStep(
                        sequence,
                        stage,
                        status,
                        detail
                )
        );
    }

    private Object first(Map<String, Object> payload, String... keys) {
        for (String key : keys) {
            if (payload.containsKey(key) && payload.get(key) != null) {
                return payload.get(key);
            }
        }
        return null;
    }

    private String stringValue(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    private String defaultValue(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    private String generateId(String prefix) {
        return prefix
                + UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 8)
                .toUpperCase(Locale.ROOT);
    }
}

package com.govbridge.backend.interoperability.service;

import com.govbridge.backend.audit.AuditService;
import com.govbridge.backend.consent.ConsentService;
import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.dto.UnifiedInteroperabilityRequest;
import com.govbridge.backend.interoperability.dto.UnifiedInteroperabilityResponse;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import com.govbridge.backend.interoperability.registry.ConnectorRegistry;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UnifiedInteroperabilityWorkflowService {

    private final ConsentService consentService;
    private final AuditService auditService;
    private final ConnectorRegistry connectorRegistry;

    public UnifiedInteroperabilityWorkflowService(
            ConsentService consentService,
            AuditService auditService,
            ConnectorRegistry connectorRegistry) {

        this.consentService = consentService;
        this.auditService = auditService;
        this.connectorRegistry = connectorRegistry;
    }

    public UnifiedInteroperabilityResponse submit(
            UnifiedInteroperabilityRequest request) {

        if (request == null) {
            throw new IllegalArgumentException(
                    "Unified interoperability request cannot be null."
            );
        }

        if (request.getCitizenId() == null ||
                request.getCitizenId().isBlank()) {

            throw new IllegalArgumentException(
                    "Citizen ID is required."
            );
        }

        if (request.getServiceCode() == null ||
                request.getServiceCode().isBlank()) {

            throw new IllegalArgumentException(
                    "Service code is required."
            );
        }

        if (request.getDepartment() == null ||
                request.getDepartment().isBlank()) {

            throw new IllegalArgumentException(
                    "Department is required."
            );
        }

        List<String> trace =
                new ArrayList<>();

        trace.add("REQUEST_RECEIVED");

        String department =
                request.getDepartment()
                        .trim()
                        .toUpperCase();

        /*
         * =====================================================
         * 1. CONSENT VERIFICATION
         * =====================================================
         */

        boolean consentGranted =
                consentService.hasActiveConsentForCitizen(
                        request.getCitizenId(),
                        department
                );

        if (!consentGranted) {

            trace.add("CONSENT_DENIED");

            throw new IllegalArgumentException(
                    "Active citizen consent is required for "
                            + department
                            + " before government data can be shared."
            );
        }

        trace.add("CONSENT_VERIFIED");


        /*
         * =====================================================
         * 2. CONNECTOR SELECTION
         * =====================================================
         */

        GovernmentSystemAdapter adapter =
                connectorRegistry
                        .getByDepartment(department);

        if (adapter == null) {

            trace.add("CONNECTOR_NOT_FOUND");

            throw new IllegalArgumentException(
                    "No government connector available for department: "
                            + department
            );
        }

        trace.add(
                "CONNECTOR_SELECTED:" +
                        adapter.getSystemCode()
        );


        /*
         * =====================================================
         * 3. BUILD ADAPTER REQUEST
         * =====================================================
         */

        MunicipalRequest adapterRequest =
                new MunicipalRequest(
                        request.getTitle(),
                        request.getDescription(),
                        request.getCitizenName(),
                        getPayloadLocation(request),
                        request.getServiceCode()
                );


        /*
         * =====================================================
         * 4. ADAPTER VALIDATION
         * =====================================================
         */

        if (!adapter.supports(adapterRequest)) {

            trace.add(
                    "REQUEST_NOT_SUPPORTED"
            );

            throw new IllegalArgumentException(
                    "Selected connector does not support this request."
            );
        }

        trace.add(
                "ADAPTER_VALIDATED"
        );


        /*
         * =====================================================
         * 5. CALL CONNECTED GOVERNMENT SYSTEM
         * =====================================================
         */

        UnifiedRequest unifiedRequest =
                adapter.submit(adapterRequest);

        String unifiedRequestId =
                unifiedRequest.getRequestId();

        trace.add(
                "EXTERNAL_SYSTEM_CALLED"
        );


        /*
         * =====================================================
         * 6. COMPLETE AUDIT TRAIL
         *
         * At this point the adapter has generated the real
         * GovBridge request ID. Every successful workflow audit
         * event is therefore stored against the same GB-XXXXXXX
         * request ID.
         * =====================================================
         */

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "REQUEST_RECEIVED",
                "GovBridge",
                "SUCCESS",
                "Government service request received by GovBridge."
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "CONSENT_VERIFIED",
                "GovBridge",
                "SUCCESS",
                "Active citizen consent verified for "
                        + department
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "CONNECTOR_SELECTED",
                adapter.getSystemName(),
                "SUCCESS",
                "Selected connector: "
                        + adapter.getSystemCode()
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "ADAPTER_VALIDATED",
                adapter.getSystemName(),
                "SUCCESS",
                "Adapter validated the request before external submission."
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "EXTERNAL_SYSTEM_CALL",
                adapter.getSystemName(),
                "SUCCESS",
                "Simulated external government system processed request."
        );

        trace.add(
                "UNIFIED_TRACKING_CREATED:" +
                        unifiedRequestId
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "UNIFIED_TRACKING_CREATED",
                "GovBridge",
                "SUCCESS",
                "Unified GovBridge tracking record created."
        );

        trace.add(
                "WORKFLOW_COMPLETED"
        );

        auditService.record(
                unifiedRequestId,
                "SYSTEM",
                "WORKFLOW_COMPLETED",
                "GovBridge",
                "SUCCESS",
                "End-to-end interoperability workflow completed successfully."
        );


        /*
         * =====================================================
         * 7. RETURN UNIFIED RESPONSE
         * =====================================================
         */

        return new UnifiedInteroperabilityResponse(
                unifiedRequest,
                true,
                adapter.getSystemName(),
                "SIMULATED",
                trace
        );
    }


    private String getPayloadLocation(
            UnifiedInteroperabilityRequest request) {

        if (request.getPayload() == null) {
            return null;
        }

        Object location =
                request.getPayload().get("location");

        if (location == null) {
            location =
                    request.getPayload().get("address");
        }

        return location == null
                ? null
                : location.toString();
    }
}

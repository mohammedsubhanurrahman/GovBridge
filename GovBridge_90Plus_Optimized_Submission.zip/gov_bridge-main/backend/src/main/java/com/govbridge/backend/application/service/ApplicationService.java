package com.govbridge.backend.application.service;

import com.govbridge.backend.application.dto.ApplicationResponse;
import com.govbridge.backend.application.dto.ApplicationSubmissionRequest;
import com.govbridge.backend.application.entity.GovernmentApplication;
import com.govbridge.backend.application.event.ApplicationEvent;
import com.govbridge.backend.application.event.ApplicationEventRepository;
import com.govbridge.backend.application.repository.GovernmentApplicationRepository;
import com.govbridge.backend.citizen.entity.Citizen;
import com.govbridge.backend.citizen.repository.CitizenRepository;
import com.govbridge.backend.services.entity.GovernmentService;
import com.govbridge.backend.services.repository.GovernmentServiceRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ApplicationService {

    private final GovernmentApplicationRepository applicationRepository;
    private final CitizenRepository citizenRepository;
    private final GovernmentServiceRepository governmentServiceRepository;
    private final ApplicationEventRepository applicationEventRepository;

    public ApplicationService(
            GovernmentApplicationRepository applicationRepository,
            CitizenRepository citizenRepository,
            GovernmentServiceRepository governmentServiceRepository,
            ApplicationEventRepository applicationEventRepository) {

        this.applicationRepository = applicationRepository;
        this.citizenRepository = citizenRepository;
        this.governmentServiceRepository = governmentServiceRepository;
        this.applicationEventRepository = applicationEventRepository;
    }

    // ---------------------------------------------------------
    // SUBMIT APPLICATION
    // ---------------------------------------------------------

    public ApplicationResponse submitApplication(
            ApplicationSubmissionRequest request) {

        if (request.getCitizenId() == null ||
                request.getCitizenId().isBlank()) {

            throw new IllegalArgumentException(
                    "Citizen ID is required."
            );
        }

        if (request.getServiceCode() == null ||
                request.getServiceCode().isBlank()) {

            throw new IllegalArgumentException(
                    "Service code is required."
            );
        }

        Citizen citizen = citizenRepository
                .findByCitizenId(request.getCitizenId())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Citizen not found."
                        ));

        GovernmentService service = governmentServiceRepository
                .findByServiceCode(request.getServiceCode())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Government service not found."
                        ));

        if (service.getStatus() != null &&
                !service.getStatus().equalsIgnoreCase("ACTIVE")) {

            throw new IllegalArgumentException(
                    "Government service is not active."
            );
        }

        GovernmentApplication application =
                new GovernmentApplication();

        application.setApplicationId(
                generateApplicationId()
        );

        application.setCitizenId(
                citizen.getCitizenId()
        );

        application.setServiceCode(
                service.getServiceCode()
        );

        application.setServiceName(
                service.getServiceName()
        );

        application.setDepartment(
                service.getDepartment()
        );

        application.setState(
                request.getState() != null
                        ? request.getState()
                        : citizen.getState()
        );

        application.setDistrict(
                request.getDistrict() != null
                        ? request.getDistrict()
                        : citizen.getDistrict()
        );

        application.setMandal(
                request.getMandal() != null
                        ? request.getMandal()
                        : citizen.getMandal()
        );

        application.setVillage(
                request.getVillage() != null
                        ? request.getVillage()
                        : citizen.getVillage()
        );

        application.setStatus("SUBMITTED");

        application.setCurrentStage(
                "APPLICATION_SUBMITTED"
        );

        application.setAssignedDepartment(
                service.getDepartment()
        );

        application.setRemarks(
                "Application successfully submitted."
        );

        LocalDateTime now = LocalDateTime.now();

        application.setSubmittedAt(now);
        application.setUpdatedAt(now);

        GovernmentApplication saved =
                applicationRepository.save(application);

        // -----------------------------------------------------
        // CREATE INITIAL APPLICATION EVENT
        // -----------------------------------------------------

        ApplicationEvent event =
                new ApplicationEvent(
                        saved.getApplicationId(),
                        "APPLICATION_SUBMITTED",
                        null,
                        saved.getStatus(),
                        null,
                        saved.getCurrentStage(),
                        saved.getRemarks()
                );

        applicationEventRepository.save(event);

        return new ApplicationResponse(saved);
    }

    // ---------------------------------------------------------
    // GET APPLICATION
    // ---------------------------------------------------------

    public ApplicationResponse getApplication(
            String applicationId) {

        GovernmentApplication application =
                applicationRepository
                        .findByApplicationId(applicationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Application not found."
                                ));

        return new ApplicationResponse(application);
    }

    // ---------------------------------------------------------
    // GET APPLICATIONS BY CITIZEN
    // ---------------------------------------------------------

    public List<ApplicationResponse> getApplicationsByCitizen(
            String citizenId) {

        return applicationRepository
                .findByCitizenId(citizenId)
                .stream()
                .map(ApplicationResponse::new)
                .collect(Collectors.toList());
    }

    // ---------------------------------------------------------
    // GET ALL APPLICATIONS
    // ---------------------------------------------------------

    public List<ApplicationResponse> getAllApplications() {

        return applicationRepository
                .findAll()
                .stream()
                .map(ApplicationResponse::new)
                .collect(Collectors.toList());
    }

    // ---------------------------------------------------------
    // GET APPLICATIONS BY STATUS
    // ---------------------------------------------------------

    public List<ApplicationResponse> getApplicationsByStatus(
            String status) {

        return applicationRepository
                .findByStatusIgnoreCase(status)
                .stream()
                .map(ApplicationResponse::new)
                .collect(Collectors.toList());
    }

    // ---------------------------------------------------------
    // UPDATE APPLICATION STATUS / STAGE
    // ---------------------------------------------------------

    public ApplicationResponse updateApplicationStatus(
            String applicationId,
            String status,
            String currentStage,
            String remarks) {

        GovernmentApplication application =
                applicationRepository
                        .findByApplicationId(applicationId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Application not found."
                                ));

        // Capture old values BEFORE modification
        String previousStatus =
                application.getStatus();

        String previousStage =
                application.getCurrentStage();

        // Update status
        if (status != null &&
                !status.isBlank()) {

            application.setStatus(status);
        }

        // Update stage
        if (currentStage != null &&
                !currentStage.isBlank()) {

            application.setCurrentStage(currentStage);
        }

        // Update remarks
        if (remarks != null) {
            application.setRemarks(remarks);
        }

        application.setUpdatedAt(
                LocalDateTime.now()
        );

        GovernmentApplication updated =
                applicationRepository.save(application);

        // -----------------------------------------------------
        // CREATE APPLICATION STATUS EVENT
        // -----------------------------------------------------

        boolean statusChanged =
                !equalsIgnoreCase(
                        previousStatus,
                        updated.getStatus()
                );

        boolean stageChanged =
                !equalsIgnoreCase(
                        previousStage,
                        updated.getCurrentStage()
                );

        boolean remarksChanged =
                remarks != null;

        if (statusChanged ||
                stageChanged ||
                remarksChanged) {

            String eventType;

            if (statusChanged &&
                    stageChanged) {

                eventType = "STATUS_AND_STAGE_UPDATED";

            } else if (statusChanged) {

                eventType = "STATUS_UPDATED";

            } else if (stageChanged) {

                eventType = "STAGE_UPDATED";

            } else {

                eventType = "REMARKS_UPDATED";
            }

            ApplicationEvent event =
                    new ApplicationEvent(
                            updated.getApplicationId(),
                            eventType,
                            previousStatus,
                            updated.getStatus(),
                            previousStage,
                            updated.getCurrentStage(),
                            updated.getRemarks()
                    );

            applicationEventRepository.save(event);
        }

        return new ApplicationResponse(updated);
    }

    // ---------------------------------------------------------
    // CASE-INSENSITIVE SAFE COMPARISON
    // ---------------------------------------------------------

    private boolean equalsIgnoreCase(
            String first,
            String second) {

        if (first == null && second == null) {
            return true;
        }

        if (first == null || second == null) {
            return false;
        }

        return first.equalsIgnoreCase(second);
    }

    // ---------------------------------------------------------
    // GENERATE UNIQUE APPLICATION ID
    // ---------------------------------------------------------

    private String generateApplicationId() {

        String applicationId;

        do {
            applicationId =
                    "APP-" +
                    UUID.randomUUID()
                            .toString()
                            .substring(0, 8)
                            .toUpperCase();

        } while (
                applicationRepository
                        .existsByApplicationId(applicationId)
        );

        return applicationId;
    }
}
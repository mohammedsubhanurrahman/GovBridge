package com.govbridge.backend.interoperability.controller;

import com.govbridge.backend.interoperability.dto.UnifiedInteroperabilityRequest;
import com.govbridge.backend.interoperability.dto.UnifiedInteroperabilityResponse;
import com.govbridge.backend.interoperability.service.UnifiedInteroperabilityWorkflowService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/interoperability")
public class UnifiedInteroperabilityController {

    private final UnifiedInteroperabilityWorkflowService workflowService;

    public UnifiedInteroperabilityController(
            UnifiedInteroperabilityWorkflowService workflowService) {

        this.workflowService =
                workflowService;
    }

    @PostMapping("/submit")
    public UnifiedInteroperabilityResponse submit(
            @RequestBody UnifiedInteroperabilityRequest request) {

        return workflowService.submit(request);
    }
}

package com.govbridge.backend.citizen.controller;

import com.govbridge.backend.citizen.dto.CitizenRegistrationRequest;
import com.govbridge.backend.citizen.dto.CitizenResponse;
import com.govbridge.backend.citizen.service.CitizenService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/citizens")
public class CitizenController {

    private final CitizenService citizenService;

    public CitizenController(
            CitizenService citizenService) {

        this.citizenService = citizenService;
    }

    /*
     * Register a new citizen.
     */
    @PostMapping("/register")
    public ResponseEntity<CitizenResponse> registerCitizen(
            @RequestBody CitizenRegistrationRequest request) {

        return ResponseEntity.ok(
                citizenService.registerCitizen(request)
        );
    }

    /*
     * Get all registered citizens.
     */
    @GetMapping
    public ResponseEntity<List<CitizenResponse>> getAllCitizens() {

        return ResponseEntity.ok(
                citizenService.getAllCitizens()
        );
    }

    /*
     * Get a citizen using the GovBridge citizen ID.
     */
    @GetMapping("/{citizenId}")
    public ResponseEntity<CitizenResponse> getCitizen(
            @PathVariable String citizenId) {

        return ResponseEntity.ok(
                citizenService.getCitizen(citizenId)
        );
    }

    /*
     * Find a citizen using their mobile number.
     */
    @GetMapping("/mobile/{mobileNumber}")
    public ResponseEntity<CitizenResponse> getCitizenByMobile(
            @PathVariable String mobileNumber) {

        return ResponseEntity.ok(
                citizenService.getCitizenByMobile(mobileNumber)
        );
    }
}
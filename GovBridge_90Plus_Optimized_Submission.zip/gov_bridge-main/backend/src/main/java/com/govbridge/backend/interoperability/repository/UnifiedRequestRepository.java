package com.govbridge.backend.interoperability.repository;

import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UnifiedRequestRepository
        extends JpaRepository<UnifiedRequest, Long> {

    Optional<UnifiedRequest> findByRequestId(String requestId);

    Optional<UnifiedRequest> findByExternalRequestId(
            String externalRequestId);
}
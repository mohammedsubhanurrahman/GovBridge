package com.govbridge.backend.consent;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
/**
 * Manages citizen consent records used to authorize traceable data exchange.
 */
public class ConsentService {

    private final ConsentRepository consentRepository;

    public ConsentService(
            ConsentRepository consentRepository) {

        this.consentRepository =
                consentRepository;
    }

    public ConsentRecord grantConsent(
            String citizenId,
            String requestId,
            String purpose,
            String department,
            String dataRequested) {

        if (citizenId == null || citizenId.isBlank()) {
            throw new IllegalArgumentException(
                    "Citizen ID is required."
            );
        }

        if (purpose == null || purpose.isBlank()) {
            throw new IllegalArgumentException(
                    "Consent purpose is required."
            );
        }

        if (department == null || department.isBlank()) {
            throw new IllegalArgumentException(
                    "Department is required."
            );
        }

        if (dataRequested == null ||
                dataRequested.isBlank()) {

            throw new IllegalArgumentException(
                    "Requested data must be specified."
            );
        }

        ConsentRecord record =
                new ConsentRecord();

        record.setCitizenId(
                citizenId.trim()
        );

        record.setRequestId(
                requestId == null
                        ? null
                        : requestId.trim()
        );

        record.setPurpose(
                purpose.trim()
        );

        record.setDepartment(
                department.trim()
        );

        record.setDataRequested(
                dataRequested.trim()
        );

        record.setStatus(
                "GRANTED"
        );

        record.setGrantedAt(
                LocalDateTime.now()
        );

        return consentRepository.save(record);
    }

    public ConsentRecord revokeConsent(
            Long consentId) {

        ConsentRecord record =
                consentRepository.findById(consentId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Consent record not found: "
                                                + consentId
                                )
                        );

        record.setStatus("REVOKED");

        record.setRevokedAt(
                LocalDateTime.now()
        );

        return consentRepository.save(record);
    }

    public boolean hasActiveConsent(
            String requestId) {

        if (requestId == null ||
                requestId.isBlank()) {

            return false;
        }

        return consentRepository
                .findByRequestIdAndStatus(
                        requestId.trim(),
                        "GRANTED"
                )
                .isPresent();
    }

    public boolean hasActiveConsentForCitizen(
            String citizenId,
            String department) {

        if (citizenId == null ||
                citizenId.isBlank() ||
                department == null ||
                department.isBlank()) {

            return false;
        }

        return consentRepository
                .findByCitizenIdAndDepartmentAndStatus(
                        citizenId.trim(),
                        department.trim(),
                        "GRANTED"
                )
                .isPresent();
    }

    public List<ConsentRecord> getByCitizen(
            String citizenId) {

        return consentRepository
                .findByCitizenId(
                        citizenId
                );
    }

    public List<ConsentRecord> getByRequest(
            String requestId) {

        return consentRepository
                .findByRequestId(
                        requestId
                );
    }

    public List<ConsentRecord> getAll() {

        return consentRepository.findAll();
    }
}

package com.govbridge.backend.interoperability.integration;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;

/**
 * Common contract used by GovBridge to communicate with a government system.
 *
 * The existing MunicipalRequest/UnifiedRequest signatures are intentionally
 * preserved so current integrations remain compatible while the connector
 * registry is introduced around them.
 */
public interface GovernmentSystemAdapter {

    String getDepartment();

    boolean supports(MunicipalRequest request);

    UnifiedRequest submit(MunicipalRequest request);

    /** Stable machine-readable connector code. */
    default String getSystemCode() {
        return getDepartment();
    }

    /** Human-readable name shown by the monitoring/dashboard layer. */
    default String getSystemName() {
        return getDepartment() + " Government System";
    }

    /** Protocol used by the external system in this prototype. */
    default String getProtocol() {
        return "REST";
    }

    /** Whether the connector is enabled for routing. */
    default boolean isEnabled() {
        return true;
    }
}

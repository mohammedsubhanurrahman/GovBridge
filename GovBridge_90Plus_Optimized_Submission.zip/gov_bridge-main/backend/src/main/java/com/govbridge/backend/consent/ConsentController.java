package com.govbridge.backend.consent;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consent")
public class ConsentController {

    private final ConsentService consentService;

    public ConsentController(
            ConsentService consentService) {

        this.consentService =
                consentService;
    }

    @PostMapping("/grant")
    public ConsentRecord grantConsent(
            @RequestBody ConsentRequest request) {

        return consentService.grantConsent(
                request.citizenId(),
                request.requestId(),
                request.purpose(),
                request.department(),
                request.dataRequested()
        );
    }

    @PostMapping("/revoke/{consentId}")
    public ConsentRecord revokeConsent(
            @PathVariable Long consentId) {

        return consentService.revokeConsent(
                consentId
        );
    }

    @GetMapping("/check/{requestId}")
    public boolean checkConsent(
            @PathVariable String requestId) {

        return consentService.hasActiveConsent(
                requestId
        );
    }

    @GetMapping("/citizen/{citizenId}")
    public List<ConsentRecord> getByCitizen(
            @PathVariable String citizenId) {

        return consentService.getByCitizen(
                citizenId
        );
    }

    @GetMapping("/request/{requestId}")
    public List<ConsentRecord> getByRequest(
            @PathVariable String requestId) {

        return consentService.getByRequest(
                requestId
        );
    }

    @GetMapping
    public List<ConsentRecord> getAll() {

        return consentService.getAll();
    }

    public record ConsentRequest(
            String citizenId,
            String requestId,
            String purpose,
            String department,
            String dataRequested
    ) {
    }
}

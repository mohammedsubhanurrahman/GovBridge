package com.govbridge.backend.interoperability.canonical.controller;

import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationRequest;
import com.govbridge.backend.interoperability.canonical.model.InteroperabilityTransformationResponse;
import com.govbridge.backend.interoperability.canonical.service.InteroperabilityTransformationService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/interoperability/transformation")
public class InteroperabilityTransformationController {

    private final InteroperabilityTransformationService transformationService;

    public InteroperabilityTransformationController(
            InteroperabilityTransformationService transformationService) {

        this.transformationService =
                transformationService;
    }

    @PostMapping
    public InteroperabilityTransformationResponse transform(
            @RequestBody CanonicalNormalizationRequest request) {

        return transformationService.transform(request);
    }
}

package com.govbridge.backend.application.dto;

import com.govbridge.backend.application.entity.GovernmentApplication;

import java.time.LocalDateTime;

public class ApplicationResponse {

    private String applicationId;
    private String citizenId;

    private String serviceCode;
    private String serviceName;
    private String department;

    private String state;
    private String district;
    private String mandal;
    private String village;

    private String status;
    private String currentStage;
    private String assignedDepartment;
    private String remarks;

    private LocalDateTime submittedAt;
    private LocalDateTime updatedAt;

    public ApplicationResponse() {
    }

    public ApplicationResponse(GovernmentApplication application) {

        this.applicationId = application.getApplicationId();
        this.citizenId = application.getCitizenId();

        this.serviceCode = application.getServiceCode();
        this.serviceName = application.getServiceName();
        this.department = application.getDepartment();

        this.state = application.getState();
        this.district = application.getDistrict();
        this.mandal = application.getMandal();
        this.village = application.getVillage();

        this.status = application.getStatus();
        this.currentStage = application.getCurrentStage();
        this.assignedDepartment =
                application.getAssignedDepartment();

        this.remarks = application.getRemarks();

        this.submittedAt = application.getSubmittedAt();
        this.updatedAt = application.getUpdatedAt();
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getCitizenId() {
        return citizenId;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getDepartment() {
        return department;
    }

    public String getState() {
        return state;
    }

    public String getDistrict() {
        return district;
    }

    public String getMandal() {
        return mandal;
    }

    public String getVillage() {
        return village;
    }

    public String getStatus() {
        return status;
    }

    public String getCurrentStage() {
        return currentStage;
    }

    public String getAssignedDepartment() {
        return assignedDepartment;
    }

    public String getRemarks() {
        return remarks;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
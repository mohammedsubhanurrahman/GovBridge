package com.govbridge.backend.interoperability.controller;

import com.govbridge.backend.interoperability.registry.ConnectorDefinition;
import com.govbridge.backend.interoperability.registry.ConnectorRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/interoperability/connectors")
public class ConnectorRegistryController {

    private final ConnectorRegistry connectorRegistry;

    public ConnectorRegistryController(ConnectorRegistry connectorRegistry) {
        this.connectorRegistry = connectorRegistry;
    }

    @GetMapping
    public List<ConnectorDefinition> getConnectors() {
        return connectorRegistry.describeAll();
    }
}
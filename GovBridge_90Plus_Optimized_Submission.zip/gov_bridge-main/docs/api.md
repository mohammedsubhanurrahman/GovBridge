# GovBridge API Surface

Representative endpoints in the current backend:

| Area | Endpoint | Purpose |
|---|---|---|
| Routing | `POST /api/routing/analyze` | Analyze request intent and route to a department |
| Interoperability | `POST /api/interoperability/submit` | Submit a unified government request |
| Connectors | `GET /api/interoperability/connectors` | List registered government-system connectors |
| Tracking | `GET /api/interoperability/tracking/{requestId}` | Retrieve unified request tracking |
| Audit | `GET /api/audit/{requestId}` | Retrieve request audit history |
| Consent | `/api/consent/*` | Manage citizen consent records |
| AI | `POST /predict` | Optional AI-service classification |
| AI health | `GET /health` | Deployment health probe for AI service |

The exact request/response DTOs are defined in the source tree. Production deployments should place authentication, authorization, rate limiting and gateway controls in front of public endpoints.

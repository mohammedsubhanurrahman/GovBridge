package com.govbridge.backend.interoperability.registry;

import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Central registry for GovBridge government-system connectors.
 *
 * Spring discovers all GovernmentSystemAdapter implementations and this
 * registry indexes them by department/system code. The orchestrator therefore
 * does not need a hard-coded switch for every department.
 */
@Component
/**
 * Registry of enabled government-system adapters used for interoperability routing.
 * The registry keeps department-specific integrations behind a common contract.
 */
public class ConnectorRegistry {

    private final Map<String, GovernmentSystemAdapter> connectors = new LinkedHashMap<>();

    public ConnectorRegistry(List<GovernmentSystemAdapter> adapters) {
        for (GovernmentSystemAdapter adapter : adapters) {
            register(adapter);
        }
    }

    private void register(GovernmentSystemAdapter adapter) {
        if (adapter == null || !adapter.isEnabled()) {
            return;
        }

        connectors.put(normalize(adapter.getSystemCode()), adapter);
        connectors.putIfAbsent(normalize(adapter.getDepartment()), adapter);
    }

    public GovernmentSystemAdapter getBySystemCode(String systemCode) {
        if (systemCode == null || systemCode.isBlank()) {
            return null;
        }
        return connectors.get(normalize(systemCode));
    }

    public GovernmentSystemAdapter getByDepartment(String department) {
        return getBySystemCode(department);
    }

    public boolean hasConnector(String systemCode) {
        return getBySystemCode(systemCode) != null;
    }

    public Collection<GovernmentSystemAdapter> getAll() {
        return List.copyOf(new java.util.LinkedHashSet<>(connectors.values()));
    }

    public List<ConnectorDefinition> describeAll() {
        return getAll().stream()
                .map(adapter -> new ConnectorDefinition(
                        adapter.getSystemCode(),
                        adapter.getSystemName(),
                        adapter.getDepartment(),
                        adapter.getProtocol(),
                        adapter.getClass().getSimpleName(),
                        adapter.isEnabled(),
                        "SIMULATED"
                ))
                .toList();
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }
}

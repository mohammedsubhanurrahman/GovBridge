package com.govbridge.backend.interoperability.revenue.controller;

import com.govbridge.backend.interoperability.revenue.dto.RevenueRequest;
import com.govbridge.backend.interoperability.revenue.dto.RevenueResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/mock/revenue")
public class RevenueMockController {

    @PostMapping("/applications")
    public ResponseEntity<RevenueResponse> createApplication(
            @RequestBody RevenueRequest request) {

        String applicationId =
                "REV-" +
                UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        RevenueResponse response =
                new RevenueResponse(
                        applicationId,
                        "PENDING",
                        "Revenue Department",
                        "Mandal Revenue Office",
                        "Application successfully registered in Revenue System"
                );

        return ResponseEntity.ok(response);
    }
}
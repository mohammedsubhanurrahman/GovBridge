import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowLeft,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Filter,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { getGrievances, updateGrievanceStatus } from "./api";
import "./AdminDashboard.css";

const STATUS_OPTIONS = ["ALL", "SUBMITTED", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"];
const PRIORITY_OPTIONS = ["ALL", "HIGH", "MEDIUM", "LOW"];

function formatStatus(status) {
  return String(status || "SUBMITTED").replaceAll("_", " ");
}

function formatId(id) {
  return `GB-${String(id).padStart(6, "0")}`;
}

function AdminDashboard({ onBack }) {
  const [grievances, setGrievances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [priorityFilter, setPriorityFilter] = useState("ALL");
  const [selected, setSelected] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  async function loadGrievances(showRefresh = false) {
    try {
      showRefresh ? setRefreshing(true) : setLoading(true);
      setError("");
      const result = await getGrievances();
      setGrievances(Array.isArray(result) ? result : []);
    } catch (loadError) {
      console.error(loadError);
      setError("Unable to load grievances. Make sure the backend is running on port 8081.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    loadGrievances();
  }, []);

  const stats = useMemo(() => {
    const count = (status) => grievances.filter((g) => String(g.status).toUpperCase() === status).length;
    return {
      total: grievances.length,
      submitted: count("SUBMITTED"),
      assigned: count("ASSIGNED"),
      progress: count("IN_PROGRESS"),
      resolved: count("RESOLVED"),
      closed: count("CLOSED"),
    };
  }, [grievances]);

  const filteredGrievances = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    return [...grievances]
      .filter((g) => statusFilter === "ALL" || String(g.status).toUpperCase() === statusFilter)
      .filter((g) => priorityFilter === "ALL" || String(g.priority).toUpperCase() === priorityFilter)
      .filter((g) => {
        if (!query) return true;
        return [
          g.id,
          g.title,
          g.description,
          g.department,
          g.category,
          g.assignedAuthority,
          g.jurisdiction,
        ].some((value) => String(value ?? "").toLowerCase().includes(query));
      })
      .sort((a, b) => Number(b.id) - Number(a.id));
  }, [grievances, searchTerm, statusFilter, priorityFilter]);

  async function handleStatusChange(id, status) {
    try {
      setUpdatingId(id);
      const updated = await updateGrievanceStatus(id, status);
      setGrievances((current) => current.map((g) => (g.id === id ? updated : g)));
      setSelected((current) => (current?.id === id ? updated : current));
    } catch (updateError) {
      console.error(updateError);
      setError(updateError.message || "Unable to update grievance status.");
    } finally {
      setUpdatingId(null);
    }
  }

  return (
    <section className="admin-page">
      <div className="admin-shell">
        <div className="admin-topbar">
          <button className="admin-back" onClick={onBack}>
            <ArrowLeft size={17} /> Back to Citizen Portal
          </button>
          <div className="admin-role">
            <ShieldCheck size={17} /> Officer / Admin Console
          </div>
        </div>

        <div className="admin-heading">
          <div>
            <div className="admin-eyebrow"><Sparkles size={14} /> GOVERNANCE OPERATIONS CENTER</div>
            <h1>Grievance Command Center</h1>
            <p>Monitor citizen complaints, inspect AI routing decisions and move cases through the resolution lifecycle.</p>
          </div>
          <button className="admin-refresh" onClick={() => loadGrievances(true)} disabled={refreshing}>
            <RefreshCw size={17} className={refreshing ? "spin" : ""} />
            {refreshing ? "Refreshing..." : "Refresh Data"}
          </button>
        </div>

        <div className="admin-stat-grid">
          <Stat icon={BarChart3} label="Total Cases" value={stats.total} />
          <Stat icon={Clock3} label="Submitted" value={stats.submitted} />
          <Stat icon={Activity} label="Assigned" value={stats.assigned} />
          <Stat icon={Activity} label="In Progress" value={stats.progress} />
          <Stat icon={CheckCircle2} label="Resolved" value={stats.resolved} />
          <Stat icon={CheckCircle2} label="Closed" value={stats.closed} />
        </div>

        <div className="admin-toolbar">
          <div className="admin-search">
            <Search size={18} />
            <input value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search ID, title, department, authority..." />
          </div>
          <div className="admin-filter"><Filter size={16} /><select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>{STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s === "ALL" ? "All Statuses" : formatStatus(s)}</option>)}</select><ChevronDown size={15} /></div>
          <div className="admin-filter"><select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>{PRIORITY_OPTIONS.map((p) => <option key={p} value={p}>{p === "ALL" ? "All Priorities" : p}</option>)}</select><ChevronDown size={15} /></div>
        </div>

        {error && <div className="admin-error">{error}</div>}

        {loading ? (
          <div className="admin-empty"><RefreshCw className="spin" size={25} /><strong>Loading grievance intelligence...</strong><span>Connecting to the GovBridge backend.</span></div>
        ) : filteredGrievances.length === 0 ? (
          <div className="admin-empty"><Search size={25} /><strong>No grievances found</strong><span>Try changing your search or filters.</span></div>
        ) : (
          <div className="grievance-table-wrap">
            <div className="table-caption"><span>LIVE CASE REGISTER</span><strong>{filteredGrievances.length} case{filteredGrievances.length === 1 ? "" : "s"}</strong></div>
            <div className="grievance-table">
              <div className="table-head"><span>ID</span><span>GRIEVANCE</span><span>ROUTING</span><span>PRIORITY</span><span>STATUS</span><span>ACTION</span></div>
              {filteredGrievances.map((g) => (
                <div className="table-row" key={g.id}>
                  <div className="case-id">{formatId(g.id)}</div>
                  <div className="case-main"><strong>{g.title}</strong><span>{g.department} · {g.category || "Unclassified"}</span></div>
                  <div className="routing-cell"><strong>{g.assignedAuthority || "Pending"}</strong><span>{g.jurisdiction || "—"} · {g.routingConfidence != null ? `${Math.round(Number(g.routingConfidence) * 100)}% AI` : "No score"}</span></div>
                  <div><span className={`priority-badge ${String(g.priority || "").toLowerCase()}`}>{g.priority || "N/A"}</span></div>
                  <div><span className={`status-badge ${String(g.status || "").toLowerCase()}`}>{formatStatus(g.status)}</span></div>
                  <div className="row-actions"><select value={g.status} disabled={updatingId === g.id} onChange={(e) => handleStatusChange(g.id, e.target.value)}>{STATUS_OPTIONS.slice(1).map((s) => <option key={s} value={s}>{formatStatus(s)}</option>)}</select><button onClick={() => setSelected(g)}>View</button></div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {selected && (
        <div className="admin-modal-overlay" onClick={() => setSelected(null)}>
          <div className="admin-detail-modal" onClick={(e) => e.stopPropagation()}>
            <div className="detail-header"><div><span>CASE DETAILS</span><h2>{formatId(selected.id)}</h2></div><button onClick={() => setSelected(null)}><X size={20} /></button></div>
            <div className="detail-title"><span>{selected.category || "Grievance"}</span><h3>{selected.title}</h3></div>
            <p className="detail-description">{selected.description}</p>
            <div className="detail-grid">
              <Detail label="Department" value={selected.department} />
              <Detail label="Authority" value={selected.assignedAuthority} />
              <Detail label="Jurisdiction" value={selected.jurisdiction} />
              <Detail label="Priority" value={selected.priority} />
              <Detail label="AI Confidence" value={selected.routingConfidence != null ? `${Math.round(Number(selected.routingConfidence) * 100)}%` : "Not available"} />
              <Detail label="Created" value={selected.createdAt ? new Date(selected.createdAt).toLocaleString() : "Not available"} />
            </div>
            <div className="detail-routing"><Sparkles size={18} /><div><strong>AI Smart Routing</strong><span>Routing metadata is available directly from the backend for officer review.</span></div></div>
            <div className="detail-status"><label>Update case status</label><div className="detail-status-controls">{STATUS_OPTIONS.slice(1).map((s) => <button key={s} className={selected.status === s ? "active" : ""} disabled={updatingId === selected.id} onClick={() => handleStatusChange(selected.id, s)}>{formatStatus(s)}</button>)}</div></div>
          </div>
        </div>
      )}
    </section>
  );
}

function Stat({ icon: Icon, label, value }) {
  return <div className="admin-stat"><div className="admin-stat-icon"><Icon size={18} /></div><div><strong>{value}</strong><span>{label}</span></div></div>;
}

function Detail({ label, value }) {
  return <div className="detail-item"><span>{label}</span><strong>{value || "Not available"}</strong></div>;
}

export default AdminDashboard;

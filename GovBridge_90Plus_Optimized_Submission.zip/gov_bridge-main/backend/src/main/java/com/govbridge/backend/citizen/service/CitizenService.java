package com.govbridge.backend.citizen.service;

import com.govbridge.backend.citizen.dto.CitizenRegistrationRequest;
import com.govbridge.backend.citizen.dto.CitizenResponse;
import com.govbridge.backend.citizen.entity.Citizen;
import com.govbridge.backend.citizen.repository.CitizenRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class CitizenService {

    private final CitizenRepository citizenRepository;

    public CitizenService(CitizenRepository citizenRepository) {
        this.citizenRepository = citizenRepository;
    }

    /*
     * Register a new citizen.
     */
    public CitizenResponse registerCitizen(
            CitizenRegistrationRequest request) {

        if (request.getFullName() == null ||
                request.getFullName().isBlank()) {

            throw new IllegalArgumentException(
                    "Full name is required."
            );
        }

        if (request.getMobileNumber() == null ||
                request.getMobileNumber().isBlank()) {

            throw new IllegalArgumentException(
                    "Mobile number is required."
            );
        }

        if (request.getIdentityType() == null ||
                request.getIdentityType().isBlank()) {

            throw new IllegalArgumentException(
                    "Identity type is required."
            );
        }

        if (request.getState() == null ||
                request.getState().isBlank()) {

            throw new IllegalArgumentException(
                    "State is required."
            );
        }

        if (citizenRepository.existsByMobileNumber(
                request.getMobileNumber())) {

            throw new IllegalArgumentException(
                    "A citizen profile already exists for this mobile number."
            );
        }

        Citizen citizen = new Citizen();

        citizen.setCitizenId(
                "CIT-" +
                UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase()
        );

        citizen.setFullName(
                request.getFullName()
        );

        citizen.setMobileNumber(
                request.getMobileNumber()
        );

        citizen.setEmail(
                request.getEmail()
        );

        citizen.setIdentityType(
                request.getIdentityType()
        );

        /*
         * Prototype identity verification layer.
         *
         * A real government identity provider can
         * be connected through an adapter later.
         */
        citizen.setIdentityVerified(
                request.getVerificationReference() != null &&
                !request.getVerificationReference().isBlank()
        );

        citizen.setVerificationReference(
                request.getVerificationReference()
        );

        citizen.setState(
                request.getState()
        );

        citizen.setDistrict(
                request.getDistrict()
        );

        citizen.setMandal(
                request.getMandal()
        );

        citizen.setVillage(
                request.getVillage()
        );

        citizen.setPincode(
                request.getPincode()
        );

        citizen.setCitizenCategory(
                request.getCitizenCategory()
        );

        citizen.setStatus("ACTIVE");

        citizen.setCreatedAt(
                LocalDateTime.now()
        );

        Citizen savedCitizen =
                citizenRepository.save(citizen);

        return new CitizenResponse(savedCitizen);
    }

    /*
     * Get a single citizen by GovBridge citizen ID.
     */
    public CitizenResponse getCitizen(
            String citizenId) {

        Citizen citizen =
                citizenRepository
                        .findByCitizenId(citizenId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Citizen not found."
                                )
                        );

        return new CitizenResponse(citizen);
    }

    /*
     * Get all citizens.
     */
    public List<CitizenResponse> getAllCitizens() {

        return citizenRepository
                .findAll()
                .stream()
                .map(CitizenResponse::new)
                .toList();
    }

    /*
     * Find a citizen by mobile number.
     */
    public CitizenResponse getCitizenByMobile(
            String mobileNumber) {

        Citizen citizen =
                citizenRepository
                        .findByMobileNumber(mobileNumber)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Citizen not found for mobile number."
                                )
                        );

        return new CitizenResponse(citizen);
    }
}
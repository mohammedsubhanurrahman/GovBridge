/** Base API URL supplied by the deployment environment. */
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8081/api").replace(/\/$/, "");

/*
 * =========================================================
 * EXISTING GRIEVANCE APIs
 * =========================================================
 */

export async function getGrievances() {
  const response = await fetch(`${API_BASE_URL}/grievances`);

  if (!response.ok) {
    throw new Error("Failed to fetch grievances");
  }

  return response.json();
}

export async function getGrievanceById(id) {
  const response = await fetch(`${API_BASE_URL}/grievances/${id}`);

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error("Grievance not found");
    }

    throw new Error("Failed to fetch grievance");
  }

  return response.json();
}

export async function createGrievance(grievance) {
  const response = await fetch(`${API_BASE_URL}/grievances`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(grievance),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || "Failed to create grievance");
  }

  return response.json();
}

export async function updateGrievanceStatus(id, status) {
  const response = await fetch(
    `${API_BASE_URL}/grievances/${id}/status?status=${encodeURIComponent(
      status
    )}`,
    {
      method: "PATCH",
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || "Failed to update grievance status");
  }

  return response.json();
}

/*
 * =========================================================
 * APPLICATION EVENT HISTORY
 * =========================================================
 */

export async function getApplicationEvents(applicationId) {
  const response = await fetch(
    `${API_BASE_URL}/applications/${encodeURIComponent(
      applicationId
    )}/events`
  );

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error("Application events not found");
    }

    throw new Error("Failed to fetch application events");
  }

  return response.json();
}

/*
 * =========================================================
 * GOVBRIDGE INTEROPERABILITY APIs
 * =========================================================
 */

/*
 * Submit a unified government service request.
 *
 * Backend:
 * POST /api/interoperability/submit
 */
export async function submitInteroperabilityRequest(request) {
  const response = await fetch(
    `${API_BASE_URL}/interoperability/submit`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    }
  );

  if (!response.ok) {
    const errorText = await response.text();

    let message = errorText;

    try {
      const parsed = JSON.parse(errorText);
      message =
        parsed.message ||
        parsed.error ||
        errorText;
    } catch {
      // Backend may return plain text.
    }

    throw new Error(
      message ||
        "Unable to submit the government service request."
    );
  }

  return response.json();
}

/*
 * Get all connected government systems.
 *
 * Backend:
 * GET /api/interoperability/connectors
 */
export async function getConnectors() {
  const response = await fetch(
    `${API_BASE_URL}/interoperability/connectors`
  );

  if (!response.ok) {
    throw new Error(
      "Failed to load government connectors."
    );
  }

  return response.json();
}

/*
 * Get unified tracking information.
 *
 * Backend:
 * GET /api/interoperability/tracking/{requestId}
 */
export async function getInteroperabilityTracking(
  requestId
) {
  const cleanId = String(requestId || "").trim();

  const response = await fetch(
    `${API_BASE_URL}/interoperability/tracking/${encodeURIComponent(
      cleanId
    )}`
  );

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error(
        "GovBridge request not found."
      );
    }

    throw new Error(
      "Failed to fetch interoperability tracking."
    );
  }

  return response.json();
}

/*
 * Get audit history for a GovBridge request.
 *
 * Backend:
 * GET /api/audit/{requestId}
 */
export async function getAuditLogs(requestId) {
  const cleanId = String(requestId || "").trim();

  const response = await fetch(
    `${API_BASE_URL}/audit/${encodeURIComponent(
      cleanId
    )}`
  );

  if (!response.ok) {
    if (response.status === 404) {
      return [];
    }

    throw new Error(
      "Failed to fetch audit history."
    );
  }

  const result = await response.json();

  /*
   * Your backend currently returns:
   *
   * {
   *   value: [...],
   *   Count: 2
   * }
   *
   * Normalize it for the frontend.
   */
  if (Array.isArray(result)) {
    return result;
  }

  if (Array.isArray(result?.value)) {
    return result.value;
  }

  return [];
}

/*
 * =========================================================
 * EXTERNAL STATUS SYNCHRONIZATION
 * =========================================================
 */

export async function syncInteroperabilityStatus(
  externalRequestId,
  status
) {
  const cleanId = String(
    externalRequestId || ""
  ).trim();

  const response = await fetch(
    `${API_BASE_URL}/interoperability/tracking/sync/${encodeURIComponent(
      cleanId
    )}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        status,
      }),
    }
  );

  if (!response.ok) {
    const errorText = await response.text();

    throw new Error(
      errorText ||
        "Failed to synchronize external status."
    );
  }

  return response.json();
}

package com.govbridge.backend.citizen.dto;

import com.govbridge.backend.citizen.entity.Citizen;

import java.time.LocalDateTime;

public class CitizenResponse {

    private String citizenId;
    private String fullName;
    private String mobileNumber;
    private String email;

    private String identityType;
    private boolean identityVerified;

    private String state;
    private String district;
    private String mandal;
    private String village;
    private String pincode;

    private String citizenCategory;
    private String status;
    private LocalDateTime createdAt;

    public CitizenResponse() {
    }

    public CitizenResponse(Citizen citizen) {
        this.citizenId = citizen.getCitizenId();
        this.fullName = citizen.getFullName();
        this.mobileNumber = citizen.getMobileNumber();
        this.email = citizen.getEmail();
        this.identityType = citizen.getIdentityType();
        this.identityVerified = citizen.isIdentityVerified();
        this.state = citizen.getState();
        this.district = citizen.getDistrict();
        this.mandal = citizen.getMandal();
        this.village = citizen.getVillage();
        this.pincode = citizen.getPincode();
        this.citizenCategory = citizen.getCitizenCategory();
        this.status = citizen.getStatus();
        this.createdAt = citizen.getCreatedAt();
    }

    public String getCitizenId() {
        return citizenId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getIdentityType() {
        return identityType;
    }

    public boolean isIdentityVerified() {
        return identityVerified;
    }

    public String getState() {
        return state;
    }

    public String getDistrict() {
        return district;
    }

    public String getMandal() {
        return mandal;
    }

    public String getVillage() {
        return village;
    }

    public String getPincode() {
        return pincode;
    }

    public String getCitizenCategory() {
        return citizenCategory;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
# Testing Strategy

## Backend unit tests

The Spring Boot module contains tests for:

- application context loading
- electricity routing
- land/revenue routing
- empty-input routing boundary behavior
- connector registry indexing and lookup

Run with:

```bash
cd backend
./mvnw test
```

## AI service tests

Pytest fixtures cover:

- health endpoint
- representative electricity and land-record requests
- prediction output schema and confidence bounds
- empty-input human-review behavior
- input boundary validation

Run with:

```bash
cd ai-service
pytest -q
```

## Frontend validation

Run:

```bash
cd frontend
npm ci
npm run lint
npm run build
```

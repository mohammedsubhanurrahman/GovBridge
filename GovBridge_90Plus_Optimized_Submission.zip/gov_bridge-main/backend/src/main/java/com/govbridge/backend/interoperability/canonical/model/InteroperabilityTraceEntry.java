package com.govbridge.backend.interoperability.canonical.model;

import java.time.LocalDateTime;

public record InteroperabilityTraceEntry(
        int sequence,
        String stage,
        String status,
        String detail,
        LocalDateTime timestamp
) {
}

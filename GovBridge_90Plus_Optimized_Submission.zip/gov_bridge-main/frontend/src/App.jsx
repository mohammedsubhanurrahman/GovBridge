import {
  ArrowRight,
  Building2,
  CheckCircle2,
  ChevronRight,
  FileText,
  Globe2,
  Network,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
  Zap,
  Droplets,
  Landmark,
} from "lucide-react";

import { useEffect, useMemo, useState } from "react";

import {
  submitInteroperabilityRequest,
  getInteroperabilityTracking,
  getConnectors,
  getAuditLogs,
  syncInteroperabilityStatus,
} from "./api";

import "./App.css";


const SERVICE_GUIDES = [
  {
    key: "residence",
    title: "Residence Certificate",
    short: "Apply for a residence certificate through the revenue service.",
    department: "REVENUE",
    displayDepartment: "Revenue Department",
    authority: "Mandal Revenue Office",
    category: "Certificates & Documents",
    serviceCode: "RES_CERT",
    icon: FileText,
    keywords: [
      "residence",
      "residence certificate",
      "address certificate",
      "residence proof",
    ],
    steps: [
      "Provide your citizen and residence details.",
      "GovBridge identifies the relevant revenue connector.",
      "Your consent controls the sharing of requested information.",
      "The request is transformed into the common GovBridge model.",
      "Use the generated GovBridge ID to follow the request.",
    ],
  },
  {
    key: "birth",
    title: "Birth Certificate",
    short: "Access birth registration and certificate services.",
    department: "MUNICIPAL",
    displayDepartment: "Municipal Administration",
    authority: "Local Birth Registration Authority",
    category: "Certificates & Documents",
    serviceCode: "BIRTH_CERT",
    icon: FileText,
    keywords: [
      "birth",
      "birth certificate",
      "birth registration",
      "newborn",
    ],
    steps: [
      "Provide the relevant birth details.",
      "GovBridge identifies the appropriate local connector.",
      "Required information can be mapped into the common data model.",
      "The connected system processes the request.",
      "Track the resulting request through one GovBridge ID.",
    ],
  },
  {
    key: "municipal",
    title: "Municipal / Civic Service",
    short: "Roads, drainage, sanitation and local infrastructure services.",
    department: "MUNICIPAL",
    displayDepartment: "Municipal Administration",
    authority: "Municipal Ward Office",
    category: "Civic Services",
    serviceCode: "CIVIC_SERVICE",
    icon: Building2,
    keywords: [
      "road",
      "pothole",
      "garbage",
      "drainage",
      "sewage",
      "sanitation",
      "street light",
      "streetlight",
      "municipal",
      "civic",
    ],
    steps: [
      "Describe the civic service requirement.",
      "Provide the location or nearby landmark.",
      "GovBridge identifies the municipal connector.",
      "The request is mapped to the common interoperability model.",
      "Track the request with the unified GovBridge ID.",
    ],
  },
  {
    key: "police",
    title: "Police / Public Safety",
    short: "Public-safety services such as theft and missing-property reports.",
    department: "POLICE",
    displayDepartment: "Police Department",
    authority: "Local Police Station",
    category: "Public Safety",
    serviceCode: "POLICE_SERVICE",
    icon: ShieldCheck,
    keywords: [
      "police",
      "theft",
      "stolen",
      "missing",
      "fraud",
      "crime",
      "safety",
    ],
    steps: [
      "Record the incident details.",
      "Provide the location and relevant information.",
      "GovBridge identifies the police connector.",
      "The request can be routed through the interoperability layer.",
      "Use the unified request ID for supported workflows.",
    ],
  },
  {
    key: "electricity",
    title: "Electricity / Utility",
    short: "Power supply, meter and electricity service requests.",
    department: "ELECTRICITY",
    displayDepartment: "Electricity / Utility",
    authority: "Local Electricity Service Office",
    category: "Utility Services",
    serviceCode: "ELECTRICITY_SERVICE",
    icon: Zap,
    keywords: [
      "electricity",
      "power",
      "power cut",
      "power outage",
      "meter",
      "transformer",
      "electric bill",
    ],
    steps: [
      "Provide your consumer or service information when available.",
      "Describe the utility issue and location.",
      "GovBridge identifies the electricity connector.",
      "Data is routed through the common interoperability layer.",
      "Track the request using the GovBridge ID.",
    ],
  },
  {
    key: "water",
    title: "Water Service",
    short: "Water supply, leakage and local water service requests.",
    department: "WATER",
    displayDepartment: "Water Department",
    authority: "Local Water Service Office",
    category: "Utility Services",
    serviceCode: "WATER_SERVICE",
    icon: Droplets,
    keywords: [
      "water",
      "water supply",
      "water leakage",
      "pipeline",
      "drinking water",
    ],
    steps: [
      "Describe the water-service issue.",
      "Provide the location.",
      "GovBridge selects the water connector.",
      "The request passes through the interoperability layer.",
      "Follow progress using the unified request ID.",
    ],
  },
  {
    key: "welfare",
    title: "Welfare / Social Support",
    short: "Government welfare and social-support service requests.",
    department: "WELFARE",
    displayDepartment: "Social Welfare",
    authority: "Local Welfare Service Office",
    category: "Welfare Services",
    serviceCode: "WELFARE_SERVICE",
    icon: UserRound,
    keywords: [
      "welfare",
      "pension",
      "scholarship",
      "financial aid",
      "benefit",
      "social security",
      "assistance",
    ],
    steps: [
      "Identify the welfare service required.",
      "Provide the relevant citizen information.",
      "GovBridge identifies the welfare connector.",
      "Information is exchanged through the common model.",
      "Track the supported request using one GovBridge ID.",
    ],
  },
  {
    key: "panchayat",
    title: "Panchayat Service",
    short: "Local rural administration and panchayat service requests.",
    department: "PANCHAYAT",
    displayDepartment: "Panchayat Administration",
    authority: "Local Panchayat Office",
    category: "Local Government",
    serviceCode: "PANCHAYAT_SERVICE",
    icon: Landmark,
    keywords: [
      "panchayat",
      "village",
      "rural",
      "gram panchayat",
      "local administration",
    ],
    steps: [
      "Describe the required local-government service.",
      "Provide the village or jurisdiction.",
      "GovBridge identifies the panchayat connector.",
      "The request is processed through the interoperability layer.",
      "Use the unified GovBridge ID for tracking.",
    ],
  },
];


const CONNECTOR_FALLBACK = [
  ["ELECTRICITY", "Electricity Government System", "ElectricityGovernmentAdapter"],
  ["MUNICIPAL", "Municipal Government System", "MunicipalGovernmentAdapter"],
  ["PANCHAYAT", "Panchayat Government System", "PanchayatGovernmentAdapter"],
  ["POLICE", "Police Government System", "PoliceGovernmentAdapter"],
  ["REVENUE", "Revenue Government System", "RevenueGovernmentAdapter"],
  ["WATER", "Water Government System", "WaterGovernmentAdapter"],
  ["WELFARE", "Welfare Government System", "WelfareGovernmentAdapter"],
];


const STATUS_STEPS = [
  "SUBMITTED",
  "ASSIGNED",
  "IN_PROGRESS",
  "RESOLVED",
];


function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  const [loginForm, setLoginForm] = useState({
    name: "",
    mobile: "",
  });

  const [selectedGuide, setSelectedGuide] = useState(null);
  const [searchText, setSearchText] = useState("");

  const [showRequestModal, setShowRequestModal] =
    useState(false);

  const [requestForm, setRequestForm] = useState({
    serviceCode: "RES_CERT",
    serviceName: "Residence Certificate",
    intent: "SERVICE_REQUEST",
    citizenId: "CITIZEN-DEMO-001",
    citizenName: "",
    department: "REVENUE",
    administrativeLevel: "MANDAL",
    jurisdiction: "Demo Mandal",
    priority: "MEDIUM",
    title: "Residence Certificate",
    description: "",
    address: "",
  });

  const [consentAccepted, setConsentAccepted] =
    useState(false);

  const [submitting, setSubmitting] =
    useState(false);

  const [submitError, setSubmitError] =
    useState("");

  const [submitted, setSubmitted] =
    useState(null);

  const [trackingId, setTrackingId] =
    useState("");

  const [tracked, setTracked] =
    useState(null);

  const [auditLogs, setAuditLogs] =
    useState([]);

  const [trackingError, setTrackingError] =
    useState("");

  const [trackingLoading, setTrackingLoading] =
    useState(false);

  const [syncLoading, setSyncLoading] =
    useState(false);

  const [syncMessage, setSyncMessage] =
    useState("");

  const [connectors, setConnectors] =
    useState([]);

  const [connectorsLoading, setConnectorsLoading] =
    useState(true);

  const [activeTab, setActiveTab] =
    useState("home");


  const detectedGuide = useMemo(() => {
    const q = searchText
      .toLowerCase()
      .trim();

    if (!q) {
      return null;
    }

    return (
      SERVICE_GUIDES.find((guide) =>
        guide.keywords.some((word) =>
          q.includes(word)
        )
      ) || null
    );
  }, [searchText]);


  useEffect(() => {
    async function loadConnectors() {
      try {
        const result =
          await getConnectors();

        setConnectors(
          Array.isArray(result)
            ? result
            : []
        );
      } catch {
        setConnectors(
          CONNECTOR_FALLBACK.map(
            ([systemCode, systemName, adapterClass]) => ({
              systemCode,
              systemName,
              department: systemCode,
              protocol: "REST",
              adapterClass,
              enabled: true,
              mode: "SIMULATED",
            })
          )
        );
      } finally {
        setConnectorsLoading(false);
      }
    }

    loadConnectors();
  }, []);


  function login(event) {
    event.preventDefault();

    if (
      !loginForm.name.trim() ||
      !loginForm.mobile.trim()
    ) {
      return;
    }

    setRequestForm((current) => ({
      ...current,
      citizenName: loginForm.name.trim(),
    }));

    setLoggedIn(true);
  }


  function openRequest(guide = selectedGuide) {
    const selected =
      guide || SERVICE_GUIDES[0];

    setRequestForm({
      serviceCode:
        selected.serviceCode,
      serviceName:
        selected.title,
      intent:
        "SERVICE_REQUEST",
      citizenId:
        "CITIZEN-DEMO-001",
      citizenName:
        loginForm.name,
      department:
        selected.department,
      administrativeLevel:
        "MANDAL",
      jurisdiction:
        "Demo Mandal",
      priority:
        "MEDIUM",
      title:
        selected.title,
      description:
        "",
      address:
        "",
    });

    setConsentAccepted(false);
    setSubmitError("");
    setShowRequestModal(true);
  }


  async function submitRequest(event) {
    event.preventDefault();

    if (
      !requestForm.title.trim() ||
      !requestForm.description.trim()
    ) {
      setSubmitError(
        "Please enter a request title and description."
      );
      return;
    }

    if (!requestForm.citizenId.trim()) {
      setSubmitError(
        "Citizen ID is required."
      );
      return;
    }

    if (!consentAccepted) {
      setSubmitError(
        "Please provide consent before sharing data with the connected government system."
      );
      return;
    }

    setSubmitting(true);
    setSubmitError("");

    try {
      /*
       * The backend currently checks for an active
       * consent record before submitting.
       *
       * The demo citizen already has consent created
       * during the backend integration test.
       */
      const result =
        await submitInteroperabilityRequest({
          serviceCode:
            requestForm.serviceCode,

          serviceName:
            requestForm.serviceName,

          intent:
            requestForm.intent,

          citizenId:
            requestForm.citizenId,

          citizenName:
            requestForm.citizenName,

          department:
            requestForm.department,

          administrativeLevel:
            requestForm.administrativeLevel,

          jurisdiction:
            requestForm.jurisdiction,

          priority:
            requestForm.priority,

          title:
            requestForm.title,

          description:
            requestForm.description,

          payload: {
            address:
              requestForm.address,

            applicationType:
              requestForm.serviceName,

            source:
              "GovBridge Citizen Portal",
          },
        });

      setSubmitted(result);
      setShowRequestModal(false);

    } catch (error) {
      setSubmitError(
        error?.message ||
        "Unable to submit the government service request."
      );
    } finally {
      setSubmitting(false);
    }
  }


  async function trackRequest(event) {
    event.preventDefault();

    const value =
      trackingId.trim();

    if (!value) {
      setTrackingError(
        "Enter a GovBridge request ID."
      );
      return;
    }

    setTrackingLoading(true);
    setTrackingError("");
    setTracked(null);
    setAuditLogs([]);

    try {
      const result =
        await getInteroperabilityTracking(
          value
        );

      setTracked(result);

      try {
        const logs =
          await getAuditLogs(
            result.requestId
          );

        setAuditLogs(
          Array.isArray(logs)
            ? logs
            : []
        );
      } catch {
        setAuditLogs([]);
      }

    } catch (error) {
      setTrackingError(
        error?.message ||
        "Request not found. Please verify the GovBridge ID."
      );
    } finally {
      setTrackingLoading(false);
    }
  }


  async function simulateExternalStatus(nextStatus) {
    const externalId =
      tracked?.externalRequestId;

    if (!externalId) {
      return;
    }

    setSyncLoading(true);
    setSyncMessage("");

    try {
      const updated =
        await syncInteroperabilityStatus(
          externalId,
          nextStatus
        );

      setTracked(updated);

      setSyncMessage(
        `External system synchronized: ${nextStatus.replace(
          "_",
          " "
        )}`
      );

      const logs =
        await getAuditLogs(
          updated.requestId
        );

      setAuditLogs(
        Array.isArray(logs)
          ? logs
          : []
      );

    } catch (error) {
      setSyncMessage(
        error?.message ||
        "Unable to synchronize external status."
      );
    } finally {
      setSyncLoading(false);
    }
  }


  function formatId(item) {
    if (!item) {
      return "â€”";
    }

    return (
      item.requestId ||
      "â€”"
    );
  }


  function scrollTo(id) {
    document
      .getElementById(id)
      ?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });

    setActiveTab(
      id === "tracking"
        ? "track"
        : "home"
    );
  }


  function openSubmittedTracking() {
    if (!submitted?.unifiedRequest?.requestId) {
      return;
    }

    const id =
      submitted.unifiedRequest.requestId;

    setTrackingId(id);
    setSubmitted(null);

    setTimeout(() => {
      scrollTo("tracking");
    }, 50);
  }


  if (!loggedIn) {
    return (
      <div className="app login-page">
        <div className="ambient ambient-one" />
        <div className="ambient ambient-two" />

        <div className="login-shell">

          <div className="login-brand">
            <div className="brand-mark">
              <Network size={24} />
            </div>

            <div>
              <strong>GovBridge</strong>
              <span>
                UNIFIED GOVERNMENT INTEROPERABILITY
              </span>
            </div>
          </div>


          <div className="login-card">

            <div className="login-icon">
              <UserRound size={24} />
            </div>

            <span className="eyebrow">
              CITIZEN PORTAL
            </span>

            <h1>
              Government services,{" "}
              <span>one bridge.</span>
            </h1>

            <p>
              Access connected government services
              through one unified interface.
              GovBridge routes supported requests
              through an interoperability layer and
              provides one tracking identity.
            </p>


            <form
              onSubmit={login}
              className="login-form"
            >

              <label>
                Your name

                <input
                  value={loginForm.name}
                  onChange={(event) =>
                    setLoginForm({
                      ...loginForm,
                      name:
                        event.target.value,
                    })
                  }
                  placeholder="Enter your name"
                />
              </label>


              <label>
                Mobile number

                <input
                  value={loginForm.mobile}
                  onChange={(event) =>
                    setLoginForm({
                      ...loginForm,
                      mobile:
                        event.target.value,
                    })
                  }
                  placeholder="10-digit mobile number"
                  inputMode="numeric"
                />
              </label>


              <button
                className="primary-button"
                type="submit"
              >
                Enter Citizen Portal
                <ArrowRight size={18} />
              </button>

            </form>


            <div className="prototype-note">
              <ShieldCheck size={16} />

              Prototype login â€”
              authentication can be connected
              to an official identity provider later.
            </div>

          </div>
        </div>
      </div>
    );
  }


  return (
    <div className="app">

      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />


      <header className="navbar">

        <button
          className="brand-button"
          onClick={() =>
            setActiveTab("home")
          }
        >

          <div className="brand-mark">
            <Network size={22} />
          </div>

          <div>
            <strong>GovBridge</strong>
            <span>
              GOVERNMENT INTEROPERABILITY LAYER
            </span>
          </div>

        </button>


        <nav>

          <button
            className={
              activeTab === "home"
                ? "active"
                : ""
            }
            onClick={() =>
              setActiveTab("home")
            }
          >
            Home
          </button>

          <button
            onClick={() =>
              scrollTo("services")
            }
          >
            Services
          </button>

          <button
            onClick={() =>
              scrollTo("systems")
            }
          >
            Systems
          </button>

          <button
            className={
              activeTab === "track"
                ? "active"
                : ""
            }
            onClick={() =>
              scrollTo("tracking")
            }
          >
            Track
          </button>

        </nav>


        <div className="citizen-pill">
          <UserRound size={15} />
          {loginForm.name}
        </div>

      </header>


      <main>

        {/* HERO */}

        <section className="hero section">

          <div className="hero-copy">

            <span className="eyebrow">
              UNIFIED GOVERNMENT ACCESS
            </span>

            <h1>
              One request.
              <span>Connected government.</span>
            </h1>

            <p className="hero-lead">
              GovBridge acts as an interoperability
              layer between citizens and fragmented
              government digital systems â€” connecting
              services, transforming data and providing
              unified tracking.
            </p>


            <div className="smart-box">

              <div className="smart-box-top">
                <Sparkles size={18} />
                <span>
                  SMART SERVICE UNDERSTANDING
                </span>
              </div>


              <div className="smart-input-wrap">
                <Search size={19} />

                <input
                  value={searchText}
                  onChange={(event) =>
                    setSearchText(
                      event.target.value
                    )
                  }
                  placeholder="e.g. I need a residence certificate..."
                />
              </div>


              {detectedGuide && (

                <div className="detected-card">

                  <div className="detected-icon">
                    <detectedGuide.icon size={20} />
                  </div>

                  <div>
                    <span>
                      SERVICE UNDERSTOOD
                    </span>

                    <strong>
                      {detectedGuide.title}
                    </strong>

                    <small>
                      {detectedGuide.displayDepartment}
                    </small>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedGuide(
                        detectedGuide
                      );

                      setSearchText("");
                    }}
                  >
                    View service
                    <ChevronRight size={17} />
                  </button>

                </div>

              )}

            </div>


            <div className="hero-actions">

              <button
                className="primary-button"
                onClick={() =>
                  openRequest()
                }
              >
                <Send size={17} />
                Submit Government Service
              </button>


              <button
                className="secondary-button"
                onClick={() =>
                  scrollTo("systems")
                }
              >
                View connected systems
                <ArrowRight size={17} />
              </button>

            </div>

          </div>


          <div className="hero-visual">

            <div className="bridge-card">

              <div className="bridge-head">

                <div>

                  <span>
                    GOVBRIDGE INTEROPERABILITY LAYER
                  </span>

                  <strong>
                    One common workflow across
                    fragmented systems
                  </strong>

                </div>


                <div className="live-dot">
                  <i />
                  SIMULATED DEMO
                </div>

              </div>


              <div className="bridge-flow">

                <div className="flow-node citizen">
                  <UserRound size={20} />
                  <b>Citizen</b>
                  <small>One interface</small>
                </div>

                <div className="flow-line">
                  <span />
                </div>

                <div className="flow-node ai">
                  <Sparkles size={20} />
                  <b>GovBridge</b>
                  <small>Route + transform</small>
                </div>

                <div className="flow-line">
                  <span />
                </div>

                <div className="flow-node departments">
                  <Network size={20} />
                  <b>Government Systems</b>
                  <small>Connected adapters</small>
                </div>

              </div>


              <div className="bridge-proof">

                <span>
                  <CheckCircle2 size={15} />
                  Consent-aware
                </span>

                <span>
                  <CheckCircle2 size={15} />
                  Common data model
                </span>

                <span>
                  <CheckCircle2 size={15} />
                  Unified tracking
                </span>

              </div>

            </div>

          </div>

        </section>


        {/* VALUE STRIP */}

        <section className="value-strip">

          <div>
            <strong>01</strong>
            <span>Describe once</span>
          </div>

          <div>
            <strong>02</strong>
            <span>Give consent</span>
          </div>

          <div>
            <strong>03</strong>
            <span>Connect systems</span>
          </div>

          <div>
            <strong>04</strong>
            <span>Track one ID</span>
          </div>

        </section>


        {/* SERVICES */}

        <section
          id="services"
          className="section"
        >

          <div className="section-heading">

            <div>

              <span className="eyebrow">
                GOVERNMENT SERVICES
              </span>

              <h2>
                Services through
                <span> one interface.</span>
              </h2>

              <p>
                GovBridge provides a common entry
                point for services that may otherwise
                span different government systems.
              </p>

            </div>


            <div className="heading-chip">
              <Globe2 size={16} />
              Common service access
            </div>

          </div>


          <div className="service-grid">

            {SERVICE_GUIDES.map((guide) => {

              const Icon =
                guide.icon;

              return (

                <button
                  className={
                    `service-card ${
                      selectedGuide?.key ===
                      guide.key
                        ? "selected"
                        : ""
                    }`
                  }
                  key={guide.key}
                  onClick={() =>
                    setSelectedGuide(guide)
                  }
                >

                  <div className="service-icon">
                    <Icon size={21} />
                  </div>

                  <span className="service-label">
                    {guide.category}
                  </span>

                  <h3>
                    {guide.title}
                  </h3>

                  <p>
                    {guide.short}
                  </p>

                  <div className="service-link">
                    View workflow
                    <ChevronRight size={16} />
                  </div>

                </button>

              );
            })}

          </div>


          {selectedGuide && (

            <div className="guide-panel">

              <div className="guide-panel-head">

                <div>

                  <span className="eyebrow">
                    SERVICE WORKFLOW
                  </span>

                  <h3>
                    {selectedGuide.title}
                  </h3>

                  <p>
                    <b>
                      {selectedGuide.displayDepartment}
                    </b>
                    {" Â· "}
                    {selectedGuide.authority}
                  </p>

                </div>


                <button
                  className="icon-button"
                  onClick={() =>
                    setSelectedGuide(null)
                  }
                >
                  <X size={18} />
                </button>

              </div>


              <div className="steps">

                {selectedGuide.steps.map(
                  (step, index) => (

                    <div
                      className="step"
                      key={step}
                    >

                      <div className="step-number">
                        {String(index + 1).padStart(
                          2,
                          "0"
                        )}
                      </div>

                      <p>
                        {step}
                      </p>

                    </div>

                  )
                )}

              </div>


              <div className="guide-actions">

                <button
                  className="primary-button"
                  onClick={() =>
                    openRequest(
                      selectedGuide
                    )
                  }
                >
                  <Send size={17} />
                  Submit this service
                </button>

                <span>
                  <ShieldCheck size={15} />
                  Government connections are
                  simulated in this prototype.
                </span>

              </div>

            </div>

          )}

        </section>


        {/* CONNECTED SYSTEMS */}

        <section
          id="systems"
          className="section dark-section"
        >

          <div className="section-heading">

            <div>

              <span className="eyebrow">
                CONNECTOR REGISTRY
              </span>

              <h2>
                Seven systems.
                <span> One bridge.</span>
              </h2>

              <p>
                GovBridge uses adapters so different
                government systems can participate in
                a common interoperability workflow.
              </p>

            </div>

          </div>


          <div className="systems-dashboard">

            <div className="connector-list">

              {connectorsLoading ? (

                <div className="connector-loading">
                  Loading connected systems...
                </div>

              ) : (

                connectors.map((connector) => (

                  <div
                    className="connector-row"
                    key={connector.systemCode}
                  >

                    <div className="connector-icon">
                      <Network size={18} />
                    </div>

                    <div className="connector-info">

                      <strong>
                        {connector.systemName}
                      </strong>

                      <span>
                        {connector.adapterClass}
                      </span>

                    </div>

                    <div className="connector-meta">

                      <em>
                        <i />
                        CONNECTED
                      </em>

                      <small>
                        {connector.mode ||
                          "SIMULATED"}
                      </small>

                    </div>

                  </div>

                ))

              )}

            </div>


            <div className="interoperability-card">

              <div className="interop-center">
                <Network size={27} />

                <span>
                  GOVBRIDGE
                </span>

                <small>
                  CANONICAL LAYER
                </small>
              </div>


              <div className="interop-node n1">
                Municipal
              </div>

              <div className="interop-node n2">
                Police
              </div>

              <div className="interop-node n3">
                Revenue
              </div>

              <div className="interop-node n4">
                Utilities
              </div>

              <div className="interop-line l1" />
              <div className="interop-line l2" />
              <div className="interop-line l3" />
              <div className="interop-line l4" />

              <small>
                COMMON DATA + CONNECTOR MODEL
              </small>

            </div>

          </div>

        </section>


        {/* TRACKING */}

        <section
          id="tracking"
          className="section"
        >

          <div className="section-heading">

            <div>

              <span className="eyebrow">
                UNIFIED TRACKING
              </span>

              <h2>
                One ID.
                <span> Full visibility.</span>
              </h2>

              <p>
                Retrieve a GovBridge request and see
                its current lifecycle, external reference
                and audit history.
              </p>

            </div>

          </div>


          <div className="tracking-card">

            <form
              className="track-form"
              onSubmit={trackRequest}
            >

              <Search size={19} />

              <input
                value={trackingId}
                onChange={(event) =>
                  setTrackingId(
                    event.target.value
                  )
                }
                placeholder="Enter ID e.g. GB-FCB22282"
              />

              <button
                className="primary-button"
                type="submit"
                disabled={trackingLoading}
              >
                {trackingLoading
                  ? "Checking..."
                  : "Track request"}

                <ArrowRight size={17} />
              </button>

            </form>


            {trackingError && (
              <div className="error-box">
                {trackingError}
              </div>
            )}


            {!tracked &&
              !trackingError && (

                <div className="tracking-empty">

                  <div className="empty-icon">
                    <Search size={23} />
                  </div>

                  <strong>
                    Your request journey will
                    appear here.
                  </strong>

                  <span>
                    Enter a GovBridge request ID
                    created by the interoperability flow.
                  </span>

                </div>

              )}


            {tracked && (

              <div className="tracked-result">

                <div className="tracked-top">

                  <div>

                    <span>
                      GOVBRIDGE REQUEST
                    </span>

                    <h3>
                      {tracked.title ||
                        "Government Service Request"}
                    </h3>

                    <div className="tracked-subtitle">
                      {tracked.sourceSystem ||
                        "Connected Government System"}
                    </div>

                  </div>


                  <b>
                    {formatId(tracked)}
                  </b>

                </div>


                <div className="status-timeline">

                  {STATUS_STEPS.map(
                    (status, index) => {

                      const current =
                        STATUS_STEPS.indexOf(
                          tracked.status ||
                            "SUBMITTED"
                        );

                      const done =
                        index <=
                        Math.max(current, 0);

                      return (

                        <div
                          className={
                            `timeline-step ${
                              done
                                ? "done"
                                : ""
                            }`
                          }
                          key={status}
                        >

                          <div className="timeline-dot">

                            {done ? (
                              <CheckCircle2
                                size={16}
                              />
                            ) : (
                              index + 1
                            )}

                          </div>

                          <span>
                            {status.replace(
                              "_",
                              " "
                            )}
                          </span>

                        </div>

                      );

                    }
                  )}

                </div>


                <div className="tracked-grid">

                  <div>
                    <span>
                      Department
                    </span>

                    <strong>
                      {tracked.department ||
                        "â€”"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      External Reference
                    </span>

                    <strong>
                      {tracked.externalRequestId ||
                        "â€”"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Source System
                    </span>

                    <strong>
                      {tracked.sourceSystem ||
                        "â€”"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Authority
                    </span>

                    <strong>
                      {tracked.assignedAuthority ||
                        "â€”"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Priority
                    </span>

                    <strong>
                      {tracked.priority ||
                        "MEDIUM"}
                    </strong>
                  </div>

                  <div>
                    <span>
                      Jurisdiction
                    </span>

                    <strong>
                      {tracked.jurisdiction ||
                        "â€”"}
                    </strong>
                  </div>

                </div>


                <div className="sync-panel">

                  <div className="sync-panel-head">

                    <div>
                      <span className="eyebrow">
                        EXTERNAL SYSTEM SIMULATOR
                      </span>

                      <h3>
                        Status synchronization
                      </h3>
                    </div>

                    <Globe2 size={20} />

                  </div>

                  <p>
                    Simulate a status change in the connected
                    government system and synchronize it with
                    the unified GovBridge tracking record.
                  </p>

                  <div className="sync-current">

                    <span>
                      CURRENT GOVBRIDGE STATUS
                    </span>

                    <strong>
                      {tracked.status ||
                        "SUBMITTED"}
                    </strong>

                  </div>

                  <div className="sync-controls">

                    <button
                      className="secondary-button"
                      disabled={syncLoading}
                      onClick={() =>
                        simulateExternalStatus(
                          "WORKING"
                        )
                      }
                    >
                      {syncLoading
                        ? "Synchronizing..."
                        : "Simulate → IN PROGRESS"}
                    </button>

                    <button
                      className="secondary-button"
                      disabled={syncLoading}
                      onClick={() =>
                        simulateExternalStatus(
                          "COMPLETED"
                        )
                      }
                    >
                      Simulate → RESOLVED
                    </button>

                  </div>

                  {syncMessage && (
                    <div className="sync-message">
                      <CheckCircle2 size={15} />
                      {syncMessage}
                    </div>
                  )}

                </div>


                <div className="audit-panel">

                  <div className="audit-head">

                    <div>
                      <span className="eyebrow">
                        AUDIT TRAIL
                      </span>

                      <h3>
                        Interoperability events
                      </h3>
                    </div>

                    <ShieldCheck size={20} />

                  </div>


                  {auditLogs.length === 0 ? (

                    <div className="audit-empty">
                      No audit events available
                      for this request.
                    </div>

                  ) : (

                    <div className="audit-list">

                      {auditLogs.map(
                        (log) => (

                          <div
                            className="audit-row"
                            key={log.id}
                          >

                            <div className="audit-dot">
                              <CheckCircle2
                                size={14}
                              />
                            </div>

                            <div>

                              <strong>
                                {log.action}
                              </strong>

                              <span>
                                {log.details}
                              </span>

                              <small>
                                {log.sourceSystem}
                                {" Â· "}
                                {log.actor}
                              </small>

                            </div>

                            <em>
                              {log.result}
                            </em>

                          </div>

                        )
                      )}

                    </div>

                  )}

                </div>

              </div>

            )}

          </div>

        </section>


        {/* DEMO */}

        <section className="demo-section">

          <div>

            <span className="eyebrow">
              SIH DEMO FLOW
            </span>

            <h2>
              Fragmented systems.
              <span> One citizen journey.</span>
            </h2>

            <p>
              Citizen ? consent ? connector ?
              transformation ? external system ?
              unified GovBridge ID ? tracking.
            </p>

          </div>


          <button
            className="primary-button"
            onClick={() =>
              openRequest()
            }
          >
            Start live flow
            <ArrowRight size={18} />
          </button>

        </section>

      </main>


      <footer>

        <div>
          <Network size={18} />
          <strong>GovBridge</strong>
        </div>

        <span>
          AI-ready government interoperability
          prototype
        </span>

        <span className="prototype-badge">
          SIH PROTOTYPE Â· SIMULATED SYSTEMS
        </span>

      </footer>


      {/* REQUEST MODAL */}

      {showRequestModal && (

        <div
          className="modal-backdrop"
          onMouseDown={(event) =>
            event.target ===
              event.currentTarget &&
            !submitting &&
            setShowRequestModal(false)
          }
        >

          <div className="complaint-modal">

            <button
              className="icon-button modal-close"
              onClick={() =>
                !submitting &&
                setShowRequestModal(false)
              }
            >
              <X size={19} />
            </button>


            <div className="modal-icon">
              <Network size={20} />
            </div>

            <span className="eyebrow">
              UNIFIED SERVICE REQUEST
            </span>

            <h2>
              Submit through GovBridge.
            </h2>

            <p>
              Your request will be checked for
              consent, routed to the selected
              connector and converted into a
              unified tracking request.
            </p>


            <form
              onSubmit={submitRequest}
            >

              <label>
                Service

                <select
                  value={
                    requestForm.serviceCode
                  }
                  onChange={(event) => {

                    const selected =
                      SERVICE_GUIDES.find(
                        (guide) =>
                          guide.serviceCode ===
                          event.target.value
                      );

                    if (!selected) {
                      return;
                    }

                    setRequestForm({
                      ...requestForm,
                      serviceCode:
                        selected.serviceCode,
                      serviceName:
                        selected.title,
                      department:
                        selected.department,
                      title:
                        selected.title,
                    });

                  }}
                >

                  {SERVICE_GUIDES.map(
                    (guide) => (

                      <option
                        key={
                          guide.serviceCode
                        }
                        value={
                          guide.serviceCode
                        }
                      >
                        {guide.title}
                      </option>

                    )
                  )}

                </select>

              </label>


              <label>
                Citizen ID

                <input
                  value={
                    requestForm.citizenId
                  }
                  onChange={(event) =>
                    setRequestForm({
                      ...requestForm,
                      citizenId:
                        event.target.value,
                    })
                  }
                  placeholder="CITIZEN-DEMO-001"
                />

              </label>


              <label>
                Department

                <select
                  value={
                    requestForm.department
                  }
                  onChange={(event) =>
                    setRequestForm({
                      ...requestForm,
                      department:
                        event.target.value,
                    })
                  }
                >

                  <option value="REVENUE">
                    Revenue
                  </option>

                  <option value="MUNICIPAL">
                    Municipal
                  </option>

                  <option value="POLICE">
                    Police
                  </option>

                  <option value="ELECTRICITY">
                    Electricity
                  </option>

                  <option value="WATER">
                    Water
                  </option>

                  <option value="WELFARE">
                    Welfare
                  </option>

                  <option value="PANCHAYAT">
                    Panchayat
                  </option>

                </select>

              </label>


              <label>
                Request title

                <input
                  value={
                    requestForm.title
                  }
                  onChange={(event) =>
                    setRequestForm({
                      ...requestForm,
                      title:
                        event.target.value,
                    })
                  }
                  placeholder="Residence Certificate"
                />

              </label>


              <label>
                Description

                <textarea
                  rows="4"
                  value={
                    requestForm.description
                  }
                  onChange={(event) =>
                    setRequestForm({
                      ...requestForm,
                      description:
                        event.target.value,
                    })
                  }
                  placeholder="Describe the government service you need..."
                />

              </label>


              <label>
                Address / Location
                <span className="optional">
                  optional
                </span>

                <input
                  value={
                    requestForm.address
                  }
                  onChange={(event) =>
                    setRequestForm({
                      ...requestForm,
                      address:
                        event.target.value,
                    })
                  }
                  placeholder="Enter location"
                />

              </label>


              <div className="consent-box">

                <label className="consent-check">

                  <input
                    type="checkbox"
                    checked={
                      consentAccepted
                    }
                    onChange={(event) =>
                      setConsentAccepted(
                        event.target.checked
                      )
                    }
                  />

                  <span>
                    I consent to GovBridge sharing
                    the requested information with
                    the selected government system
                    for this service request.
                  </span>

                </label>

              </div>


              {submitError && (

                <div className="error-box">
                  {submitError}
                </div>

              )}


              <button
                className="primary-button submit-wide"
                type="submit"
                disabled={submitting}
              >

                {submitting
                  ? "Connecting systems..."
                  : "Submit through GovBridge"}

                <ArrowRight size={18} />

              </button>

            </form>


            <div className="prototype-note">

              <ShieldCheck size={15} />

              Government platform connections
              are simulated in this prototype.

            </div>

          </div>

        </div>

      )}


      {/* SUCCESS MODAL */}

      {submitted && (

        <div className="modal-backdrop">

          <div className="success-modal">

            <div className="success-check">
              <CheckCircle2 size={34} />
            </div>

            <span className="eyebrow">
              WORKFLOW COMPLETED
            </span>

            <h2>
              Request routed successfully.
            </h2>

            <p>
              GovBridge connected the request
              to the selected simulated government
              system and created a unified tracking
              identity.
            </p>


            <div className="success-id">

              <span>
                GOVBRIDGE ID
              </span>

              <strong>
                {
                  submitted
                    ?.unifiedRequest
                    ?.requestId ||
                  "â€”"
                }
              </strong>

            </div>


            <div className="success-meta">

              <div>
                <span>
                  External Reference
                </span>

                <b>
                  {
                    submitted
                      ?.unifiedRequest
                      ?.externalRequestId ||
                    "â€”"
                  }
                </b>
              </div>

              <div>
                <span>
                  Connector
                </span>

                <b>
                  {
                    submitted
                      ?.connectorSystem ||
                    "â€”"
                  }
                </b>
              </div>

              <div>
                <span>
                  Status
                </span>

                <b>
                  {
                    submitted
                      ?.unifiedRequest
                      ?.status ||
                    "SUBMITTED"
                  }
                </b>
              </div>

            </div>


            <div className="workflow-trace">

              <div className="workflow-trace-head">
                <span>
                  INTEROPERABILITY TRACE
                </span>

                <small>
                  SIMULATED
                </small>
              </div>


              {(
                submitted?.workflowTrace ||
                []
              ).map(
                (item, index) => (

                  <div
                    className="trace-item"
                    key={`${item}-${index}`}
                  >

                    <div className="trace-number">
                      {String(index + 1).padStart(
                        2,
                        "0"
                      )}
                    </div>

                    <span>
                      {item
                        .replaceAll("_", " ")
                        .replaceAll(":", " ? ")}
                    </span>

                    {index <
                      submitted.workflowTrace.length -
                        1 && (
                      <ChevronRight
                        size={14}
                      />
                    )}

                  </div>

                )
              )}

            </div>


            <div className="success-actions">

              <button
                className="primary-button"
                onClick={
                  openSubmittedTracking
                }
              >
                Track this request
                <Search size={17} />
              </button>


              <button
                className="secondary-button"
                onClick={() =>
                  setSubmitted(null)
                }
              >
                Continue exploring
              </button>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}


export default App;

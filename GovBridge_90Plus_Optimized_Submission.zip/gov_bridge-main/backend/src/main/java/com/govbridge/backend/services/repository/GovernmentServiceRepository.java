package com.govbridge.backend.services.repository;

import com.govbridge.backend.services.entity.GovernmentService;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GovernmentServiceRepository
        extends JpaRepository<GovernmentService, Long> {

    Optional<GovernmentService> findByServiceCode(String serviceCode);

    List<GovernmentService> findByDepartmentIgnoreCase(
            String department);

    List<GovernmentService> findByCategoryIgnoreCase(
            String category);

    List<GovernmentService> findByStateIgnoreCase(
            String state);

    List<GovernmentService> findByLevelIgnoreCase(
            String level);

    List<GovernmentService> findByStatusIgnoreCase(
            String status);
}
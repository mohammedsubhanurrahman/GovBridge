package com.govbridge.backend.interoperability.controller;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.repository.UnifiedRequestRepository;
import com.govbridge.backend.interoperability.routing.GovernmentRoutingService;
import com.govbridge.backend.interoperability.service.InteroperabilityOrchestratorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/interoperability")
public class InteroperabilityController {

    private final GovernmentRoutingService governmentRoutingService;
    private final InteroperabilityOrchestratorService orchestratorService;
    private final UnifiedRequestRepository unifiedRequestRepository;

    public InteroperabilityController(
            GovernmentRoutingService governmentRoutingService,
            InteroperabilityOrchestratorService orchestratorService,
            UnifiedRequestRepository unifiedRequestRepository) {

        this.governmentRoutingService = governmentRoutingService;
        this.orchestratorService = orchestratorService;
        this.unifiedRequestRepository = unifiedRequestRepository;
    }

    /**
     * Intelligent department routing.
     *
     * Determines which government department
     * should handle the citizen request.
     */
    @PostMapping("/route")
    public ResponseEntity<?> routeRequest(
            @RequestBody MunicipalRequest request) {

        return ResponseEntity.ok(
                governmentRoutingService.routeRequest(request)
        );
    }

    /**
     * Main GovBridge interoperability endpoint.
     *
     * A single citizen request enters GovBridge.
     * GovBridge determines the destination department
     * and sends the request through the appropriate
     * government-system integration layer.
     */
    @PostMapping("/process")
    public ResponseEntity<?> processRequest(
            @RequestBody MunicipalRequest request) {

        return ResponseEntity.ok(
                orchestratorService.processRequest(request)
        );
    }

    /**
     * Get a unified request using the
     * GovBridge request ID.
     */
    @GetMapping("/{requestId}")
    public ResponseEntity<?> getRequest(
            @PathVariable String requestId) {

        return unifiedRequestRepository
                .findByRequestId(requestId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get all unified requests handled
     * through the GovBridge interoperability layer.
     */
    @GetMapping
    public ResponseEntity<List<UnifiedRequest>> getAllRequests() {

        return ResponseEntity.ok(
                unifiedRequestRepository.findAll()
        );
    }
}
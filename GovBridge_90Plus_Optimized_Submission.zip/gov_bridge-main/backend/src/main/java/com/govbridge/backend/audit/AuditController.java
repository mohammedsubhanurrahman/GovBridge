package com.govbridge.backend.audit;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit")
public class AuditController {

    private final AuditService auditService;

    public AuditController(
            AuditService auditService) {

        this.auditService =
                auditService;
    }

    @PostMapping
    public AuditLog record(
            @RequestBody AuditRequest request) {

        return auditService.record(
                request.requestId(),
                request.actor(),
                request.action(),
                request.sourceSystem(),
                request.result(),
                request.details()
        );
    }

    @GetMapping("/{requestId}")
    public List<AuditLog> getByRequestId(
            @PathVariable String requestId) {

        return auditService.getByRequestId(
                requestId
        );
    }

    @GetMapping
    public List<AuditLog> getAll() {

        return auditService.getAll();
    }

    public record AuditRequest(
            String requestId,
            String actor,
            String action,
            String sourceSystem,
            String result,
            String details
    ) {
    }
}

"""FastAPI service for GovBridge AI-assisted request classification.

The prototype uses a small deterministic training set so that the service is
reproducible without downloading a model. Production deployments should train
and evaluate on representative, consented government-service datasets.
"""

from typing import Final

from fastapi import FastAPI
from pydantic import BaseModel, Field
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

APP_NAME: Final[str] = "GovBridge AI Routing Service"
CONFIDENCE_THRESHOLD: Final[float] = 0.65

TRAINING_EXAMPLES = [
    ("birth certificate registration delayed", "CIVIL_REGISTRATION"),
    ("death certificate correction request", "CIVIL_REGISTRATION"),
    ("income caste residence certificate", "REVENUE"),
    ("land record mutation property issue", "REVENUE"),
    ("ration card food subsidy problem", "FOOD_CIVIL_SUPPLIES"),
    ("electricity bill outage connection", "ELECTRICITY"),
    ("water supply pipeline complaint", "WATER"),
    ("street road drainage municipal service", "MUNICIPAL"),
    ("police complaint missing document", "POLICE"),
    ("welfare pension benefit application", "WELFARE"),
    ("school scholarship education service", "EDUCATION"),
    ("hospital health service complaint", "HEALTHCARE"),
    ("panchayat local government service", "PANCHAYAT"),
]

X_TRAIN = [text for text, _ in TRAINING_EXAMPLES]
Y_TRAIN = [label for _, label in TRAINING_EXAMPLES]

MODEL: Final[Pipeline] = Pipeline(
    steps=[
        ("tfidf", TfidfVectorizer(lowercase=True, ngram_range=(1, 2))),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ]
)
MODEL.fit(X_TRAIN, Y_TRAIN)

app = FastAPI(title=APP_NAME, version="1.0.0")


class RoutingRequest(BaseModel):
    """Input fields used to classify a government request."""

    title: str = Field(default="", max_length=300)
    description: str = Field(default="", max_length=5000)


class RoutingPrediction(BaseModel):
    """AI classification output with a human-review safeguard."""

    category: str
    confidence: float = Field(ge=0.0, le=1.0)
    requires_human_review: bool
    model: str


def predict_request(title: str, description: str) -> RoutingPrediction:
    """Predict a government-service category and apply confidence gating."""
    text = f"{title.strip()} {description.strip()}".strip()
    if not text:
        return RoutingPrediction(
            category="UNKNOWN",
            confidence=0.0,
            requires_human_review=True,
            model="tfidf-logistic-regression",
        )

    probabilities = MODEL.predict_proba([text])[0]
    best_index = int(probabilities.argmax())
    confidence = float(probabilities[best_index])
    category = str(MODEL.classes_[best_index])

    return RoutingPrediction(
        category=category,
        confidence=round(confidence, 4),
        requires_human_review=confidence < CONFIDENCE_THRESHOLD,
        model="tfidf-logistic-regression",
    )


@app.get("/health")
def health() -> dict[str, str]:
    """Return a minimal health response suitable for deployment probes."""
    return {"status": "ok", "service": "govbridge-ai"}


@app.post("/predict", response_model=RoutingPrediction)
def predict(request: RoutingRequest) -> RoutingPrediction:
    """Classify a citizen request for downstream GovBridge routing."""
    return predict_request(request.title, request.description)

package com.govbridge.backend.interoperability.service;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.dto.MunicipalResponse;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.repository.UnifiedRequestRepository;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;

@Service
public class MunicipalIntegrationService {

    private final MunicipalAdapter municipalAdapter;
    private final UnifiedRequestRepository unifiedRequestRepository;
    private final RestClient restClient;

    public MunicipalIntegrationService(
            MunicipalAdapter municipalAdapter,
            UnifiedRequestRepository unifiedRequestRepository,
            RestClient.Builder restClientBuilder) {

        this.municipalAdapter = municipalAdapter;
        this.unifiedRequestRepository = unifiedRequestRepository;

        this.restClient = restClientBuilder
                .baseUrl("http://localhost:8081")
                .build();
    }

    /**
     * Sends a citizen request to the external Municipal System
     * and converts the response into the common GovBridge model.
     */
    public UnifiedRequest submitToMunicipalSystem(
            MunicipalRequest request) {

        MunicipalResponse response =
                restClient.post()
                        .uri("/mock/municipal/complaints")
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(request)
                        .retrieve()
                        .body(MunicipalResponse.class);

        if (response == null) {
            throw new IllegalStateException(
                    "Municipal System returned an empty response."
            );
        }

        UnifiedRequest unifiedRequest =
                municipalAdapter.convertToUnifiedRequest(
                        response,
                        request.getTitle(),
                        request.getCategory()
                );

        /*
         * Persist the normalized request in GovBridge.
         */
        return unifiedRequestRepository.save(unifiedRequest);
    }

    /**
     * Synchronizes the status of an existing GovBridge request
     * with the external Municipal Government System.
     */
    public UnifiedRequest synchronizeMunicipalStatus(
            String requestId) {

        /*
         * 1. Find the GovBridge request.
         */
        UnifiedRequest unifiedRequest =
                unifiedRequestRepository
                        .findByRequestId(requestId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "GovBridge request not found: "
                                                + requestId
                                )
                        );

        /*
         * 2. Read the Municipal System's external ID.
         */
        String externalRequestId =
                unifiedRequest.getExternalRequestId();

        if (externalRequestId == null
                || externalRequestId.isBlank()) {

            throw new IllegalStateException(
                    "No external Municipal request ID is associated "
                            + "with GovBridge request: "
                            + requestId
            );
        }

        /*
         * 3. Ask the Municipal System for its latest status.
         */
        MunicipalResponse municipalResponse =
                restClient.get()
                        .uri("/mock/municipal/complaints/{complaintId}",
                                externalRequestId)
                        .retrieve()
                        .body(MunicipalResponse.class);

        if (municipalResponse == null) {
            throw new IllegalStateException(
                    "Municipal System returned an empty status response."
            );
        }

        /*
         * 4. Convert the external status into GovBridge's
         *    canonical status.
         */
        String normalizedStatus =
                municipalAdapter.mapMunicipalStatus(
                        municipalResponse.getStatus()
                );

        unifiedRequest.setStatus(normalizedStatus);

        /*
         * 5. Keep the latest department/authority information.
         */
        unifiedRequest.setDepartment(
                municipalResponse.getDepartment()
        );

        unifiedRequest.setAssignedAuthority(
                municipalResponse.getAssignedOffice()
        );

        /*
         * 6. Record the synchronization time.
         */
        unifiedRequest.setLastSyncedAt(
                LocalDateTime.now()
        );

        /*
         * 7. Persist the updated request.
         */
        return unifiedRequestRepository.save(unifiedRequest);
    }
}
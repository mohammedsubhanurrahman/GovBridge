package com.govbridge.backend.interoperability.service;

import com.govbridge.backend.interoperability.dto.MunicipalResponse;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.UUID;

@Service
public class MunicipalAdapter {

    /**
     * Converts a response from the external Municipal System
     * into the common GovBridge UnifiedRequest model.
     */
    public UnifiedRequest convertToUnifiedRequest(
            MunicipalResponse municipalResponse,
            String title,
            String serviceType) {

        UnifiedRequest unifiedRequest = new UnifiedRequest();

        /*
         * ---------------------------------------------------------
         * 1. Generate GovBridge-wide request ID
         * ---------------------------------------------------------
         */
        unifiedRequest.setRequestId(
                "GB-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase()
        );

        /*
         * ---------------------------------------------------------
         * 2. Preserve external Municipal System ID
         * ---------------------------------------------------------
         */
        unifiedRequest.setExternalRequestId(
                municipalResponse.getComplaintId()
        );

        /*
         * ---------------------------------------------------------
         * 3. Identify source system
         * ---------------------------------------------------------
         */
        unifiedRequest.setSourceSystem(
                "Municipal Government System"
        );

        /*
         * ---------------------------------------------------------
         * 4. Normalize service information
         * ---------------------------------------------------------
         */
        unifiedRequest.setServiceType(
                normalizeServiceType(serviceType)
        );

        unifiedRequest.setTitle(title);

        /*
         * ---------------------------------------------------------
         * 5. Department
         * ---------------------------------------------------------
         */
        unifiedRequest.setDepartment(
                municipalResponse.getDepartment()
        );

        /*
         * ---------------------------------------------------------
         * 6. Normalize external status
         * ---------------------------------------------------------
         */
        unifiedRequest.setStatus(
                mapMunicipalStatus(
                        municipalResponse.getStatus()
                )
        );

        /*
         * ---------------------------------------------------------
         * 7. Assigned authority
         * ---------------------------------------------------------
         */
        unifiedRequest.setAssignedAuthority(
                municipalResponse.getAssignedOffice()
        );

        /*
         * ---------------------------------------------------------
         * 8. Intelligent priority
         * ---------------------------------------------------------
         */
        unifiedRequest.setPriority(
                determinePriority(title, serviceType)
        );

        /*
         * ---------------------------------------------------------
         * 9. Jurisdiction
         * ---------------------------------------------------------
         */
        unifiedRequest.setJurisdiction(
                "Local"
        );

        /*
         * ---------------------------------------------------------
         * 10. Synchronization timestamp
         * ---------------------------------------------------------
         */
        unifiedRequest.setLastSyncedAt(
                LocalDateTime.now()
        );

        return unifiedRequest;
    }

    /**
     * Normalizes the service type into a consistent GovBridge value.
     */
    private String normalizeServiceType(String serviceType) {

        if (serviceType == null || serviceType.isBlank()) {
            return "General Grievance";
        }

        return serviceType.trim();
    }

    /**
     * Determines priority using the grievance title/service type.
     */
    private String determinePriority(
            String title,
            String serviceType) {

        String text =
                ((title == null ? "" : title) + " "
                        + (serviceType == null ? "" : serviceType))
                        .toLowerCase(Locale.ROOT);

        /*
         * Critical situations
         */
        if (containsAny(
                text,
                "emergency",
                "accident",
                "fire",
                "life threatening",
                "danger",
                "critical")) {

            return "CRITICAL";
        }

        /*
         * High priority municipal issues
         */
        if (containsAny(
                text,
                "blocked",
                "major",
                "severe",
                "urgent",
                "flood",
                "overflow")) {

            return "HIGH";
        }

        /*
         * Normal municipal grievance
         */
        return "MEDIUM";
    }

    /**
     * Converts external Municipal status terminology
     * into GovBridge canonical status terminology.
     *
     * Municipal System  ->  GovBridge
     *
     * OPEN              ->  SUBMITTED
     * PENDING           ->  IN_PROGRESS
     * WORKING           ->  IN_PROGRESS
     * RESOLVED          ->  RESOLVED
     * CLOSED            ->  CLOSED
     */
    public String mapMunicipalStatus(String municipalStatus) {

        if (municipalStatus == null || municipalStatus.isBlank()) {
            return "SUBMITTED";
        }

        return switch (
                municipalStatus.trim().toUpperCase(Locale.ROOT)) {

            case "OPEN" -> "SUBMITTED";

            case "PENDING" -> "IN_PROGRESS";

            case "WORKING" -> "IN_PROGRESS";

            case "RESOLVED" -> "RESOLVED";

            case "CLOSED" -> "CLOSED";

            default -> "SUBMITTED";
        };
    }

    /**
     * Utility method for keyword detection.
     */
    private boolean containsAny(
            String text,
            String... keywords) {

        for (String keyword : keywords) {

            if (text.contains(keyword)) {
                return true;
            }
        }

        return false;
    }
}
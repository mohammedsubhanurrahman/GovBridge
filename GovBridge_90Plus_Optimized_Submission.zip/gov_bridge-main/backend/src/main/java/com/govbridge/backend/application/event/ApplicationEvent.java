package com.govbridge.backend.application.event;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "application_events")
public class ApplicationEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String applicationId;

    @Column(nullable = false)
    private String eventType;

    private String previousStatus;
    private String newStatus;
    private String previousStage;
    private String newStage;

    @Column(length = 1000)
    private String remarks;

    @Column(nullable = false)
    private LocalDateTime eventTime;

    public ApplicationEvent() {
    }

    public ApplicationEvent(
            String applicationId,
            String eventType,
            String previousStatus,
            String newStatus,
            String previousStage,
            String newStage,
            String remarks) {

        this.applicationId = applicationId;
        this.eventType = eventType;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.previousStage = previousStage;
        this.newStage = newStage;
        this.remarks = remarks;
        this.eventTime = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getEventType() {
        return eventType;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public String getNewStatus() {
        return newStatus;
    }

    public String getPreviousStage() {
        return previousStage;
    }

    public String getNewStage() {
        return newStage;
    }

    public String getRemarks() {
        return remarks;
    }

    public LocalDateTime getEventTime() {
        return eventTime;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }

    public void setPreviousStage(String previousStage) {
        this.previousStage = previousStage;
    }

    public void setNewStage(String newStage) {
        this.newStage = newStage;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setEventTime(LocalDateTime eventTime) {
        this.eventTime = eventTime;
    }
}
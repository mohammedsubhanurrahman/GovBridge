package com.govbridge.backend.routing.service;

import com.govbridge.backend.routing.dto.RoutingResult;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
/**
 * Deterministic government-service classifier used as the reliable routing fallback.
 * It combines normalized request text with domain rules for department, priority
 * and jurisdiction selection.
 */
public class SmartRoutingService {

    public RoutingResult analyze(String title, String description) {

        String text = ((title == null ? "" : title) + " "
                + (description == null ? "" : description))
                .toLowerCase(Locale.ROOT);

        /*
         * =========================================================
         * 1. GOVERNMENT SERVICE REQUESTS
         * =========================================================
         * These are requests for a government service/document.
         * They should not automatically become grievances.
         */

        // Birth Certificate
        if (containsAny(text,
                "birth certificate",
                "birth registration",
                "register birth",
                "birth record")) {

            // If the citizen reports a problem/delay, treat it
            // as a grievance related to the service.
            if (containsAny(text,
                    "delay",
                    "delayed",
                    "not received",
                    "not issued",
                    "pending",
                    "rejected",
                    "problem",
                    "issue",
                    "wrong",
                    "correction",
                    "complaint")) {

                return new RoutingResult(
                        "Birth Certificate Delay",
                        "Civil Registration / Municipal Administration",
                        "HIGH",
                        "Local",
                        "Local Birth & Death Registrar",
                        0.91
                );
            }

            return new RoutingResult(
                    "Birth Certificate",
                    "Civil Registration / Municipal Administration",
                    "MEDIUM",
                    "Local",
                    "Local Birth & Death Registrar",
                    0.93
            );
        }

        // Death Certificate
        if (containsAny(text,
                "death certificate",
                "death registration",
                "death record")) {

            if (containsAny(text,
                    "delay",
                    "delayed",
                    "not received",
                    "not issued",
                    "pending",
                    "rejected",
                    "problem",
                    "issue",
                    "wrong",
                    "correction",
                    "complaint")) {

                return new RoutingResult(
                        "Death Certificate Issue",
                        "Civil Registration / Municipal Administration",
                        "HIGH",
                        "Local",
                        "Local Birth & Death Registrar",
                        0.90
                );
            }

            return new RoutingResult(
                    "Death Certificate",
                    "Civil Registration / Municipal Administration",
                    "MEDIUM",
                    "Local",
                    "Local Birth & Death Registrar",
                    0.92
            );
        }

        // Income Certificate
        if (containsAny(text,
                "income certificate",
                "income proof",
                "income certificate application")) {

            if (containsAny(text,
                    "delay",
                    "delayed",
                    "pending",
                    "rejected",
                    "not received",
                    "problem",
                    "complaint")) {

                return new RoutingResult(
                        "Income Certificate Issue",
                        "Revenue Department",
                        "HIGH",
                        "District",
                        "Mandal Revenue Office",
                        0.90
                );
            }

            return new RoutingResult(
                    "Income Certificate",
                    "Revenue Department",
                    "MEDIUM",
                    "District",
                    "Mandal Revenue Office",
                    0.91
            );
        }

        // Caste Certificate
        if (containsAny(text,
                "caste certificate",
                "community certificate",
                "caste certificate application")) {

            if (containsAny(text,
                    "delay",
                    "delayed",
                    "pending",
                    "rejected",
                    "not received",
                    "problem",
                    "complaint")) {

                return new RoutingResult(
                        "Caste Certificate Issue",
                        "Revenue Department",
                        "HIGH",
                        "District",
                        "Mandal Revenue Office",
                        0.89
                );
            }

            return new RoutingResult(
                    "Caste Certificate",
                    "Revenue Department",
                    "MEDIUM",
                    "District",
                    "Mandal Revenue Office",
                    0.90
            );
        }

        // Residence Certificate
        if (containsAny(text,
                "residence certificate",
                "residential certificate",
                "domicile certificate")) {

            if (containsAny(text,
                    "delay",
                    "delayed",
                    "pending",
                    "rejected",
                    "not received",
                    "problem",
                    "complaint")) {

                return new RoutingResult(
                        "Residence Certificate Issue",
                        "Revenue Department",
                        "HIGH",
                        "District",
                        "Mandal Revenue Office",
                        0.89
                );
            }

            return new RoutingResult(
                    "Residence Certificate",
                    "Revenue Department",
                    "MEDIUM",
                    "District",
                    "Mandal Revenue Office",
                    0.90
            );
        }

        // Ration Card
        if (containsAny(text,
                "ration card",
                "ration",
                "food card",
                "pds card")) {

            if (containsAny(text,
                    "delay",
                    "delayed",
                    "pending",
                    "rejected",
                    "not received",
                    "problem",
                    "complaint")) {

                return new RoutingResult(
                        "Ration Card Issue",
                        "Food & Civil Supplies Department",
                        "HIGH",
                        "District",
                        "District Civil Supplies Office",
                        0.88
                );
            }

            return new RoutingResult(
                    "Ration Card Service",
                    "Food & Civil Supplies Department",
                    "MEDIUM",
                    "District",
                    "District Civil Supplies Office",
                    0.89
            );
        }

        /*
         * =========================================================
         * 2. ELECTRICITY GRIEVANCES
         * =========================================================
         */

        if (containsAny(text,
                "electricity",
                "power",
                "current",
                "power cut",
                "transformer",
                "electric pole",
                "electric")) {

            return new RoutingResult(
                    "Electricity",
                    "Electricity Department",
                    determinePriority(text, "power", "electricity"),
                    "Local",
                    "Local Electricity Office",
                    0.94
            );
        }

        /*
         * =========================================================
         * 3. WATER GRIEVANCES
         * =========================================================
         */

        if (containsAny(text,
                "water",
                "pipeline",
                "water supply",
                "drinking water",
                "leakage",
                "tap water")) {

            return new RoutingResult(
                    "Water Supply",
                    "Water Supply Department",
                    determinePriority(text, "leakage", "water supply"),
                    "Local",
                    "Local Water Supply Office",
                    0.92
            );
        }

        /*
         * =========================================================
         * 4. MUNICIPAL GRIEVANCES
         * =========================================================
         */

        if (containsAny(text,
                "street light",
                "streetlight",
                "road",
                "pothole",
                "drain",
                "garbage",
                "waste",
                "municipal")) {

            return new RoutingResult(
                    "Municipal Services",
                    "Municipal Corporation",
                    determinePriority(text, "danger", "accident", "blocked"),
                    "Local",
                    "Municipal Ward Office",
                    0.91
            );
        }

        /*
         * =========================================================
         * 5. HEALTHCARE GRIEVANCES
         * =========================================================
         */

        if (containsAny(text,
                "hospital",
                "health",
                "doctor",
                "ambulance",
                "medicine",
                "medical")) {

            return new RoutingResult(
                    "Healthcare",
                    "Health Department",
                    determinePriority(
                            text,
                            "ambulance",
                            "emergency",
                            "critical"
                    ),
                    "Local",
                    "District Health Office",
                    0.90
            );
        }

        /*
         * =========================================================
         * 6. EDUCATION GRIEVANCES
         * =========================================================
         */

        if (containsAny(text,
                "school",
                "college",
                "teacher",
                "education",
                "student",
                "exam")) {

            return new RoutingResult(
                    "Education",
                    "Education Department",
                    determinePriority(
                            text,
                            "exam",
                            "urgent",
                            "student"
                    ),
                    "District",
                    "District Education Office",
                    0.89
            );
        }

        /*
         * =========================================================
         * 7. POLICE / PUBLIC SAFETY
         * =========================================================
         */

        if (containsAny(text,
                "police",
                "crime",
                "theft",
                "stolen",
                "fraud",
                "harassment",
                "safety")) {

            return new RoutingResult(
                    "Public Safety",
                    "Police Department",
                    "CRITICAL",
                    "Local",
                    "Local Police Station",
                    0.95
            );
        }

        /*
         * =========================================================
         * 8. SOCIAL WELFARE
         * =========================================================
         */

        if (containsAny(text,
                "pension",
                "welfare",
                "scholarship",
                "social security",
                "benefit")) {

            return new RoutingResult(
                    "Social Welfare",
                    "Social Welfare Department",
                    "MEDIUM",
                    "District",
                    "District Social Welfare Office",
                    0.87
            );
        }

        /*
         * =========================================================
         * 9. GENERAL GRIEVANCE FALLBACK
         * =========================================================
         */

        return new RoutingResult(
                "General Grievance",
                "Citizen Services",
                "MEDIUM",
                "District",
                "District Grievance Cell",
                0.65
        );
    }

    private boolean containsAny(
            String text,
            String... keywords) {

        for (String keyword : keywords) {
            if (text.contains(keyword)) {
                return true;
            }
        }

        return false;
    }

    private String determinePriority(
            String text,
            String... priorityKeywords) {

        if (containsAny(
                text,
                "emergency",
                "critical",
                "life threatening",
                "danger",
                "accident",
                "fire",
                "ambulance",
                "urgent")) {

            return "CRITICAL";
        }

        if (containsAny(text, priorityKeywords)) {
            return "HIGH";
        }

        return "MEDIUM";
    }
}
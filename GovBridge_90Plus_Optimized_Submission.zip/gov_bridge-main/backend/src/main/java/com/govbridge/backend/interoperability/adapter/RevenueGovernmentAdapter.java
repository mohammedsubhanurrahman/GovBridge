package com.govbridge.backend.interoperability.adapter;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import com.govbridge.backend.interoperability.revenue.service.RevenueIntegrationService;
import org.springframework.stereotype.Component;

@Component
public class RevenueGovernmentAdapter implements GovernmentSystemAdapter {

    private final RevenueIntegrationService revenueIntegrationService;

    public RevenueGovernmentAdapter(RevenueIntegrationService revenueIntegrationService) {
        this.revenueIntegrationService = revenueIntegrationService;
    }

    @Override
    public String getDepartment() {
        return "REVENUE";
    }

    @Override
    public String getSystemCode() {
        return "REVENUE";
    }

    @Override
    public String getSystemName() {
        return "Revenue Government System";
    }

    @Override
    public boolean supports(MunicipalRequest request) {
        return request != null &&
                request.getTitle() != null &&
                request.getTitle().toLowerCase().matches(".*(certificate|revenue|income|residence|land|property).*" );
    }

    @Override
    public UnifiedRequest submit(MunicipalRequest request) {
        return revenueIntegrationService.submitToRevenueSystem(request);
    }
}

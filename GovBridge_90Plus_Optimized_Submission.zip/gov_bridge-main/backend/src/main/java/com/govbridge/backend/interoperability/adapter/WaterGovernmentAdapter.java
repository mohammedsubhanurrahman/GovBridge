package com.govbridge.backend.interoperability.adapter;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

@Component
public class WaterGovernmentAdapter implements GovernmentSystemAdapter {

    @Override
    public String getSystemName() {
        return "Water Government System";
    }

    @Override
    public String getDepartment() {
        return "WATER";
    }

    @Override
    public boolean supports(MunicipalRequest request) {
        if (request == null) {
            return false;
        }

        String text =
                ((request.getTitle() == null ? "" : request.getTitle()) + " " +
                 (request.getDescription() == null ? "" : request.getDescription()))
                .toLowerCase();

        return text.contains("water")
                || text.contains("pipeline")
                || text.contains("leakage")
                || text.contains("water supply")
                || text.contains("drinking water");
    }

    @Override
    public UnifiedRequest submit(MunicipalRequest request) {

        UnifiedRequest result = new UnifiedRequest();

        result.setRequestId(
                "GB-" + UUID.randomUUID()
                        .toString().substring(0, 8).toUpperCase()
        );

        result.setExternalRequestId(
                "WATER-" + UUID.randomUUID()
                        .toString().substring(0, 8).toUpperCase()
        );

        result.setSourceSystem(getSystemName());
        result.setServiceType("Water Service");
        result.setTitle(request.getTitle());
        result.setDepartment("Water Department");
        result.setStatus("SUBMITTED");
        result.setPriority("MEDIUM");
        result.setJurisdiction("Local");
        result.setAssignedAuthority("Water Section Office");
        result.setCreatedAt(LocalDateTime.now());
        result.setLastSyncedAt(LocalDateTime.now());

        return result;
    }
}

package com.govbridge.backend.interoperability.canonical.controller;

import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationRequest;
import com.govbridge.backend.interoperability.canonical.model.CanonicalNormalizationResponse;
import com.govbridge.backend.interoperability.canonical.service.CanonicalNormalizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Step-1 interoperability endpoint.
 *
 * This is intentionally separate from the existing /process endpoint so
 * the current working integrations remain untouched while the canonical
 * interoperability layer is introduced safely.
 */
@RestController
@RequestMapping("/api/interoperability/canonical")
public class CanonicalInteroperabilityController {

    private final CanonicalNormalizationService normalizationService;

    public CanonicalInteroperabilityController(
            CanonicalNormalizationService normalizationService) {
        this.normalizationService = normalizationService;
    }

    /**
     * Converts an external government-system payload into the
     * common GovBridge canonical model and returns a transformation trace.
     */
    @PostMapping("/normalize")
    public ResponseEntity<CanonicalNormalizationResponse> normalize(
            @RequestBody CanonicalNormalizationRequest request) {

        return ResponseEntity.ok(
                normalizationService.normalize(request)
        );
    }
}

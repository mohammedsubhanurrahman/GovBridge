# OptiForge Submission Checklist

## Code Quality
- Modular Spring Boot package structure.
- DTO/service/repository/controller separation.
- Connector interface isolates external systems.
- JavaDoc on core routing, interoperability, consent and audit services.

## Efficiency & Latency
- Lightweight deterministic routing path.
- Optional AI service isolated from the core synchronous path.
- Benchmark deployment TTFB before submission.

## Testing & Validation
- JUnit tests for routing and connector registry.
- Pytest fixtures for AI health, classification, boundaries and human-review fallback.
- Frontend lint/build checks.

## Security & Secrets
- No real secrets in source control.
- `.env.example` templates only.
- H2 console disabled by default.
- SQL logging disabled by default.
- CORS is configurable by environment.

## Problem Alignment
- Government interoperability.
- Unified citizen service delivery.
- Intelligent routing.
- Heterogeneous/legacy systems.
- Canonical data normalization.
- Department adapters and connectors.
- Unified tracking and status synchronization.
- Consent and auditability.

## Track Innovation
- FastAPI AI/ML service.
- TF-IDF + Logistic Regression prototype classifier.
- Confidence scoring.
- Human-review fallback.

## Accessibility & Documentation
- README with setup and architecture.
- API, testing, performance and SDG documentation.
- Frontend viewport validation required after deployment.

# GovBridge AI Service

FastAPI microservice for AI-assisted government-service intent and department classification.

## Model pipeline

**Text -> TF-IDF -> Logistic Regression -> confidence -> human-review gate**

The bundled dataset is intentionally small and deterministic for prototype reproducibility. It is not a production-trained government classifier.

## Run

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Endpoints:

- `GET /health`
- `POST /predict`
- `/docs`

## Test

```bash
pytest -q
```

## Safety and limitations

Low-confidence classifications are marked for human review. Production use requires representative multilingual datasets, privacy controls, model evaluation, calibration, monitoring and domain-owner validation.

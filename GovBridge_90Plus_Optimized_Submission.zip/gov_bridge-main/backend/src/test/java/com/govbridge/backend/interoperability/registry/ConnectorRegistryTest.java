package com.govbridge.backend.interoperability.registry;

import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Tests registry indexing and connector discovery behavior. */
class ConnectorRegistryTest {

    @Test
    void indexesEnabledConnectorByCodeAndDepartment() {
        GovernmentSystemAdapter adapter = new GovernmentSystemAdapter() {
            @Override public String getDepartment() { return "Revenue Department"; }
            @Override public boolean supports(com.govbridge.backend.interoperability.dto.MunicipalRequest request) { return true; }
            @Override public com.govbridge.backend.interoperability.entity.UnifiedRequest submit(com.govbridge.backend.interoperability.dto.MunicipalRequest request) { return null; }
            @Override public String getSystemCode() { return "REVENUE"; }
        };

        ConnectorRegistry registry = new ConnectorRegistry(List.of(adapter));
        assertTrue(registry.hasConnector("REVENUE"));
        assertNotNull(registry.getByDepartment("Revenue Department"));
        assertEquals(1, registry.describeAll().size());
    }
}

package com.govbridge.backend.hierarchy.service;

import com.govbridge.backend.hierarchy.dto.HierarchyNode;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class HierarchyService {

    /**
     * Demo administrative hierarchy.
     *
     * This is configuration/demo data, not a live government directory.
     *
     * State
     *  └── District
     *       └── Mandal / Block
     *            └── Gram Panchayat
     *                 └── Village / Ward
     *                      └── Responsible roles
     */
    public List<HierarchyNode> getHierarchy() {

        HierarchyNode state = node(
                "STATE-01",
                "Example State",
                "STATE",
                "State Administration",
                "All Departments"
        );

        HierarchyNode district = node(
                "DIST-01",
                "Example District",
                "DISTRICT",
                "District Administration",
                "District Administration"
        );

        HierarchyNode mandal = node(
                "MANDAL-01",
                "Example Mandal",
                "MANDAL",
                "Mandal / Block Administration",
                "Multi-Department"
        );

        HierarchyNode panchayat = node(
                "GP-01",
                "Example Gram Panchayat",
                "GRAM_PANCHAYAT",
                "Local Self Government",
                "Panchayat Raj"
        );

        HierarchyNode village = node(
                "VILLAGE-01",
                "Example Village",
                "VILLAGE",
                "Village / Ward",
                "Local Administration"
        );

        village.addChild(node(
                "ROLE-01",
                "Sarpanch",
                "ROLE",
                "Sarpanch",
                "Panchayat Raj"
        ));

        village.addChild(node(
                "ROLE-02",
                "Deputy Sarpanch",
                "ROLE",
                "Deputy Sarpanch",
                "Panchayat Raj"
        ));

        village.addChild(node(
                "ROLE-03",
                "Ward Member",
                "ROLE",
                "Ward Member",
                "Panchayat Raj"
        ));

        village.addChild(node(
                "ROLE-04",
                "Panchayat Secretary",
                "ROLE",
                "Panchayat Secretary",
                "Panchayat Raj"
        ));

        village.addChild(node(
                "ROLE-05",
                "Village Secretariat Staff",
                "ROLE",
                "Village Secretariat Staff",
                "Citizen Services"
        ));

        village.addChild(node(
                "ROLE-06",
                "Village Revenue Officer",
                "ROLE",
                "Revenue Authority",
                "Revenue"
        ));

        panchayat.addChild(village);
        mandal.addChild(panchayat);
        district.addChild(mandal);
        state.addChild(district);

        List<HierarchyNode> result = new ArrayList<>();
        result.add(state);

        return result;
    }

    /**
     * Returns the configured administrative levels supported by GovBridge.
     */
    public List<String> getLevels() {
        return List.of(
                "STATE",
                "DISTRICT",
                "MANDAL",
                "GRAM_PANCHAYAT",
                "VILLAGE",
                "WARD",
                "ROLE"
        );
    }

    private HierarchyNode node(
            String id,
            String name,
            String level,
            String role,
            String department) {

        return new HierarchyNode(
                id,
                name,
                level,
                role,
                department
        );
    }
}
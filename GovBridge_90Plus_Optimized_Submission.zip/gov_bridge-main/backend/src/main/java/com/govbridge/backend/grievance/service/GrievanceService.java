package com.govbridge.backend.grievance.service;

import com.govbridge.backend.grievance.entity.Grievance;
import com.govbridge.backend.grievance.repository.GrievanceRepository;
import com.govbridge.backend.routing.dto.RoutingResult;
import com.govbridge.backend.routing.service.SmartRoutingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class GrievanceService {

    private final GrievanceRepository grievanceRepository;
    private final SmartRoutingService smartRoutingService;

    private static final Set<String> VALID_STATUSES = Set.of(
            "SUBMITTED",
            "ASSIGNED",
            "IN_PROGRESS",
            "RESOLVED",
            "CLOSED"
    );

    public GrievanceService(
            GrievanceRepository grievanceRepository,
            SmartRoutingService smartRoutingService) {

        this.grievanceRepository = grievanceRepository;
        this.smartRoutingService = smartRoutingService;
    }

    public Grievance createGrievance(Grievance grievance) {

        // Default status
        if (grievance.getStatus() == null
                || grievance.getStatus().isBlank()) {

            grievance.setStatus("SUBMITTED");
        }

        // Normalize status
        grievance.setStatus(
                grievance.getStatus().trim().toUpperCase()
        );

        // Validate status
        if (!VALID_STATUSES.contains(grievance.getStatus())) {
            throw new IllegalArgumentException(
                    "Invalid grievance status: " + grievance.getStatus()
            );
        }

        // Default creation time
        if (grievance.getCreatedAt() == null) {
            grievance.setCreatedAt(
                    java.time.LocalDateTime.now()
            );
        }

        /*
         * SMART ROUTING
         */
        RoutingResult routingResult =
                smartRoutingService.analyze(
                        grievance.getTitle(),
                        grievance.getDescription()
                );

        /*
         * Store complete routing result
         */
        if (routingResult != null) {

            grievance.setCategory(
                    routingResult.getCategory()
            );

            grievance.setDepartment(
                    routingResult.getDepartment()
            );

            grievance.setPriority(
                    routingResult.getPriority()
            );

            grievance.setJurisdiction(
                    routingResult.getJurisdiction()
            );

            grievance.setAssignedAuthority(
                    routingResult.getAssignedAuthority()
            );

            grievance.setRoutingConfidence(
                    routingResult.getConfidence()
            );
        }

        return grievanceRepository.save(grievance);
    }

    public List<Grievance> getAllGrievances() {
        return grievanceRepository.findAll();
    }

    public Optional<Grievance> getGrievanceById(Long id) {
        return grievanceRepository.findById(id);
    }

    public Optional<Grievance> updateStatus(
            Long id,
            String status) {

        if (status == null || status.isBlank()) {
            throw new IllegalArgumentException(
                    "Status is required."
            );
        }

        String normalizedStatus =
                status.trim().toUpperCase();

        if (!VALID_STATUSES.contains(normalizedStatus)) {
            throw new IllegalArgumentException(
                    "Invalid grievance status: "
                            + normalizedStatus
                            + ". Allowed values: "
                            + String.join(", ", VALID_STATUSES)
            );
        }

        return grievanceRepository.findById(id).map(grievance -> {

            grievance.setStatus(normalizedStatus);

            return grievanceRepository.save(grievance);
        });
    }
}
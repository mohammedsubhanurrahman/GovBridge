# GovBridge — Step 1: Government Hierarchy Engine

## What this adds

A new, isolated backend module:

`/api/hierarchy`

It models:

State → District → Mandal/Block → Gram Panchayat → Village/Ward → Roles

Roles included:
- Sarpanch
- Deputy Sarpanch
- Ward Member
- Panchayat Secretary
- Village Secretariat Staff
- Village Revenue Officer

## Files

Copy the files into your existing backend:

src/main/java/com/govbridge/backend/hierarchy/dto/HierarchyNode.java
src/main/java/com/govbridge/backend/hierarchy/service/HierarchyService.java
src/main/java/com/govbridge/backend/hierarchy/controller/HierarchyController.java

## Important

The hierarchy data is explicitly demo/configuration data. It does NOT claim to be a live government directory.

## Test

Start the backend on port 8081.

Open:

GET http://localhost:8081/api/hierarchy

Also test:

GET http://localhost:8081/api/hierarchy/levels

Expected:
- HTTP 200
- JSON tree beginning with STATE-01
- nested district → mandal → gram panchayat → village
- village contains the configured administrative roles

This step intentionally does not modify the existing grievance, routing, interoperability, or frontend code. That keeps the current working flow safe while creating the hierarchy foundation for the next routing-engine step.

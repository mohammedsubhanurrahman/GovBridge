package com.govbridge.backend.routing.dto;

public class RoutingResult {

    private String category;
    private String department;
    private String priority;
    private String jurisdiction;
    private String assignedAuthority;
    private double confidence;
    private boolean requiresHumanReview;

    public RoutingResult() {
    }

    public RoutingResult(
            String category,
            String department,
            String priority,
            String jurisdiction,
            String assignedAuthority,
            double confidence) {

        this.category = category;
        this.department = department;
        this.priority = priority;
        this.jurisdiction = jurisdiction;
        this.assignedAuthority = assignedAuthority;
        this.confidence = confidence;
        this.requiresHumanReview = confidence < 0.70;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public String getAssignedAuthority() {
        return assignedAuthority;
    }

    public void setAssignedAuthority(String assignedAuthority) {
        this.assignedAuthority = assignedAuthority;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
        this.requiresHumanReview = confidence < 0.70;
    }

    /** Indicates whether an authorized human should verify this routing decision. */
    public boolean isRequiresHumanReview() {
        return requiresHumanReview;
    }

    public void setRequiresHumanReview(boolean requiresHumanReview) {
        this.requiresHumanReview = requiresHumanReview;
    }
}
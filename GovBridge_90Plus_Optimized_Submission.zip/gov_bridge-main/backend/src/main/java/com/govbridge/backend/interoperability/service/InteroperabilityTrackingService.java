package com.govbridge.backend.interoperability.service;

import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.repository.UnifiedRequestRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
/**
 * Provides unified tracking and status synchronization for interoperable requests.
 */
public class InteroperabilityTrackingService {

    private final UnifiedRequestRepository unifiedRequestRepository;

    public InteroperabilityTrackingService(
            UnifiedRequestRepository unifiedRequestRepository) {

        this.unifiedRequestRepository =
                unifiedRequestRepository;
    }

    /**
     * Returns one unified request using the
     * GovBridge request ID.
     */
    public UnifiedRequest getByRequestId(
            String requestId) {

        if (requestId == null || requestId.isBlank()) {

            throw new IllegalArgumentException(
                    "GovBridge request ID is required."
            );
        }

        return unifiedRequestRepository
                .findByRequestId(requestId.trim())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "GovBridge request not found: "
                                        + requestId
                        )
                );
    }

    /**
     * Returns all requests handled through
     * the interoperability layer.
     */
    public List<UnifiedRequest> getAllRequests() {

        return unifiedRequestRepository.findAll();
    }

    /**
     * Finds a GovBridge request using the
     * external government's request ID.
     */
    public UnifiedRequest getByExternalRequestId(
            String externalRequestId) {

        if (externalRequestId == null
                || externalRequestId.isBlank()) {

            throw new IllegalArgumentException(
                    "External request ID is required."
            );
        }

        return unifiedRequestRepository
                .findByExternalRequestId(
                        externalRequestId.trim()
                )
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "External government request not found: "
                                        + externalRequestId
                        )
                );
    }

    /**
     * Synchronizes an external government status
     * into the GovBridge unified status model.
     */
    public UnifiedRequest synchronizeStatus(
            String externalRequestId,
            String externalStatus) {

        if (externalRequestId == null
                || externalRequestId.isBlank()) {

            throw new IllegalArgumentException(
                    "External request ID is required."
            );
        }

        if (externalStatus == null
                || externalStatus.isBlank()) {

            throw new IllegalArgumentException(
                    "External status is required."
            );
        }

        UnifiedRequest request =
                unifiedRequestRepository
                        .findByExternalRequestId(
                                externalRequestId.trim()
                        )
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "External government request not found: "
                                                + externalRequestId
                                )
                        );

        String canonicalStatus =
                normalizeStatus(externalStatus);

        request.setStatus(canonicalStatus);

        request.setLastSyncedAt(
                LocalDateTime.now()
        );

        return unifiedRequestRepository.save(request);
    }

    /**
     * Converts different government-system
     * status values into one GovBridge status.
     */
    private String normalizeStatus(
            String externalStatus) {

        String status =
                externalStatus
                        .trim()
                        .toUpperCase();

        return switch (status) {

            case "OPEN",
                 "RECEIVED",
                 "REGISTERED",
                 "SUBMITTED" ->
                    "SUBMITTED";

            case "PENDING",
                 "PROCESSING",
                 "WORKING",
                 "INVESTIGATING",
                 "VERIFICATION",
                 "IN_PROGRESS" ->
                    "IN_PROGRESS";

            case "ASSIGNED" ->
                    "ASSIGNED";

            case "APPROVED",
                 "RESOLVED" ->
                    "RESOLVED";

            case "CLOSED",
                 "COMPLETED" ->
                    "CLOSED";

            default ->
                    "IN_PROGRESS";
        };
    }
}

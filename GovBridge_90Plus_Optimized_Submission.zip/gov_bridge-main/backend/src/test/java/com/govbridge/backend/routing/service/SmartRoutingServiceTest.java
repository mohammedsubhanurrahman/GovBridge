package com.govbridge.backend.routing.service;

import com.govbridge.backend.routing.dto.RoutingResult;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Boundary and representative tests for deterministic GovBridge routing. */
class SmartRoutingServiceTest {

    private final SmartRoutingService service = new SmartRoutingService();

    @Test
    void routesElectricityRequestToElectricityDepartment() {
        RoutingResult result = service.analyze("Electricity bill", "Power outage in my locality");
        assertEquals("Electricity Department", result.getDepartment());
        assertTrue(result.getConfidence() >= 0.0 && result.getConfidence() <= 1.0);
        assertFalse(result.isRequiresHumanReview());
    }

    @Test
    void routesLandRecordRequestToRevenueDepartment() {
        RoutingResult result = service.analyze("Land record mutation", "Property record needs correction");
        assertEquals("Revenue Department", result.getDepartment());
        assertTrue(result.getConfidence() >= 0.0 && result.getConfidence() <= 1.0);
    }

    @Test
    void handlesEmptyInputWithHumanReviewFallback() {
        RoutingResult result = assertDoesNotThrow(() -> service.analyze(null, null));
        assertTrue(result.isRequiresHumanReview());
    }
}

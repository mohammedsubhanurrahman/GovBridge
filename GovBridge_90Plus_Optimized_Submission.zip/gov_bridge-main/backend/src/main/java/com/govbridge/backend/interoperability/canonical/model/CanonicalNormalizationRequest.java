package com.govbridge.backend.interoperability.canonical.model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Input contract used by the Step-1 interoperability demonstration.
 * The payload represents the response/request shape of an external
 * government platform before GovBridge normalizes it.
 */
public class CanonicalNormalizationRequest {

    private String sourceSystem;
    private String serviceCode;
    private String serviceName;
    private String intent;
    private String department;
    private String administrativeLevel;
    private String jurisdiction;
    private String assignedAuthority;
    private String priority;
    private String title;
    private String description;

    private Map<String, Object> payload = new LinkedHashMap<>();

    public CanonicalNormalizationRequest() {
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAdministrativeLevel() {
        return administrativeLevel;
    }

    public void setAdministrativeLevel(String administrativeLevel) {
        this.administrativeLevel = administrativeLevel;
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public String getAssignedAuthority() {
        return assignedAuthority;
    }

    public void setAssignedAuthority(String assignedAuthority) {
        this.assignedAuthority = assignedAuthority;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Map<String, Object> getPayload() {
        return payload;
    }

    public void setPayload(Map<String, Object> payload) {
        this.payload = payload == null
                ? new LinkedHashMap<>()
                : new LinkedHashMap<>(payload);
    }
}

package com.govbridge.backend.interoperability.routing;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import org.springframework.stereotype.Service;

@Service
public class GovernmentRoutingService {

    /**
     * Determines which government department should handle
     * the incoming citizen grievance.
     *
     * This is the first layer of GovBridge's intelligent
     * cross-department routing system.
     */
    public String determineDepartment(MunicipalRequest request) {

        String text =
                ((request.getTitle() == null
                        ? ""
                        : request.getTitle())
                        + " "
                        + (request.getDescription() == null
                        ? ""
                        : request.getDescription())
                        + " "
                        + (request.getCategory() == null
                        ? ""
                        : request.getCategory()))
                        .toLowerCase();

        /*
         * Police-related grievances
         */
        if (containsAny(
                text,
                "police",
                "theft",
                "stolen",
                "robbery",
                "murder",
                "kidnap",
                "kidnapping",
                "assault",
                "crime",
                "fraud",
                "missing person",
                "vehicle stolen",
                "motorcycle stolen")) {

            return "POLICE";
        }

        /*
         * Revenue / land-related grievances
         */
        if (containsAny(
                text,
                "revenue",
                "land",
                "property",
                "mutation",
                "ownership",
                "survey",
                "patta",
                "registration",
                "encroachment",
                "land record")) {

            return "REVENUE";
        }

        /*
         * Municipal / local-government grievances
         */
        if (containsAny(
                text,
                "municipal",
                "street light",
                "streetlight",
                "garbage",
                "drainage",
                "sanitation",
                "road",
                "pothole",
                "water supply",
                "sewerage",
                "waste",
                "municipal corporation")) {

            return "MUNICIPAL";
        }

        /*
         * Default department.
         *
         * Instead of rejecting the grievance, GovBridge
         * sends unclassified requests to a general authority.
         */
        return "GENERAL";
    }

    /**
     * Routes the request and returns a simple routing response.
     */
    public RoutingResult routeRequest(MunicipalRequest request) {

        String department = determineDepartment(request);

        String message =
                "Request routed to " + department;

        return new RoutingResult(
                message,
                department
        );
    }

    /**
     * Creates a standardized response when a department
     * does not yet have a live integration adapter.
     *
     * This allows GovBridge to acknowledge the routing decision
     * without pretending that the request was submitted to an
     * external government system.
     */
    public RoutingResult createPendingResponse(
            MunicipalRequest request,
            String department) {

        String message =
                "Request routed to " + department
                        + " and is pending external system integration.";

        return new RoutingResult(
                message,
                department
        );
    }

    /**
     * Standard routing response.
     */
    public static class RoutingResult {

        private String message;
        private String department;

        public RoutingResult() {
        }

        public RoutingResult(
                String message,
                String department) {

            this.message = message;
            this.department = department;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getDepartment() {
            return department;
        }

        public void setDepartment(String department) {
            this.department = department;
        }
    }

    /**
     * Utility method for keyword matching.
     */
    private boolean containsAny(
            String text,
            String... keywords) {

        for (String keyword : keywords) {

            if (text.contains(keyword)) {
                return true;
            }
        }

        return false;
    }
}
package com.govbridge.backend.hierarchy.dto;

import java.util.ArrayList;
import java.util.List;

public class HierarchyNode {

    private String id;
    private String name;
    private String level;
    private String role;
    private String department;
    private List<HierarchyNode> children = new ArrayList<>();

    public HierarchyNode() {
    }

    public HierarchyNode(
            String id,
            String name,
            String level,
            String role,
            String department) {

        this.id = id;
        this.name = name;
        this.level = level;
        this.role = role;
        this.department = department;
    }

    public void addChild(HierarchyNode child) {
        children.add(child);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public List<HierarchyNode> getChildren() {
        return children;
    }

    public void setChildren(List<HierarchyNode> children) {
        this.children = children;
    }
}
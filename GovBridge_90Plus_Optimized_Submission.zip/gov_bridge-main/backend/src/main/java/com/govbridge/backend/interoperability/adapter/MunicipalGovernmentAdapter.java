package com.govbridge.backend.interoperability.adapter;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.integration.GovernmentSystemAdapter;
import com.govbridge.backend.interoperability.service.MunicipalIntegrationService;
import org.springframework.stereotype.Component;

@Component
public class MunicipalGovernmentAdapter implements GovernmentSystemAdapter {

    private final MunicipalIntegrationService municipalIntegrationService;

    public MunicipalGovernmentAdapter(MunicipalIntegrationService municipalIntegrationService) {
        this.municipalIntegrationService = municipalIntegrationService;
    }

    @Override
    public String getDepartment() {
        return "MUNICIPAL";
    }

    @Override
    public String getSystemCode() {
        return "MUNICIPAL";
    }

    @Override
    public String getSystemName() {
        return "Municipal Government System";
    }

    @Override
    public boolean supports(MunicipalRequest request) {
        return request != null && request.getTitle() != null &&
                request.getTitle().toLowerCase().matches(".*(road|street|drain|garbage|municipal|sanitation|streetlight|street light|water).*" );
    }

    @Override
    public UnifiedRequest submit(MunicipalRequest request) {
        return municipalIntegrationService.submitToMunicipalSystem(request);
    }
}

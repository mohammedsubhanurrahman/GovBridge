package com.govbridge.backend.interoperability.controller;

import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.service.InteroperabilityTrackingService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/interoperability/tracking")
public class InteroperabilityTrackingController {

    private final InteroperabilityTrackingService trackingService;

    public InteroperabilityTrackingController(
            InteroperabilityTrackingService trackingService) {

        this.trackingService =
                trackingService;
    }

    /**
     * Get all unified requests.
     */
    @GetMapping
    public List<UnifiedRequest> getAllRequests() {

        return trackingService.getAllRequests();
    }

    /**
     * Get request using GovBridge unified ID.
     */
    @GetMapping("/{requestId}")
    public UnifiedRequest getByRequestId(
            @PathVariable String requestId) {

        return trackingService.getByRequestId(
                requestId
        );
    }

    /**
     * Get request using external government ID.
     */
    @GetMapping("/external/{externalRequestId}")
    public UnifiedRequest getByExternalRequestId(
            @PathVariable String externalRequestId) {

        return trackingService.getByExternalRequestId(
                externalRequestId
        );
    }

    /**
     * Synchronize an external government status
     * into the GovBridge status model.
     *
     * Example:
     * POST /api/interoperability/tracking/sync/MUN-F08E74FB
     *
     * Body:
     * {
     *   "status": "WORKING"
     * }
     */
    @PostMapping("/sync/{externalRequestId}")
    public UnifiedRequest synchronizeStatus(
            @PathVariable String externalRequestId,
            @RequestBody StatusSyncRequest request) {

        return trackingService.synchronizeStatus(
                externalRequestId,
                request.status()
        );
    }

    public record StatusSyncRequest(
            String status
    ) {
    }
}

package com.govbridge.backend.interoperability.police.service;

import com.govbridge.backend.interoperability.dto.MunicipalRequest;
import com.govbridge.backend.interoperability.entity.UnifiedRequest;
import com.govbridge.backend.interoperability.police.dto.PoliceRequest;
import com.govbridge.backend.interoperability.police.dto.PoliceResponse;
import com.govbridge.backend.interoperability.repository.UnifiedRequestRepository;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.UUID;

@Service
public class PoliceIntegrationService {

    private final RestClient restClient;
    private final UnifiedRequestRepository unifiedRequestRepository;

    public PoliceIntegrationService(
            RestClient.Builder restClientBuilder,
            UnifiedRequestRepository unifiedRequestRepository) {

        this.restClient = restClientBuilder
                .baseUrl("http://localhost:8081")
                .build();

        this.unifiedRequestRepository = unifiedRequestRepository;
    }

    /**
     * Sends a citizen grievance to the Police Government System,
     * receives the external response, normalizes it into the
     * GovBridge UnifiedRequest model, and persists it.
     */
    public UnifiedRequest submitToPoliceSystem(
            MunicipalRequest request) {

        PoliceRequest policeRequest =
                new PoliceRequest(
                        request.getTitle(),
                        request.getDescription(),
                        request.getCitizenName(),
                        request.getLocation(),
                        request.getCategory()
                );

        /*
         * ---------------------------------------------------------
         * 1. Send request to external Police System
         * ---------------------------------------------------------
         */
        PoliceResponse response =
                restClient.post()
                        .uri("/mock/police/complaints")
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(policeRequest)
                        .retrieve()
                        .body(PoliceResponse.class);

        if (response == null) {
            throw new IllegalStateException(
                    "Police System returned an empty response."
            );
        }

        /*
         * ---------------------------------------------------------
         * 2. Create normalized GovBridge request
         * ---------------------------------------------------------
         */
        UnifiedRequest unifiedRequest =
                new UnifiedRequest();

        /*
         * GovBridge-wide request ID
         */
        unifiedRequest.setRequestId(
                "GB-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase(Locale.ROOT)
        );

        /*
         * Preserve Police System's external ID
         */
        unifiedRequest.setExternalRequestId(
                response.getComplaintId()
        );

        /*
         * Source platform
         */
        unifiedRequest.setSourceSystem(
                "Police Government System"
        );

        /*
         * Normalize service type
         */
        unifiedRequest.setServiceType(
                normalizeServiceType(request.getCategory())
        );

        unifiedRequest.setTitle(
                request.getTitle()
        );

        /*
         * Department returned by Police System
         */
        unifiedRequest.setDepartment(
                response.getDepartment()
        );

        /*
         * Convert Police status to GovBridge status
         */
        unifiedRequest.setStatus(
                mapStatus(response.getStatus())
        );

        /*
         * AI/rule-based priority for now.
         * This will later be replaced/enhanced
         * by the GovBridge intelligence layer.
         */
        unifiedRequest.setPriority(
                determinePriority(request)
        );

        /*
         * Initial jurisdiction
         */
        unifiedRequest.setJurisdiction(
                "Local"
        );

        /*
         * Police station/authority
         */
        unifiedRequest.setAssignedAuthority(
                response.getAssignedStation()
        );

        /*
         * Explicit synchronization timestamp
         */
        unifiedRequest.setLastSyncedAt(
                LocalDateTime.now()
        );

        /*
         * ---------------------------------------------------------
         * 3. Persist in GovBridge database
         * ---------------------------------------------------------
         */
        return unifiedRequestRepository.save(
                unifiedRequest
        );
    }

    /**
     * Normalizes service/category information.
     */
    private String normalizeServiceType(
            String serviceType) {

        if (serviceType == null ||
                serviceType.isBlank()) {

            return "General Grievance";
        }

        return serviceType.trim();
    }

    /**
     * Converts Police System terminology
     * into GovBridge's canonical status.
     */
    private String mapStatus(
            String policeStatus) {

        if (policeStatus == null ||
                policeStatus.isBlank()) {

            return "SUBMITTED";
        }

        return switch (
                policeStatus.trim()
                        .toUpperCase(Locale.ROOT)) {

            case "OPEN" ->
                    "SUBMITTED";

            case "PENDING" ->
                    "IN_PROGRESS";

            case "INVESTIGATING" ->
                    "IN_PROGRESS";

            case "RESOLVED" ->
                    "RESOLVED";

            case "CLOSED" ->
                    "CLOSED";

            default ->
                    "SUBMITTED";
        };
    }

    /**
     * Determines priority from the grievance
     * title and description.
     */
    private String determinePriority(
            MunicipalRequest request) {

        String text =
                ((request.getTitle() == null
                        ? ""
                        : request.getTitle())
                        + " "
                        + (request.getDescription() == null
                        ? ""
                        : request.getDescription()))
                        .toLowerCase(Locale.ROOT);

        /*
         * Critical police situations
         */
        if (containsAny(
                text,
                "murder",
                "kidnap",
                "kidnapping",
                "terrorist",
                "life threatening",
                "emergency",
                "hostage",
                "bomb")) {

            return "CRITICAL";
        }

        /*
         * High-priority police situations
         */
        if (containsAny(
                text,
                "theft",
                "robbery",
                "assault",
                "violence",
                "stolen",
                "fraud",
                "burglary",
                "threat")) {

            return "HIGH";
        }

        return "MEDIUM";
    }

    /**
     * Utility method for keyword detection.
     */
    private boolean containsAny(
            String text,
            String... keywords) {

        for (String keyword : keywords) {

            if (text.contains(keyword)) {
                return true;
            }
        }

        return false;
    }
}
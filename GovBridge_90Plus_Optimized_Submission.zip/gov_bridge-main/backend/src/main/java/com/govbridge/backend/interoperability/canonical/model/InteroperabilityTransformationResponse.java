package com.govbridge.backend.interoperability.canonical.model;

import java.util.List;

public record InteroperabilityTransformationResponse(
        CanonicalRequest canonicalRequest,
        List<TransformationMapping> mappings,
        List<InteroperabilityTraceEntry> trace
) {
}

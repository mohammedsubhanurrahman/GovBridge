package com.govbridge.backend.audit;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditRepository
        extends JpaRepository<AuditLog, Long> {

    List<AuditLog> findByRequestIdOrderByTimestampAsc(
            String requestId
    );
}

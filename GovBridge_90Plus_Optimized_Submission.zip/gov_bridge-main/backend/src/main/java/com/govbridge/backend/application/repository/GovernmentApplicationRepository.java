package com.govbridge.backend.application.repository;

import com.govbridge.backend.application.entity.GovernmentApplication;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GovernmentApplicationRepository
        extends JpaRepository<GovernmentApplication, Long> {

    Optional<GovernmentApplication> findByApplicationId(
            String applicationId
    );

    List<GovernmentApplication> findByCitizenId(
            String citizenId
    );

    List<GovernmentApplication> findByServiceCode(
            String serviceCode
    );

    List<GovernmentApplication> findByStatusIgnoreCase(
            String status
    );

    boolean existsByApplicationId(
            String applicationId
    );
}
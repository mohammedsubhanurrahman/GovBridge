package com.govbridge.backend.consent;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ConsentRepository
        extends JpaRepository<ConsentRecord, Long> {

    Optional<ConsentRecord> findByRequestIdAndStatus(
            String requestId,
            String status
    );

    Optional<ConsentRecord> findByCitizenIdAndDepartmentAndStatus(
            String citizenId,
            String department,
            String status
    );

    List<ConsentRecord> findByCitizenId(
            String citizenId
    );

    List<ConsentRecord> findByRequestId(
            String requestId
    );
}

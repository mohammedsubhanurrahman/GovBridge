package com.govbridge.backend.audit;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
/**
 * Records and retrieves audit events for request-level traceability.
 */
public class AuditService {

    private final AuditRepository auditRepository;

    public AuditService(
            AuditRepository auditRepository) {

        this.auditRepository =
                auditRepository;
    }

    public AuditLog record(
            String requestId,
            String actor,
            String action,
            String sourceSystem,
            String result,
            String details) {

        if (requestId == null ||
                requestId.isBlank()) {

            throw new IllegalArgumentException(
                    "GovBridge request ID is required."
            );
        }

        AuditLog audit =
                new AuditLog();

        audit.setRequestId(
                requestId.trim()
        );

        audit.setActor(
                actor == null ? "SYSTEM" : actor
        );

        audit.setAction(
                action
        );

        audit.setSourceSystem(
                sourceSystem == null
                        ? "GovBridge"
                        : sourceSystem
        );

        audit.setResult(
                result
        );

        audit.setDetails(
                details
        );

        audit.setTimestamp(
                LocalDateTime.now()
        );

        return auditRepository.save(audit);
    }

    public List<AuditLog> getByRequestId(
            String requestId) {

        return auditRepository
                .findByRequestIdOrderByTimestampAsc(
                        requestId
                );
    }

    public List<AuditLog> getAll() {

        return auditRepository.findAll();
    }
}

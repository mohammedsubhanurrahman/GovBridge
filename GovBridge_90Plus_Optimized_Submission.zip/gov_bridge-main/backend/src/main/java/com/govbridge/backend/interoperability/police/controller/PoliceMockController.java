package com.govbridge.backend.interoperability.police.controller;

import com.govbridge.backend.interoperability.police.dto.PoliceRequest;
import com.govbridge.backend.interoperability.police.dto.PoliceResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/mock/police")
public class PoliceMockController {

    @PostMapping("/complaints")
    public ResponseEntity<PoliceResponse> createComplaint(
            @RequestBody PoliceRequest request) {

        String complaintId =
                "POL-" + UUID.randomUUID()
                        .toString()
                        .substring(0, 8)
                        .toUpperCase();

        PoliceResponse response =
                new PoliceResponse(
                        complaintId,
                        "OPEN",
                        "Police Department",
                        "Demo Police Station",
                        "Complaint successfully registered in Police System"
                );

        return ResponseEntity.ok(response);
    }
}
package com.govbridge.backend.application.event;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/applications")
public class ApplicationEventController {

    private final ApplicationEventRepository eventRepository;

    public ApplicationEventController(
            ApplicationEventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    // ---------------------------------------------------------
    // GET APPLICATION EVENT HISTORY
    // GET /api/applications/{applicationId}/events
    // ---------------------------------------------------------
    @GetMapping("/{applicationId}/events")
    public ResponseEntity<List<ApplicationEvent>> getApplicationEvents(
            @PathVariable String applicationId) {

        return ResponseEntity.ok(
                eventRepository
                        .findByApplicationIdOrderByEventTimeAsc(
                                applicationId)
        );
    }
}
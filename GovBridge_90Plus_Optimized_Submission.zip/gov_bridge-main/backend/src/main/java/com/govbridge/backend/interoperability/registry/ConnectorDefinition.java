package com.govbridge.backend.interoperability.registry;

public record ConnectorDefinition(
        String systemCode,
        String systemName,
        String department,
        String protocol,
        String adapterClass,
        boolean enabled,
        String mode
) {
}

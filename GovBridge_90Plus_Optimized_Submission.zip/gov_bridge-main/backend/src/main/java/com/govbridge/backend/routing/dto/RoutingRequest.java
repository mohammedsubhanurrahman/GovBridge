package com.govbridge.backend.routing.dto;

public class RoutingRequest {

    private String title;
    private String description;

    public RoutingRequest() {
    }

    public RoutingRequest(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
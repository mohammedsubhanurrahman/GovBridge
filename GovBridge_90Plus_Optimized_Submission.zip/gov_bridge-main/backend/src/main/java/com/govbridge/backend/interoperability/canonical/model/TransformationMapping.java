package com.govbridge.backend.interoperability.canonical.model;

public record TransformationMapping(
        String sourceSystem,
        String sourceField,
        String targetField,
        Object sourceValue,
        Object targetValue
) {
}

package com.govbridge.backend.interoperability.revenue.dto;

public class RevenueResponse {

    private String applicationId;
    private String status;
    private String department;
    private String assignedOffice;
    private String message;

    public RevenueResponse() {
    }

    public RevenueResponse(
            String applicationId,
            String status,
            String department,
            String assignedOffice,
            String message) {

        this.applicationId = applicationId;
        this.status = status;
        this.department = department;
        this.assignedOffice = assignedOffice;
        this.message = message;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAssignedOffice() {
        return assignedOffice;
    }

    public void setAssignedOffice(String assignedOffice) {
        this.assignedOffice = assignedOffice;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}